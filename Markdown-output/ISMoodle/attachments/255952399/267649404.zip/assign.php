<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from https://4-demo.preview-moodle.ucl.ac.uk
 *
 * @package    mod
 * @subpackage assign
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['assign:viewblinddetails'] = 'View student identities when anonymous marking is enabled';
$string['assignmentmail'] = '{$a->grader} has posted some feedback on your assignment submission for \'{$a->assignment}\' You can see it appended to your assignment submission: {$a->url}
Marks are provisional and subject to change as a result of internal and external moderation.';
$string['assignmentmailhtml'] = '<p>{$a->grader} has posted some feedback on your assignment submission for \'<i>{$a->assignment}</i>\'.</p> <p>You can see it appended to your <a href="{$a->url}">assignment submission</a>.</p><p></p>
<p>Marks are provisional and subject to change as a result of internal and external moderation.</p>';
$string['assignmentmailsmall'] = '{$a->grader} has posted some feedback on your assignment submission for \'{$a->assignment}\' You can see it appended to your submission

Marks are provisional and subject to change as a result of internal and external moderation.';
$string['blindmarking'] = 'Anonymous marking';
$string['blindmarking_help'] = 'Anonymous marking hides the identity of students from markers. Anonymous marking settings will be locked once a submission or grade has been made in relation to this assignment.';
$string['feedbackavailableanonhtml'] = 'You have new feedback on your assignment submission for \'<i>{$a->assignment}</i>\'<br /><br /> You can see it appended to your <a href="{$a->url}">assignment submission</a>.
Marks are provisional and subject to change as a result of internal and external moderation.';
$string['feedbackavailableanonsmall'] = 'New feedback for assignment {$a->assignment}
Marks are provisional and subject to change as a result of internal and external moderation.';
$string['feedbackavailableanontext'] = 'You have new feedback on your assignment submission for \'{$a->assignment}\' You can see it appended to your assignment submission: {$a->url}
Marks are provisional and subject to change as a result of internal and external moderation.';
$string['feedbackavailablehtml'] = '{$a->username} has posted some feedback on your assignment submission for \'<i>{$a->assignment}</i>\'<br /><br /> You can see it appended to your <a href="{$a->url}">assignment submission</a>.
Marks are provisional and subject to change as a result of internal and external moderation.';
$string['feedbackavailablesmall'] = '{$a->username} has given feedback for assignment {$a->assignment}
Marks are provisional and subject to change as a result of internal and external moderation.';
$string['feedbackavailabletext'] = '{$a->username} has posted some feedback on your assignment submission for \'{$a->assignment}\' You can see it appended to your assignment submission: {$a->url}
Marks are provisional and subject to change as a result of internal and external moderation.';
$string['reopenuntilpassincompatiblewithblindmarking'] = 'Reopen until pass option is incompatible with anonymous marking, because the grades are not released to the gradebook until the student identities are revealed.';
$string['sendstudentnotificationsdefault'] = 'Default setting for "Notify students as you mark"';
