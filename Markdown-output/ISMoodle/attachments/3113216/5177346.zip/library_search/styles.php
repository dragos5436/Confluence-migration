.block_library_search .link {
  border-top:1px solid;
  border-top-color:#DDDDDD;
  padding-bottom:5px;
  font-size:0.82em;
}

.block_library_search .description {
  color:#555555;
  font-size:0.78em;
  padding-left:10px;
  padding-bottom:8px;
}

.block_library_search .blockconfigtable {
    color:#FF0000;
}

.blockconfigtable #displaylinks {
    width: 100%;
}

.blockconfigtable  #displaylinks td.selection {
    text-align: right;
    vertical-align: middle;
    padding: 10px;
}

.blockconfigtable  #displaylinks td.actions {
    text-align: center;
    vertical-align: middle;
    padding: 10px;
}

.blockconfigtable #displaylinks td.links {
    vertical-align: middle;
    padding: 5px;
    text-align = left;
}

.blockconfigtable #displaylinks .title {
    font-weight: bold;
    margin-bottom: 2px;
}

.blockconfigtable #displaylinks .url, .blockconfigtable #displaylinks .description {
    font-size: 0.8em;
}

.blockconfigtable #displaylinks tr.r0 {
  background-color: #ffffff;
}

.blockconfigtable #displaylinks tr.r1 { 
  background-color: #f0f0f0;
}



