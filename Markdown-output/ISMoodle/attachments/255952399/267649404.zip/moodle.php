<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from https://4-demo.preview-moodle.ucl.ac.uk
 *
 * @package    core
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['home'] = 'UCL Moodle';
$string['idnumber'] = 'Portico Student number';
$string['idnumbercourse'] = 'Portico identifier';
$string['idnumbercourse_help'] = 'The ID number of a course is only used when matching the course against external systems and is not displayed anywhere on the site. If the course has an official code name it may be entered, otherwise the field can be left blank.
N.B.: For Portico enrolments to work, this field must not be blank - an identifier which is unique to the course must be entered.';
$string['myhome'] = 'My home';
$string['newsitemsnumber'] = 'News items to show';
$string['resetinfo'] = 'This page allows you to empty a course of user data, while retaining the activities, resources and other settings. Please be warned that by choosing items below and submitting this page you will delete your chosen user data from this course forever!

<br /><br />Click [Select Default] at the bottom of this page, and then click [Reset course].';
$string['resourcedisplayopen'] = 'Open in same window';
$string['showallcourses'] = 'Show all my courses';
$string['tocontent'] = 'After section "{$a}"';
