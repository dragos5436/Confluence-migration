<?php //$Id: mysql.php,v 1.1 2006/06/13 21:53:42 queendido Exp $

function block_library_search_upgrade($oldversion) {
/// This function does anything necessary to upgrade 
/// older versions to match current functionality 

    global $CFG;

    if ($oldversion < 2006070600) {
       # Do something ...
    }

    return true;
}

?>
