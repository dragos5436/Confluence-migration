<?php  // $Id: view.php,v 1.6 2007/09/03 12:23:36 jamiesensei Exp $
/**
 * This page prints a particular instance of turnitintool
 *
 * @author
 * @version $Id: view.php,v 1.6 2007/09/03 12:23:36 jamiesensei Exp $
 * @package turnitintool
 **/

    require_once("../../config.php");
    require_once("lib.php");
	require_once($CFG->dirroot."/lib/uploadlib.php");
	require_once($CFG->dirroot."/lib/html2text.php");
	
	require_js($CFG->wwwroot.'/mod/turnitintool/turnitintool.js');

    $id = required_param('id', PARAM_INT); // Course Module ID, or
    $a  = optional_param('a', 0, PARAM_INT);  // turnitintool ID

    if ($id) {
        if (! $cm = get_coursemodule_from_id('turnitintool', $id)) {
            error("Course Module ID was incorrect");
        }

        if (! $course = turnitintool_get_record("course", "id", $cm->course)) {
            error("Course is misconfigured");
        }

        if (! $turnitintool = turnitintool_get_record("turnitintool", "id", $cm->instance)) {
            error("Course module is incorrect");
        }

    } else {
        if (! $turnitintool = turnitintool_get_record("turnitintool", "id", $a)) {
            error("Course module is incorrect");
        }
        if (! $course = turnitintool_get_record("course", "id", $turnitintool->course)) {
            error("Course is misconfigured");
        }
        if (! $cm = get_coursemodule_from_instance("turnitintool", $turnitintool->id, $course->id)) {
            error("Course Module ID was incorrect");
        }
    }
	
	turnitintool_update_choice_cookie($turnitintool);

    require_login($course->id);
	
	if (isset($_REQUEST['jumppage'])) {
		turnitintool_url_jumpto($_REQUEST['userid'],$_REQUEST['jumppage'],unserialize(base64_decode($_REQUEST['post'])));
		exit();
	}
	
	if (isset($_REQUEST['delete'])) {
		$delete=$_REQUEST['delete'];
		if (!$submission = turnitintool_get_record('turnitintool_submissions','id',$delete)) {
			print_error('submissiongeterror','turnitintool');
			exit();
		}
		turnitintool_delete_submission($cm,$turnitintool,$USER->id,$submission);
		exit();
	}
	
	if (isset($_REQUEST['update'])) {
		turnitintool_update_all_report_scores($cm,$turnitintool,true,true);
		turnitintool_redirect($CFG->wwwroot.'/mod/turnitintool/view.php?id='.$cm->id.'&do='.$_REQUEST["do"]);
		exit();
	}
	
	if (isset($_REQUEST['enroll'])) {
		turnitintool_enroll_all_students($cm,$turnitintool);
		turnitintool_redirect($CFG->wwwroot.'/mod/turnitintool/view.php?id='.$cm->id.'&do='.$_REQUEST["do"]);
		exit();
	}
	
	if (isset($_REQUEST['do']) AND $_REQUEST['do']=="changeowner") {
		turnitintool_ownerprocess($cm,$turnitintool,$_REQUEST['owner']);
		turnitintool_redirect($CFG->wwwroot.'/mod/turnitintool/view.php?id='.$cm->id);
		exit();
	}
	
	if (isset($_REQUEST['do']) AND $_REQUEST['do']=="allsubmissions" AND isset($_POST["anonid"])) {
		turnitintool_revealuser($cm,$turnitintool,$_POST);
		turnitintool_update_all_report_scores($cm,$turnitintool,true,true);
		turnitintool_redirect($CFG->wwwroot.'/mod/turnitintool/view.php?id='.$cm->id.'&do=allsubmissions');
		exit();
	}
	
	if (isset($_REQUEST['viewreport'])) {
		$viewreport=$_REQUEST['viewreport'];
		if (!$submission = turnitintool_get_record('turnitintool_submissions','id',$viewreport)) {
			print_error('submissiongeterror','turnitintool');
			exit();
		}
		turnitintool_view_report($cm,$turnitintool,$USER->id,$submission,$_REQUEST["do"]);
		exit();
		
	}
	
	if (isset($_REQUEST['updategrade'])) {
		turnitintool_update_grades($cm,$turnitintool,$_POST);
	}
	
	if (isset($_REQUEST["up"])) {
		$upload=$_REQUEST["up"];
		if (!$submission = turnitintool_get_record('turnitintool_submissions','id',$upload)) {
			print_error('submissiongeterror','turnitintool');
			exit();
		}
		turnitintool_upload_submission($cm,$turnitintool,$submission);
		exit();
	}
	
	if (isset($_POST['submissiontype']) AND $_REQUEST['do']=='submissions') {
		if (isset($_POST['userid'])) {
			$thisuserid=$_POST['userid'];
		} else {
			$thisuserid=$USER->id;
		}
		if ($_POST['submissiontype']==1) {
			$notice=turnitintool_dofileupload($turnitintool,$cm,$thisuserid,$_REQUEST);
		} else if ($_POST['submissiontype']==2) {
			$notice=turnitintool_dotextsubmission($turnitintool,$cm,$thisuserid,$_REQUEST);
		} else if ($_POST['submissiontype']==3) {
			$notice=turnitintool_dourlsubmission($turnitintool,$cm,$thisuserid,$_REQUEST);
		}
		if ($turnitintool->autosubmission AND !empty($notice["subid"])) {
			if (!$submission = turnitintool_get_record('turnitintool_submissions','id',$notice["subid"])) {
				print_error('submissiongeterror','turnitintool');
				exit();
			}
			turnitintool_upload_submission($cm,$turnitintool,$submission);
			exit();
		}
	}
	
	if (isset($_POST['submitted']) AND $_REQUEST['do']=='intro') {
		$notice=turnitintool_update_partnames($cm,$turnitintool,$_POST);
	}
	
	if (isset($_REQUEST['delpart']) AND $_REQUEST['do']=='intro') {
		$notice=turnitintool_delete_part($cm,$turnitintool,$_REQUEST['delpart']);
	}
	
	if (isset($_POST['submitted']) AND $_REQUEST['do']=='notes') {
		$notice=turnitintool_process_notes($cm,$turnitintool,$_REQUEST["s"],$_POST);
	}
	
	if (isset($_POST['submitted']) AND $_REQUEST['do']=='options') {
		$notice=turnitintool_process_options($cm,$turnitintool,$_POST);
	}
	
	if (isset($_REQUEST['do']) AND $turnitintool->autoupdates AND ($_REQUEST['do']=='allsubmissions' OR $_REQUEST['do']=='submissions')) {
		if ($_REQUEST['do']=='submissions') {
			$getuser=$USER->id;
		} else {
			$getuser=NULL;
		}
		$peruser=false;
		turnitintool_update_all_report_scores($cm,$turnitintool,false);
	}

    add_to_log($course->id, "turnitintool", "view", "view.php?id=$cm->id", "$turnitintool->id");

/// Print the page header
    $strturnitintools = get_string("modulenameplural", "turnitintool");
    $strturnitintool  = get_string("modulename", "turnitintool");

    if (!is_callable('build_navigation')) {
		$navigation = array(array('title' => $course->shortname, 'url' => $CFG->wwwroot."/course/view.php?id=$course->id", 'type' => 'course'),
						array('title' => $strturnitintools, 'url' => $CFG->wwwroot."/mod/turnitintool/index.php?id=$course->id", 'type' => 'activity'),
						array('title' => format_string($turnitintool->name), 'url' => '', 'type' => 'activityinstance'));
	} else {
		$navigation = build_navigation('',$cm);
	}
	
	turnitintool_header($cm,$course,$_SERVER["REQUEST_URI"],$turnitintool->name, $SITE->fullname, $navigation, "", "", true, update_module_button($cm->id, $course->id, $strturnitintool), navmenu($course));

/// Print the main part of the page
	
	if (isset($_REQUEST['do'])) {
		$do=$_REQUEST['do'];
	} else {
		$do='intro';
	}
	
	// $do=ACTION
	// $do=submissions >>> Student Submission Page
	// $do=intro >>> Turnitin Assignment Intro Page
	// $do=allsubmissions >>> Tutor View All Submissions
	// $do=bulkupload >>> Tutor Bulk Upload Student Submissions
	// $do=viewtext >>> View Student Text Submission
	// $do=submissiondetails >>> View Submission Details
	
	$studentdos=array('submissions','intro','viewtext','submissiondetails','notes');
	$graderdos=array('allsubmissions','options','changeowner');
	
	// If an unrecognised DO request produce error
	if (!in_array($do,$studentdos) AND !in_array($do,$graderdos)) {
		turnitintool_print_error('dorequesterror','turnitintool');
		exit();
	} else if (!has_capability('mod/turnitintool:grade', get_context_instance(CONTEXT_MODULE, $cm->id)) AND in_array($do,$graderdos)) {
		turnitintool_print_error('permissiondeniederror','turnitintool');
		exit();
	}
	
	echo '<br />';
	turnitintool_draw_menu($cm,$do);
		
	if ($do=='intro') {
		if (isset($notice['error'])) {
			turnitintool_box_start('generalbox boxwidthwide boxaligncenter error', 'errorbox');
			echo $notice['message'];
			turnitintool_box_end();
		} else {
			$notice=NULL;
		}
		echo turnitintool_introduction($cm,$turnitintool,$notice);
	}
	
	if ($do=='submissions') {
		echo turnitintool_view_student_submissions($cm,$turnitintool);
		if (isset($notice["error"])) {
			turnitintool_box_start('generalbox boxwidthwide boxaligncenter error', 'errorbox');
			echo $notice["error"];
			turnitintool_box_end();
		}
		echo turnitintool_view_submission_form($cm,$turnitintool);
	}
	
	if ($do=='allsubmissions') {
		if (!empty($notice)) {
			turnitintool_box_start('generalbox boxwidthwide boxaligncenter error', 'errorbox');
			echo $notice;
			turnitintool_box_end();
		}
		if (isset($_REQUEST["ob"])) {
			$ob=$_REQUEST["ob"];
		} else {
			$ob=1;
		}
		echo turnitintool_view_all_submissions($cm,$turnitintool,$ob);
	}
	
	if ($do=='notes') {
		echo turnitintool_view_notes($cm,$turnitintool,$_REQUEST["s"],$_POST);
		if (isset($notice['error'])) {
			turnitintool_box_start('generalbox boxwidthwide boxaligncenter error', 'errorbox');
			echo $notice['message'];
			turnitintool_box_end();
		} else {
			$notice=NULL;
		}
		echo turnitintool_addedit_notes($cm,$turnitintool,$_REQUEST["s"],$_POST,$notice);

	}
	
	if ($do=='options') {
		if (!empty($notice)) {
			turnitintool_box_start('generalbox boxwidthwide boxaligncenter', 'general');
			echo $notice;
			turnitintool_box_end();
		}
		echo turnitintool_view_options($cm,$turnitintool);
	}

	// Finish the page
    turnitintool_footer($course);

?>