<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * External ULCC web service api
 *
 * @copyright &copy; 2011 University of London Computer Centre
 * @author http://www.ulcc.ac.uk, http://moodle.ulcc.ac.uk
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package ULCC_webservices
 * @version 1.0
 */


/** @var $CFG  */
require_once("$CFG->libdir/externallib.php");

/**
 * User functions
 */
class local_ulcc_webservices extends external_api {

    /*****
     * Returns a list of the sections within the course with the given id
     *
     * @static
     * @param int $courseid
     * @throws moodle_exception
     * @return array
     */
    public static function course_get_sections($courseid) {

        global $CFG, $DB;

        require_once($CFG->dirroot . "/course/lib.php");

        // Validate the giuven parameter.
        $params = self::validate_parameters(self::course_get_sections_parameters(), array('courseid' => $courseid));

        // Retrieve the course.
        $course = $DB->get_record('course', array('id' => $params['courseid']), '*', MUST_EXIST);

        // Check course format exist.
        if (!file_exists($CFG->dirroot . '/course/format/' . $course->format . '/lib.php')) {
            throw new moodle_exception('cannotgetcoursecontents', 'webservice', '', null,
                get_string('courseformatnotfound', 'error', '', $course->format));
        } else {
            require_once($CFG->dirroot . '/course/format/' . $course->format . '/lib.php');
        }

        // Now security checks.
        $context = get_context_instance(CONTEXT_COURSE, $course->id);
        try {
            self::validate_context($context);
        } catch (Exception $e) {
            $exceptionparam = new stdClass();
            $exceptionparam->message = $e->getMessage();
            $exceptionparam->courseid = $course->id;
            throw new moodle_exception('errorcoursecontextnotvalid', 'webservice', '', $exceptionparam);
        }

        $retvalue = array();
        $sections = get_all_sections($course->id);

        if (!empty($sections)) {
            foreach ($sections as $s) {
                $sectionvalues = array();
                $sectionvalues['id'] = $s->id;
                $sectionvalues['name'] = get_section_name($course, $s);
                $summary = file_rewrite_pluginfile_urls($s->summary, 'webservice/pluginfile.php', $context->id, 'course',
                    'section', $s->id);
                $sectionvalues['visible'] = $s->visible;
                $sectionvalues['summary'] = format_text($summary, $s->summaryformat);
                $retvalue[] = $sectionvalues;
            }
        }

        return $retvalue;
    }

    /**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function course_get_sections_parameters() {
        return new external_function_parameters(
            array(
                'courseid' => new external_value(PARAM_INT, 'Course ID')
            )
        );
    }

    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function course_get_sections_returns() {
        return new external_multiple_structure(
            new external_single_structure(
                array(
                    'id' => new external_value(PARAM_INT, 'section record id'),
                    'name' => new external_value(PARAM_TEXT, 'name of section'),
                    'visible' => new external_value(PARAM_INT, 'The visibility'),
                    'summary' => new external_value(PARAM_RAW, 'Summary of section content', VALUE_OPTIONAL),
                )
            ), 'List of section objects. A section has an id, a name, visible,a summary
            .'
        );
    }

    /*********
     * @param $sectionid
     * @throws moodle_exception
     * @return array
     */
    public static function section_get_content($sectionid) {

        global $CFG, $DB;

        require_once($CFG->dirroot . "/course/lib.php");

        $params = self::validate_parameters(self::section_get_content_parameters(), array('sectionid' => $sectionid));

        $sec = $DB->get_record('course_sections', array('id' => $params['sectionid']));

        // Retrieve the course.
        $course = $DB->get_record('course', array('id' => $sec->course), '*', MUST_EXIST);

        // Check course format exist.
        if (!file_exists($CFG->dirroot . '/course/format/' . $course->format . '/lib.php')) {
            throw new moodle_exception('cannotgetcoursecontents', 'webservice', '', null,
                get_string('courseformatnotfound', 'error', '', $course->format));
        } else {
            require_once($CFG->dirroot . '/course/format/' . $course->format . '/lib.php');
        }

        // Now security checks.
        $context = get_context_instance(CONTEXT_COURSE, $course->id);
        try {
            self::validate_context($context);
        } catch (Exception $e) {
            $exceptionparam = new stdClass();
            $exceptionparam->message = $e->getMessage();
            $exceptionparam->courseid = $course->id;
            throw new moodle_exception('errorcoursecontextnotvalid', 'webservice', '', $exceptionparam);
        }

        $canupdatecourse = has_capability('moodle/course:update', $context);

        // Create return value.
        $coursecontents = array();

        if ($canupdatecourse or $course->visible
            or has_capability('moodle/course:viewhiddencourses', $context)
        ) {

            // Retrieve sections.
            $modinfo = get_fast_modinfo($course);
            $sections = get_all_sections($course->id);

            // For each sections (first displayed to last displayed).
            foreach ($sections as $key => $section) {

                if ($section->id != $sec->id) {
                    continue;
                }

                $showsection = (has_capability('moodle/course:viewhiddensections',
                    $context) or $section->visible or !$course->hiddensections);
                if (!$showsection) {
                    continue;
                }

                // Reset $sectioncontents.
                $sectionvalues = array();
                $sectionvalues['id'] = $section->id;
                $sectionvalues['name'] = get_section_name($course, $section);
                $summary = file_rewrite_pluginfile_urls($section->summary, 'webservice/pluginfile.php',
                    $context->id, 'course', 'section', $section->id);
                $sectionvalues['visible'] = $section->visible;
                $sectionvalues['summary'] = format_text($summary, $section->summaryformat);
                $sectioncontents = array();

                // For each module of the section.
                foreach ($modinfo->sections[$section->section] as $cmid) { // Matching /course/lib.php:print_section() logic.
                    $cm = $modinfo->cms[$cmid];

                    // Stop here if the module is not visible to the user.
                    if (!$cm->uservisible) {
                        continue;
                    }

                    $module = array();

                    // Common info (for people being able to see the module or availability dates).
                    $module['id'] = $cm->id;
                    $module['name'] = format_string($cm->name, true);
                    $module['modname'] = $cm->modname;
                    $module['modplural'] = $cm->modplural;
                    $module['modicon'] = $cm->get_icon_url()->out(false);
                    $module['indent'] = $cm->indent;

                    $modcontext = get_context_instance(CONTEXT_MODULE, $cm->id);

                    if (!empty($cm->showdescription)) {
                        $module['description'] = $cm->get_content();
                    }

                    // Url of the module.
                    $url = $cm->get_url();
                    if ($url) { // Labels don't have url.
                        $module['url'] = $cm->get_url()->out();
                    }

                    $canviewhidden = has_capability('moodle/course:viewhiddenactivities',
                        get_context_instance(CONTEXT_MODULE, $cm->id));
                    // User that can view hidden module should know about the visibility.
                    $module['visible'] = $cm->visible;

                    // Availability date (also send to user who can see hidden module when the showavailabilyt is ON).
                    if ($canupdatecourse or ($CFG->enableavailability && $canviewhidden && $cm->showavailability)) {
                        $module['availablefrom'] = $cm->availablefrom;
                        $module['availableuntil'] = $cm->availableuntil;
                    }

                    $baseurl = 'webservice/pluginfile.php';

                    // Call $modulename_export_contents
                    // ...(each module callback take care about checking the capabilities).
                    require_once($CFG->dirroot . '/mod/' . $cm->modname . '/lib.php');
                    $getcontentfunction = $cm->modname . '_export_contents';
                    if (function_exists($getcontentfunction)) {
                        if ($contents = $getcontentfunction($cm, $baseurl)) {
                            $module['contents'] = $contents;
                        }
                    }

                    // Assign result to $sectioncontents.
                    $sectioncontents[] = $module;

                }
            }
        }
        return $sectioncontents;

    }

    public static function section_get_content_parameters() {
        return new external_function_parameters(
            array(
                'sectionid' => new external_value(PARAM_INT, 'Section ID')
            )
        );
    }


    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function section_get_content_returns() {
        return new external_multiple_structure(
            new external_single_structure(
                array(
                    'id' => new external_value(PARAM_INT, 'activity id'),
                    'url' => new external_value(PARAM_URL, 'activity url', VALUE_OPTIONAL),
                    'name' => new external_value(PARAM_TEXT, 'activity module name'),
                    'description' => new external_value(PARAM_RAW, 'activity description', VALUE_OPTIONAL),
                    'visible' => new external_value(PARAM_INT, 'is the module visible', VALUE_OPTIONAL),
                    'modicon' => new external_value(PARAM_URL, 'activity icon url'),
                    'modname' => new external_value(PARAM_PLUGIN, 'activity module type'),
                    'modplural' => new external_value(PARAM_TEXT, 'activity module plural name'),
                    'availablefrom' => new external_value(PARAM_INT, 'module availability start date', VALUE_OPTIONAL),
                    'availableuntil' => new external_value(PARAM_INT, 'module availability end date', VALUE_OPTIONAL),
                    'indent' => new external_value(PARAM_INT, 'number of identation in the site'),
                    'contents' => new external_multiple_structure(
                        new external_single_structure(
                            array(
                                // Content info.
                                'type' => new external_value(PARAM_TEXT, 'a file or a folder or external link'),
                                'filename' => new external_value(PARAM_FILE, 'filename'),
                                'filepath' => new external_value(PARAM_PATH, 'filepath'),
                                'filesize' => new external_value(PARAM_INT, 'filesize'),
                                'fileurl' => new external_value(PARAM_URL, 'downloadable file url', VALUE_OPTIONAL),
                                'content' => new external_value(PARAM_RAW, 'Raw content, will be used when type is content',
                                    VALUE_OPTIONAL),
                                'timecreated' => new external_value(PARAM_INT, 'Time created'),
                                'timemodified' => new external_value(PARAM_INT, 'Time modified'),
                                'sortorder' => new external_value(PARAM_INT, 'Content sort order'),

                                // Copyright related info.
                                'userid' => new external_value(PARAM_INT, 'User who added this content to moodle'),
                                'author' => new external_value(PARAM_TEXT, 'Content owner'),
                                'license' => new external_value(PARAM_TEXT, 'Content license'),
                            )
                        ), VALUE_DEFAULT, array()
                    )
                )
            ), 'List of section objects. A section has an id, a name, visible,a summary
            .'
        );
    }

    /**
     * Returns a list of assignments for the user with the given userid
     *
     * @param int $userid the id of the user whose assignments will be retrieved
     *
     * @return array
     */

    public static function  get_user_assignments($userid = null) {
        global $DB, $USER;
        // If user id is empty pass the global user id.
        $userid = (empty($userid)) ? $USER->id : $userid;

        $params = self::validate_parameters(self::get_user_assignments_parameters(), array('userid' => $userid));
        // Get all user courses.
        $my_courses = enrol_get_users_courses($userid);
        $userassignments = array();
        if (!empty($my_courses)) {
            foreach ($my_courses as $course) {
                // Get all assignments for this course.
                $sql = "SELECT  * FROM  {assignment}
                          WHERE course = :courseid";
                $assignments = $DB->get_records_sql($sql, array('courseid' => $course->id));
                // Create.
                if (!empty($assignments)) {
                    foreach ($assignments as $a) {
                        $assign = new stdClass();
                        $assign->id = $a->id;
                        $assign->name = $a->name;
                        $assign->summary = $a->intro;
                        $assign->courseid = $a->course;
                        $assign->deadline = $a->timedue;
                        // Get user submission for this assignment if one has been created.

                        $submission = $DB->get_record('assignment_submissions', array('assignment' => $a->id, 'userid' => $userid));
                        $assign->status = (!empty($submission)) ? 1 : 0;
                        $assign->grade = (!empty($submission)) ? $submission->grade : 0;
                        $userassignments[] = (array)$assign;
                    }
                }
            }
        }
        return $userassignments;
    }

    /**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function get_user_assignments_parameters() {
        return new external_function_parameters(
            array(

                'userid' => new external_value(PARAM_INT, 'User ID')

            )
        );
    }

    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function get_user_assignments_returns() {
        return new external_multiple_structure(
            new external_single_structure(
                array(
                    'id' => new external_value(PARAM_RAW, 'assignment id'),
                    'name' => new external_value(PARAM_RAW, 'name of assignment'),
                    'summary' => new external_value(PARAM_RAW, 'intro used for assignment'),
                    'courseid' => new external_value(PARAM_RAW, 'id of course that the assignment is in'),
                    'deadline' => new external_value(PARAM_RAW, 'timestamp of the deadline for the course'),
                    'status' => new external_value(PARAM_RAW, 'has the user created a submission for the assignment'),
                    'grade' => new external_value(PARAM_RAW, 'Grade'),

                )
            ), 'List of assignments the a user has been set in their various courses.'
        );
    }


    /**
     * Returns assignment information based on the course module id provided. PLease note only assignment information
     * is provided any other module will result in a null being returned
     *
     * @param int $cmid the course module id of the assignment
     *
     * @return array|\stdClass
     */
    public static function  get_cm_assignment($cmid) {

        global $CFG, $DB;

        $params = self::validate_parameters(self::get_cm_assignment_parameters(), array('cmid' => $cmid));

        $sql = "SELECT a.*
                         FROM   {assignment}    as a,
                                {modules}        as m,
                                {course_modules} as cm
                         WHERE  m.name        = 'assignment'
                         AND    m.id          = cm.module
                         AND    cm.instance   = a.id
                         AND    cm.id         = $cmid";

        $record = $DB->get_record_sql($sql);

        // ...$assignment =   false;.

        if (!empty($record)) {
            $assign = new stdClass();
            $assign->id = $record->id;
            $assign->name = $record->name;
            $assign->summary = $record->intro;
            $assign->timeavailable = $record->timeavailable;
            $assign->timedue = $record->timedue;
            $assign = (array)$assign;
        }

        return $assign;
    }

    /**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function get_cm_assignment_parameters() {
        return new external_function_parameters(
            array(
                'cmid' => new external_value(PARAM_INT, 'Course module id')
            )
        );
    }

    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function get_cm_assignment_returns() {
        return new external_single_structure(
            array(
                'id' => new external_value(PARAM_INT, 'assignment id'),
                'name' => new external_value(PARAM_RAW, 'name of assignment'),
                'summary' => new external_value(PARAM_RAW, 'intro used for assignment'),
                'timeavailable' => new external_value(PARAM_RAW, 'timestamp of the date & time the assignment is available from'),
                'timedue' => new external_value(PARAM_RAW, 'timestamp if the date & time that the assignment is due'),
            )
        );
    }

    /**
     * @static returns a array containing student grades
     * @param int $userid the id of the user whose grades will be returned
     * @return array
     */
    public static function  get_user_grades($userid = null) {

        global $CFG, $USER;
        // If user id is empty pass the global user id.
        $userid = (empty($userid)) ? $USER->id : $userid;
        $params = self::validate_parameters(self::get_user_grades_parameters(), array('userid' => $userid));

        require_once($CFG->libdir . '/gradelib.php');

        // Get all user courses.
        $my_courses = enrol_get_users_courses($userid, false, 'id, shortname, fullname, showgrades');

        $coursegrades = array();

        if (!empty($my_courses)) {
            foreach ($my_courses as $course) {
                if (!$course->showgrades) {
                    continue;
                }

                $coursecontext = get_context_instance(CONTEXT_COURSE, $course->id);

                $canviewhidden = has_capability('moodle/grade:viewhidden', $coursecontext);

                // Get course grade_item.
                $course_item = grade_item::fetch_course_item($course->id);

                // Get the stored grade.
                $course_grade = new grade_grade(array('itemid' => $course_item->id, 'userid' => $userid));
                $course_grade->grade_item =& $course_item;
                $finalgrade = $course_grade->finalgrade;
                $grademax = $course_grade->grade_item->grademax;
                $grademin = $course_grade->grade_item->grademin;
                $rawgrademax = $course_grade->rawgrademax;
                $rawgrademin = $course_grade->rawgrademin;
                $feedback = $course_grade->optional_fields->feedback;

                if (!$canviewhidden and !is_null($finalgrade)) {
                    if ($course_grade->is_hidden()) {
                        $finalgrade = null;
                    }
                }

                $grade = grade_format_gradevalue($finalgrade, $course_item, true);

                $cgrade = new stdClass();
                $cgrade->id = $course->id;
                $cgrade->fullname = $course->fullname;
                $cgrade->grade = $grade;
                $cgrade->range = number_format($grademin, 0) . " - " . number_format($grademax, 0);
                $cgrade->percentage = number_format($rawgrademin, 0) . " - " . number_format($rawgrademax, 0);
                $cgrade->feedback = $feedback;

                $coursegrades[] = (array)$cgrade;
            }

        }

        return $coursegrades;

    }

    /**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function get_user_grades_parameters() {
        return new external_function_parameters(
            array(
                'userid' => new external_value(PARAM_INT, 'User ID')
            )
        );
    }


    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function get_user_grades_returns() {
        return new external_multiple_structure(
            new external_single_structure(
                array(
                    'id' => new external_value(PARAM_INT, 'course id'),
                    'fullname' => new external_value(PARAM_TEXT, 'course fullname'),
                    'grade' => new external_value(PARAM_TEXT, 'course grade '),
                    'range' => new external_value(PARAM_RAW, 'course range '),
                    'percentage' => new external_value(PARAM_RAW, 'course percentage '),
                    'feedback' => new external_value(PARAM_TEXT, 'course feedback ')
                )
            ), 'List of courses the user is in and the grades the user has achieved.'
        );
    }


    /**
     * @static returns a array containing student grades
     * @param $courseid
     * @param int $userid the id of the user whose grades will be returned
     * @return array
     */
    public static function  get_course_grades($courseid, $userid = null) {

        global $CFG, $USER;
        // If user id is empty pass the global user id.
        $userid = (empty($userid)) ? $USER->id : $userid;
        $params = self::validate_parameters(self::get_course_grades_parameters(), array('courseid' => $courseid,
            'userid' => $userid));

        require_once($CFG->dirroot . '/grade/lib.php');
        require_once($CFG->dirroot . '/grade/report/user/lib.php');

        $context = get_context_instance(CONTEXT_COURSE, $courseid);

        $gpr = new grade_plugin_return(array('type' => 'report', 'plugin' => 'user', 'courseid' => $courseid, 'userid' => $userid));

        // Grab the grade_tree for this course.
        $report = new grade_report_user($courseid, $gpr, $context, $userid);
        $report->fill_table();
        $grades = array();

        // This is a little bit of a hack (almost) we are traversing the grade_report_user tabledata
        // Var (which is filled with all of the grade data for the student) and taking the grade.

        foreach ($report->tabledata as $data) {
            if (!isset($data['leader'])) {
                $grade['gradeitem'] = strip_tags($data['itemname']['content']);
                $grade['grade'] = ($data['grade']['content'] == 'Error') ? '-' : $data['grade']['content'];

                $grade['range'] = $data['range']['content'];
                $grade['percentage'] = ($data['percentage']['content'] == 'Error') ? '-' : $data['percentage']['content'];
                $grade['feedback'] = $data['feedback']['content'];
                $grades[] = $grade;

            }
        }

        return $grades;

    }

    /**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function get_course_grades_parameters() {
        return new external_function_parameters(
            array(
                'courseid' => new external_value(PARAM_INT, 'Course ID'),
                'userid' => new external_value(PARAM_INT, 'User ID')
            )
        );
    }


    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function get_course_grades_returns() {
        return new external_multiple_structure(
            new external_single_structure(
                array(
                    'gradeitem' => new external_value(PARAM_RAW, 'grade item name'),
                    'grade' => new external_value(PARAM_RAW, 'course grade '),
                    'range' => new external_value(PARAM_RAW, 'course range '),
                    'percentage' => new external_value(PARAM_RAW, 'course percentage '),
                    'feedback' => new external_value(PARAM_RAW, 'course feedback ')

                )
            ), 'List of grades achieved for individual work in a course.'
        );
    }

    /**
     * @static returns a array containing all forums within a course
     * @param int $courseid the id of the course whose forums will be retrieved
     * @param null $userid
     * @return array
     */
    public static function  get_course_forums($courseid, $userid = null) {

        global $CFG, $USER;
        // If user id is empty pass the global user id.
        $userid = (empty($userid)) ? $USER->id : $userid;
        $params = self::validate_parameters(self::get_course_forums_parameters(), array('courseid' => $courseid,
            'userid' => $userid));

        require_once($CFG->dirroot . '/mod/forum/lib.php');

        $records = forum_get_readable_forums($courseid, $userid);

        $courseforums = array();
        if (!empty($records)) {
            foreach ($records as $f) {
                $forum = new stdClass();

                $forum->id = $f->id;
                $forum->coursemoduleid = $f->cm->id;
                $forum->name = $f->name;
                $forum->intro = $f->intro;
                $forum->timeavailable = (isset($f->cm->availablefrom)) ? $f->cm->availablefrom : 0;

                $courseforums[] = (array)$forum;
            }
        }

        return $courseforums;
    }

    /**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function get_course_forums_parameters() {
        return new external_function_parameters(
            array(
                'courseid' => new external_value(PARAM_INT, 'Course ID'),
                'userid' => new external_value(PARAM_INT, 'User ID'),
            )
        );
    }

    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function get_course_forums_returns() {
        return new external_multiple_structure(
            new external_single_structure(
                array(
                    'id' => new external_value(PARAM_INT, 'id'),
                    'coursemoduleid' => new external_value(PARAM_INT, 'coursemodule id '),
                    'name' => new external_value(PARAM_TEXT, 'name'),
                    'intro' => new external_value(PARAM_RAW, 'intro used for forum'),
                    'timeavailable' => new external_value(PARAM_INT, 'timestamp of the date & time the forum is available from'),
                )
            ), 'Forums available for the user to view in this course.'
        );
    }


    /**
     * @static returns a array containing all forums within a course
     * @param $coursemoduleid
     * @return array
     * @internal param int $courseid the id of the course whose forums will be retrieved
     */
    public static function  get_coursemodule_forum($coursemoduleid) {

        global $CFG, $DB;

        $params = self::validate_parameters(self::get_coursemodule_forum_parameters(), array('coursemoduleid' => $coursemoduleid));

        require_once ($CFG->dirroot . '/mod/forum/lib.php');

        $cm = $DB->get_record('course_modules', array('id' => $coursemoduleid));


        $courseforum = array();
        if (!empty($cm)) {
            $f = $DB->get_record('forum', array('id' => $cm->instance));
            if (!empty($f)) {
                $forum = new stdClass();
                $forum->id = $f->id;
                $forum->coursemoduleid = $cm->id;
                $forum->name = $f->name;
                $forum->intro = $f->intro;
                $forum->timeavailable = (isset($cm->availablefrom)) ? $cm->availablefrom : 0;
                $courseforum = (array)$forum;
            }
        }

        return $courseforum;
    }

    /**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function get_coursemodule_forum_parameters() {
        return new external_function_parameters(
            array(
                'coursemoduleid' => new external_value(PARAM_INT, 'Course module id'),
            )
        );
    }

    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function get_coursemodule_forum_returns() {
        return new external_single_structure(
            array(
                'id' => new external_value(PARAM_INT, 'id'),
                'coursemoduleid' => new external_value(PARAM_INT, 'coursemodule id '),
                'name' => new external_value(PARAM_TEXT, 'name'),
                'intro' => new external_value(PARAM_RAW, 'intro used for forum'),
                'timeavailable' => new external_value(PARAM_INT, 'timestamp of the date & time the forum is available from'),
            )
        );
    }


    /**
     * @static returns a array containing all discussions within a forum
     * @param int $coursemoduleid the coursemodule id of the forum whose discussions will be returned
     * will be returned
     */
    public static function  get_forum_discussions($coursemoduleid) {

        global $CFG, $DB;

        $params = self::validate_parameters(self::get_forum_discussions_parameters(), array('coursemoduleid' => $coursemoduleid));

        require_once($CFG->dirroot . '/mod/forum/lib.php');

        $coursemodule = $DB->get_record('course_modules', array('id' => $coursemoduleid));

        $records = forum_get_discussions($coursemodule);

        $recordsreplies = forum_count_discussion_replies($coursemodule->instance);

        $discussionrecords = array();

        if (!empty($records)) {
            foreach ($records as $d) {
                $disscusion = new stdClass();
                $disscusion->id = $d->id;
                $disscusion->name = $d->name;
                $disscusion->author = $d->firstname . ' ' . $d->lastname;
                $disscusion->content = $d->message;
                $disscusion->discussion = $d->discussion;
                // ...$disscusion->firstpost  =   $d->firstpost;.

                if (isset($recordsreplies[$d->discussion])) {
                    $disscusion->replies = $recordsreplies[$d->discussion]->replies;
                    $post = forum_get_post_full($recordsreplies[$d->discussion]->lastpostid);
                    $disscusion->lastreply = $post->modified;
                } else {
                    $disscusion->replies = 0;
                    $disscusion->lastreply = 0;
                }

                $discussionrecords[] = (array)$disscusion;
            }

        }

        return $discussionrecords;
    }

    /**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function get_forum_discussions_parameters() {
        return new external_function_parameters(
            array(
                'coursemoduleid' => new external_value(PARAM_INT, 'Course module id of the discussion'),
            )
        );
    }


    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function get_forum_discussions_returns() {
        return new external_multiple_structure(
            new external_single_structure(
                array(
                    'id' => new external_value(PARAM_INT, 'post id'),
                    'name' => new external_value(PARAM_TEXT, 'name of discussion'),
                    'discussion' => new external_value(PARAM_INT, 'discussion id '),
                    'author' => new external_value(PARAM_TEXT, 'author of discussion'),
                    'content' => new external_value(PARAM_RAW, 'content of discussion'),
                    'replies' => new external_value(PARAM_INT, 'the number of replies to this dsicussion'),
                    'lastreply' => new external_value(PARAM_INT,
                        'timestamp of the date & time of the last reply to this discussion'),
                )
            ), 'List of discussion in the given forum'
        );
    }


    /**
     * @static returns a array containing all posts within a discussion
     * @param int $discussionid the id of the discussion whose psts will be returned
     * will be returned
     * @return array
     */
    public static function  get_discussion_posts($discussionid) {

        global $CFG, $DB;

        $params = self::validate_parameters(self::get_discussion_posts_parameters(), array('discussionid' => $discussionid));

        require_once($CFG->dirroot . '/mod/forum/lib.php');

        $discussion = $DB->get_record('forum_discussions', array('id' => $discussionid));

        $records = forum_get_discussion_posts($discussionid, 'order by modified', $discussion->forum);
        $postrecords = array();

        if (!empty($records)) {
            foreach ($records as $p) {
                $post = new stdClass();
                $post->id = $p->id;
                $post->parent = $p->parent;
                $post->subject = $p->subject;
                $post->content = $p->message;
                $post->author = $p->firstname . " " . $p->lastname;
                $post->date = $p->modified;

                $postrecords[] = (array)$post;
            }
        }

        return $postrecords;

    }

    /**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function get_discussion_posts_parameters() {
        return new external_function_parameters(
            array(
                'discussionid' => new external_value(PARAM_INT, 'Disscussion id'),
            )
        );
    }

    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function get_discussion_posts_returns() {
        return new external_multiple_structure(
            new external_single_structure(
                array(
                    'id' => new external_value(PARAM_INT, 'id'),
                    'parent' => new external_value(PARAM_INT, 'parent post id'),
                    'subject' => new external_value(PARAM_TEXT, 'subject of post'),
                    'author' => new external_value(PARAM_TEXT, 'author of discussion'),
                    'content' => new external_value(PARAM_RAW, 'content of discussion'),
                    'date' => new external_value(PARAM_INT, 'timestamp of the date & time of the post was last modified'),
                )
            ), 'List of discussion in the given forum'
        );
    }


    /**
     * @static allows a discussion to be added to the forum with the given id
     * @param int $forumid the id of the forum that the discussion will be added to
     * @param int $userid  the id fo the user who is creating the discussion
     * @param string $subject the subject of the discussion
     * @param string $message the message in the discussion post
     * @param int $mailnow should all other forum users be mailed about this post
     *
     * return int id of post or false
     * @return array
     */
    public static function  add_forum_discussion($forumid, $subject, $message, $mailnow = 0, $userid = null) {

        global $CFG, $DB, $USER;
        // If user id is empty pass the global user id.
        $userid = (empty($userid)) ? $USER->id : $userid;
        $params = self::validate_parameters(self::add_forum_discussion_parameters(), array('forumid' => $forumid,
            'userid' => $userid, 'subject' => $subject, 'message' => $message, 'mailnow' => $mailnow));

        require_once($CFG->dirroot . '/mod/forum/lib.php');

        $forum = $DB->get_record('forum', array('id' => $forumid));

        $discussion = new stdClass();
        $discussion->forum = $forumid;
        $discussion->name = $subject;
        $discussion->message = $message;
        // Need to check the other possible values for these two.
        $discussion->messageformat = 1;
        $discussion->messagetrust = 0;
        $discussion->mailnow = $mailnow;
        $discussion->course = $forum->course;
        $message = '';

        $result = array();

        $result['result'] = forum_add_discussion($discussion, null, $message, $userid);

        return $result;
    }

    /**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function add_forum_discussion_parameters() {
        return new external_function_parameters(
            array(
                'forumid' => new external_value(PARAM_INT, 'Forum id'),
                'subject' => new external_value(PARAM_TEXT, 'subject id'),
                'message' => new external_value(PARAM_RAW, 'discussion message'),
                'mailnow' => new external_value(PARAM_INT, 'should all users be mailed now to inform them of this post'),
                'userid' => new external_value(PARAM_INT, 'User id'),
            )
        );
    }

    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function add_forum_discussion_returns() {
        return new external_single_structure(
            array(
                'result' => new external_value(PARAM_INT, 'result of discussion insert'),
            )
        );
    }

    /**
     * @static allows a discussion to be added to the forum with the given id
     * @param int $discussionid the id of the discussion the post will be added to
     * @param int $parentid the id of the post that the post is in reply should be 0 if not in reply to
     *            a post
     * @param string $subject the subject of the post
     * @param string $message the message in the post
     *
     * return int id of post or false
     * @return array
     */
    public static function  add_discussion_post($discussionid, $subject, $message, $parentid = 0) {

        global $CFG, $DB;

        $params = self::validate_parameters(self::add_discussion_post_parameters(), array('discussionid' => $discussionid,
            'subject' => $subject, 'message' => $message, 'parentid' => $parentid));

        require_once($CFG->dirroot . '/mod/forum/lib.php');

        if (empty($parentid)) {
            $discussion = $DB->get_record('forum_discussions', array('id' => $discussionid));
            $parentid = (!empty($discussion)) ? $discussion->firstpost : 0;
        }

        $post = new stdClass();
        $post->discussion = $discussionid;
        $post->subject = $subject;
        $post->message = $message;
        $post->messageformat = 1;
        $post->parent = $parentid;

        $post->itemid = 0;

        $message = '';
        $mform = null;

        $result = array();

        $result['result'] = forum_add_new_post($post, $mform, $message);

        return $result;
    }


    /**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function add_discussion_post_parameters() {
        return new external_function_parameters(
            array(
                'discussionid' => new external_value(PARAM_INT, 'Discussion id'),
                'subject' => new external_value(PARAM_TEXT, 'subject id'),
                'message' => new external_value(PARAM_RAW, 'post message'),
                'parentid' => new external_value(PARAM_INT, 'parent post'),
            )
        );
    }

    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function add_discussion_post_returns() {
        return new external_single_structure(
            array(
                'result' => new external_value(PARAM_INT, 'result of post insert'),
            )
        );
    }

    /**
     * @static allows a discussion to be added to the forum with the given id
     * @param int $userid the id of the user whose forums will be returned
     *
     *
     * return int id of post or false
     * @return array
     */
    public static function  get_user_forums($userid = null) {

        global $CFG, $DB, $USER;
        // If user id is empty pass the global user id.
        $userid = (empty($userid)) ? $USER->id : $userid;
        $params = self::validate_parameters(self::get_user_forums_parameters(), array('userid' => $userid));

        require_once $CFG->dirroot . '/mod/forum/lib.php';

        $records = forum_get_readable_forums($userid);
        $forums = array();

        if (!empty($records)) {
            foreach ($records as $r) {
                $f = new stdClass();
                $f->id = $r->id;
                $f->name = $r->name;
                $f->intro = $r->intro;
                $f->courseid = $r->cm->course;

                $forum = $DB->get_record('forum', array('id' => $r->id));

                $forumtracked = forum_tp_is_tracked($forum);

                if (!empty($forumtracked)) {
                    $course = $DB->get_record('course', array('id' => $r->cm->course));
                    $f->unreadposts = forum_tp_count_forum_unread_posts($r->cm, $course);
                } else {
                    $f->unreadposts = 0;
                }

                $forums[] = (array)$f;
            }
        }

        return $forums;
    }


    /**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function get_user_forums_parameters() {
        return new external_function_parameters(
            array(
                'userid' => new external_value(PARAM_INT, 'user id'),
            )
        );
    }

    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function get_user_forums_returns() {
        return new external_multiple_structure(
            new external_single_structure(
                array(
                    'id' => new external_value(PARAM_INT, 'id'),
                    'name' => new external_value(PARAM_TEXT, 'name of forum'),
                    'intro' => new external_value(PARAM_RAW, 'intro'),
                    'courseid' => new external_value(PARAM_INT, 'courseid'),
                    'unreadposts' => new external_value(PARAM_INT, 'number of unread posts (if forum tracked)'),
                )
            ), 'List of forums that the user can post in'
        );
    }

    /**
     * @static returns a list of forums that the given user can post to
     * @param $coursemoduleid
     * @return array
     * @internal param int $userid the id of the user whose forums will be returned
     *
     *
     * return int id of post or false
     */
    public static function  get_coursemodule_choice($coursemoduleid) {

        global $CFG, $DB;

        $params = self::validate_parameters(self::get_coursemodule_choice_parameters(), array('coursemoduleid' => $coursemoduleid));

        require_once($CFG->dirroot . '/mod/choice/lib.php');

        $cm = $DB->get_record('course_modules', array('id' => $coursemoduleid));

        $choice = array();

        if (!empty($cm)) {

            $choicerecord = choice_get_choice($cm->instance);

            if (!empty($choicerecord)) {
                $c = new   stdClass();
                $c->id = $cm->instance;
                $c->name = $choicerecord->name;
                $c->intro = $choicerecord->intro;
                $c->timeavailable = $choicerecord->timeopen;

                $choice = (array)$c;
            }
        }

        return $choice;
    }

    /**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function get_coursemodule_choice_parameters() {
        return new external_function_parameters(
            array(
                'coursemoduleid' => new external_value(PARAM_INT, 'course module id'),
            )
        );
    }

    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function get_coursemodule_choice_returns() {
        return new external_single_structure(
            array(
                'id' => new external_value(PARAM_INT, 'id'),
                'name' => new external_value(PARAM_TEXT, 'name of choice'),
                'intro' => new external_value(PARAM_RAW, 'intro'),
                'timeavailable' => new external_value(PARAM_INT, 'timeavailable'),
            )
        );
    }

    /**
     * @static returns a list of options for the choice with the given if
     * @param int $choiceid the id of the choice whose options will be returned
     *
     * return array  of options or false
     * @return array
     */
    public static function  get_choice_options($choiceid) {

        global $CFG, $DB;

        $params = self::validate_parameters(self::get_choice_options_parameters(), array('choiceid' => $choiceid));

        require_once($CFG->dirroot . '/mod/choice/lib.php');
        $choiceoptions = $DB->get_records("choice_options", array("choiceid" => $choiceid));
        $options = array();

        if (!empty($choiceoptions)) {
            foreach ($choiceoptions as $op) {
                $opt = new stdClass();
                $opt->id = $op->id;
                $opt->option = $op->text;
                $opt->maxanswers = $op->maxanswers;
                $count = $DB->get_records('choice_answers', array('choiceid' => $choiceid, 'optionid' => $op->id));
                $opt->count = (!empty($count)) ? $count : 0;
                $options[] = (array)$opt;
            }
        }

        return $options;
    }


    /**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function get_choice_options_parameters() {
        return new external_function_parameters(
            array(
                'choiceid' => new external_value(PARAM_INT, 'choice id'),
            )
        );
    }

    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function get_choice_options_returns() {
        return new external_multiple_structure(
            new external_single_structure(
                array(
                    'id' => new external_value(PARAM_INT, 'id'),
                    'option' => new external_value(PARAM_RAW, 'the option'),
                    'maxanswers' => new external_value(PARAM_INT, 'max amount of answers for this option'),
                    'count' => new external_value(PARAM_INT, 'count of responses'),
                )
            ), 'List of options for the choice'
        );
    }


    /**
     * @static submits a user response to a choice
     * @param int $optionid the id of option selected by the user
     * @param int $coursemoduleid id of the coursemodule relating to the  choice record
     * @param int $userid the id of the user who is making the choice
     *
     * return array  of options or false
     */
    public static function  user_choice_repsonse($optionid, $coursemoduleid, $userid = null) {
        global $CFG, $DB, $USER;
        // If user id is empty pass the global user id.
        $userid = (empty($userid)) ? $USER->id : $userid;
        $params = self::validate_parameters(self::user_choice_repsonse_parameters(), array('optionid' => $optionid,
            'coursemoduleid' => $coursemoduleid, 'userid' => $userid));
        require_once($CFG->dirroot . '/mod/choice/lib.php');
        $cm = $DB->get_record("course_modules", array("id" => $coursemoduleid));
        if (!empty($cm)) {
            $choice = $DB->get_record("choice", array("id" => $cm->instance));
            $course = $DB->get_record("course", array("id" => $cm->course));
            if (!empty($choice) && !empty($course)) {
                /* @var $test  */
                $test = choice_user_submit_response($optionid, $choice, $userid, $course, $cm);
            }
        }
    }


    /**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function user_choice_repsonse_parameters() {
        return new external_function_parameters(
            array(
                'optionid' => new external_value(PARAM_INT, 'option id'),
                'coursemoduleid' => new external_value(PARAM_INT, 'course module id'),
                'userid' => new external_value(PARAM_INT, 'user id'),
            )
        );
    }


    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function user_choice_repsonse_returns() {
        return null;
    }

    public static function  get_users_courses($userid = null) {
        global $USER;
        /* @var $userid  */
        /* @var $USER  */
        $userid = (empty($userid)) ? $USER->id : $userid;
        $my_courses = enrol_get_users_courses($userid, false, 'id, fullname');
        $usercourses = array();
        if (!empty($my_courses)) {
            foreach ($my_courses as $course) {
                $usercourses[] = (array)$course;
            }
        }
        return $usercourses;
    }

    /**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function get_users_courses_parameters() {
        return new external_function_parameters(
            array(

                'userid' => new external_value(PARAM_INT, 'User ID')

            )
        );
    }

    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function get_users_courses_returns() {
        return new external_multiple_structure(
            new external_single_structure(
                array(
                    'id' => new external_value(PARAM_INT, 'course id'),

                    'fullname' => new external_value(PARAM_TEXT, 'course full name'),

                )
            ), 'List of assignments the a user has been set in their various courses.'
        );
    }

}