# This file contains a complete database schema for all the 
# tables used by this module, written in SQL

# It may also contain INSERT statements for particular data 
# that may be used, especially new entries in the table log_display

# --------------------------------------------------------

#
# Table structure for table `prefix_block_library_search`
#

CREATE TABLE prefix_block_library_search (
  `id` int(11) NOT NULL auto_increment,
  `linktext` varchar(255) NOT NULL default '',
  `url` varchar(255) NOT NULL default '',
  `notes` text,
  `defaultshow` int NOT NULL default 1,
  PRIMARY KEY  (`id`)
);

INSERT INTO `mdl_block_library_search` VALUES (1, 'Library Catalogue', 'http://library.ucl.ac.uk/F?func=find-b&request=%s&find_code=WRD','',1);
INSERT INTO `mdl_block_library_search` VALUES (2, 'Metalib: General Search', 'http://metalib-a.lib.ucl.ac.uk:8331/V/?func=meta-1-check&mode=simple&find_request_1=%s&ckbox=UCL00688&ckbox=UCL00331&ckbox=UCL00730&ckbox=UCL00953&ckbox=UCL01087&ckbox=UCL00887','',1);
INSERT INTO `mdl_block_library_search` VALUES (3, 'Google Scholar', 'http://scholar.google.com/scholar?q=%s','',1);