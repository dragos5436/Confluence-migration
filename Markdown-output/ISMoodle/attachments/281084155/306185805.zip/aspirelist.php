<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from https://moodle.ucl.ac.uk
 *
 * @package    mod
 * @subpackage aspirelist
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['modulename'] = 'Reading List items';
$string['modulename_help'] = 'Reading List Items enables a teacher to select items from the ReadingLists@UCL list associated with the Moodle course, and display those directly within a section in that course. This helps to contextualise readings within the module.

The available Reading List must share the Portico Identifier entered in the settings of the Moodle course.

Please note: Reading List Items must be updated each year after the Library rolls over the service in summer, otherwise they continue to refer to the previous year\'s list.

Guidance at https://wiki.ucl.ac.uk/x/OxUVAw.';
$string['modulenameplural'] = 'Reading List items';
$string['noconnection'] = 'Unfortunately the UCL Reading Lists website is currently unavailable. Please try again later.';
$string['pluginadministration'] = 'Reading List items administration';
$string['pluginname'] = 'Reading List items';
