.submittoLink {
	display: block;
    border: 0px solid red;
	margin: 4px 0px 0px 0px;
    padding: 0px 0px 0px 0px;
}
.submittoLinkSmall {
	display: block;
    border: 0px solid red;
	margin: 0px 0px 0px 0px;
    padding: 0px 0px 0px 0px;
}
.submittoLinkSmall img,
.submittoLink img {
	vertical-align: middle;
    margin: 0px 5px 0px 0px;
}
.origLink {
}
.tii_nameGrey {
	color: #777777;
}
.origLink a.scoreLink {
	vertical-align: middle;
	display: inline-block;
    width: 50px;
    text-align: center;
	border: 1px solid black;
    padding: 0px;
    font-size: 11px;
    line-height: 14px;
    text-decoration: none;
    color: black;
}
.origLink a.refreshLink {
	margin-left: 3px;
    border: 0px solid #AAA;
}
.origLink .scoreBox {
	padding: 0px 14px 0px 0px;
}
.gradeTable .c1 div.student,
.gradeTable .c2 div.student,
.gradeTable .c3 div.student,
.gradeTable .c4 div.student,
.gradeTable .c5 div.student,
.gradeTable .c6 div.student {
	white-space: nowrap;
	border-width: 0px;
    border-style: solid;
    border-color: #DDDDDD;
}
.gradeTable td {
    background-color: #FFFFFF;
}
.gradeTable td.c0 div.student {
	border-width: 0px;
    border-style: solid;
    border-color: #FFFFFF;
}
.gradeTable .r0 div.student,
.gradeTable .r1 div.student {
	background-color: #F9F9F9;
    margin: 0px;
    padding: 4px;
    line-height: 1.6em;
    height: inherit;
    min-height: 100%;
}
.gradeTable div.submission {
	background-color: #FFFFFF;
    margin: 0px;
    border-bottom: 0px solid #EEEEEE;
	padding: 3px 4px 4px 4px;
    line-height: 1.4;
    height: inherit;
    min-height: 100%;
}
.gradeTable td.cell img.tiiicons {
	height: inherit;
    width: inherit;
}
.gradeTable img.plusminus {
	margin: 0px 1px 0px 1px;
    width: 9px;
    height: 9px;
}
.gradeTable td {
    border: 1px solid #DDDDDD;
    line-height: 0.1em;
}
.gradeTable .r0 td.c1 div,
.gradeTable .r1 td.c1 div {
	white-space: nowrap;
}
.gradeTable .r0 td.c2 div,
.gradeTable .r1 td.c2 div {
	white-space: nowrap;
}
.gradeTable .r0 td.c3 div,
.gradeTable .r1 td.c3 div {
	white-space: nowrap;
    color: #666666;
}

.gradeTable .r0 td.c4 div,
.gradeTable .r1 td.c4 div {
	white-space: nowrap;
}

.gradeTable .r0 td.c5 div,
.gradeTable .r1 td.c5 div {
	white-space: nowrap;
}

.gradeTable .r0 td.c6 div,
.gradeTable .r1 td.c6 div {
	white-space: nowrap;
}

.gradeTable .r0 td.c1 div.student,
.gradeTable .r1 td.c1 div.student {
}
.gradeTable .r0 td.c2 div.student,
.gradeTable .r1 td.c2 div.student {
}
.gradeTable .r0 td.c3 div.student,
.gradeTable .r1 td.c3 div.student {
    color: black;
}
.gradeTable .r0 td.c4 div.student,
.gradeTable .r1 td.c4 div.student {
}
.gradeTable .r0 td.c5 div.student,
.gradeTable .r1 td.c5 div.student {
}
.gradeTable .r0 td.c6 div.student,
.gradeTable .r1 td.c6 div.student {
}
.gradeTable .c0 img {
	position: relative;
    margin-bottom: 0px;
    top: 0px;
}
.tiiicons {
	position: relative;
    margin-bottom: -5px;
    top: 0px;
}
.gradeTable .r0 .c1,
.gradeTable .r0 .c2,
.gradeTable .r0 .c3,
.gradeTable .r0 .c4,
.gradeTable .r0 .c5,
.gradeTable .r0 .c6 {
	border-width: 1px;
    border-style: solid;
    border-color: #DDDDDD;
    vertical-align: middle;
}
.gradeTable .r1 .c1,
.gradeTable .r1 .c2,
.gradeTable .r1 .c3,
.gradeTable .r1 .c4,
.gradeTable .r1 .c5,
.gradeTable .r1 .c6 {
	border-width: 1px;
    border-style: solid;
    border-color: #DDDDDD;
    vertical-align: middle;
}
.gradeTable th {
    border-width: 1px 1px 1px 1px;
    border-style: solid;
    border-color: #DDDDDD #DDDDDD #AAAAAA #DDDDDD;
    line-height: 1.3em;
    padding: 4px;
    white-space: nowrap;
}
.gradeTable {
    border: 1px solid #AAAAAA;
	font-size: 0.9em;
    line-height: 0.1em;
}
.uploadtable form,
.gradeTable form {
	display: inline;
}
.gradeTable .student .gradebox {
	text-align: right;
    width: 2em;
    border: 0px solid white;
    background-color: #F4F4F4;
    color: black;
}
.gradeTable .gradebox,
.submissionTable .gradebox {
	padding: 1px;
	text-align: right;
    width: 2em;
}
.submissionTable {
	font-size: 0.9em;
}
.submissionTable tr.r0 td {
	background-color: #FAFAFA;
}
.submissionTable tr.r1 td {
	background-color: #F8F8F8;
}
.submissionTable td {
    border: 1px solid #DDDDDD;
    line-height: 1.6em;
    vertical-align: middle;
}
.submissionTable td.c0,
.submissionTable th {
    border: 1px solid #DDDDDD;
    vertical-align: top;
}
.submissionTable td.c0 input {
	width: 98%;
}
.submissionTable td.c4 input {
	text-align: center;
	width: 85%;
}
.submissionTable tr.r0 td.c2,
.submissionTable tr.r0 td.c4,
.submissionTable tr.r0 td.c6 {
	background-color: #FAFAFA;
    line-height: 1;
}
.submissionTable tr.r0 td.c1,
.submissionTable tr.r0 td.c3,
.submissionTable tr.r0 td.c5 {
	background-color: #F4F4F4;
    line-height: 1;
}
.submissionTable tr.r1 td.c2,
.submissionTable tr.r1 td.c4,
.submissionTable tr.r1 td.c6 {
	background-color: #F8F8F8;
    line-height: 1;
}
.submissionTable tr.r1 td.c1,
.submissionTable tr.r1 td.c3,
.submissionTable tr.r1 td.c5 {
	background-color: #F1F1F1;
    line-height: 1;
}
.submissionTable td.cell img.tiiicons {
	height: inherit;
    width: inherit;
    position: relative;
}
.submissionTable .error {
	border: 1px solid red;
}
.submissionText {
	height: 140px;
	width: 80%;
    font-family: inherit;
   	font-size: 85%;
}
.centertext {
	text-align: center;
}
.partsTable {
	margin: 8px 0px 0px 0px;
}
.partsTable td {
	background-color: #FFFFFF;
    border: 1px solid #EEEEEE;
}
.partsTable .c0 {
	font-weight: bold;
	background-color: #F3F3F3;
}
.uploadtable {
	margin: 8px 0px 0px 0px;
}
.uploadtable input.formwide,
.uploadtable select.formwide {
	width: 55%;
}
.uploadtable td {
	background-color: #FFFFFF;
}
.uploadtable td p {
	margin: 0px 0px 0px 0px;
    padding: 0px 0px 14px 0px;
}
.uploadtable .c0 {
	font-weight: bold;
	background-color: #F3F3F3;
}
.uploadtable .c0 img.iconhelp {
	vertical-align: middle;
    position: relative;
    top: -0.2em;
    margin-left: 5px;
}
.partForm {
	display: inline;
}
.partsTable .partField {
	width: 65%;
}
.partsTable .weightField {
	width: 10%;
}
.partsTable .percentField {
	width: 10%;
    border: 0px solid white;
}
.partsTable .weightBlock {
	margin: 0px;
    padding: 0px 0px 10px 0px;
}
.eightyfive {
	width: 85%;
}
#notes {
	margin: 0px auto 12px auto;
}
.tabtree {
	border-width: 0px 0px 1px 0px;
    border-style: solid;
    border-color: #DDDDDD;
    margin: 0px 0px 1.75em 0px;
}
.tabtree .tabrow0 {
	border-width: 0px 0px 1px 0px;
    border-style: solid;
    border-color: #000000;
    padding: 0px 0px 1px 0px;
    margin: 0px;
}
.tabtree .tabrow1 {
	display: none;
}
.commentBlock {
	font-size: 95%;
}
.commentLeft {
	margin: 0px 0px 5px 0px;
	float: left;
}
.commentRight {
	margin: 0px 0px 5px 0px;
	float: right;
}
.commentBottom .editNotice {
	text-align: center;
    display: block;
    padding: 5px 0px 0px 0px;
    font-style: oblique;
    color: #AAAAAA;
}
.commentRule {
	clear: both;
}
.clearBlock {
	position: relative;
    top: -1px;
	clear: both;
    font-size: 1px;
    line-height: 0;
    margin: 0px 0px -1px 0px;
}
.commentComments {
	
}
.commentButtons {
	padding: 10px 0px 10px 0px;
    text-align: right;
}
.commentButtons form {
	display: inline;
}
.toplinkTabs {
    margin: 0 auto 0 auto;
    width: 85%;
    padding: 0px;
    border: 0px solid black;
    height: 36px;
}
.toggleLinks {
	width: 50%;
	padding: 0px 0px 5px 0px;
    font-size: 0.9em;
    line-height: 1;
}
.tabLinks {
	white-space: nowrap;
	padding: 0 10px 0 0;
}
.tabLinks ul {
	margin: 0px;
    font-size: 0;
}
.tabLinks ul li {
    font-size: small;
}
.tabRowModified {
	text-align: right;
    margin: 0 10px 0 0;
    padding: 0px 0px 2px 0px;
}