<?php // $Id: index.php,v 1.7 2007/09/03 12:23:36 jamiesensei Exp $
/**
 * This page lists all the instances of turnitintool in a particular course
 *
 * @author
 * @version $Id: index.php,v 1.7 2007/09/03 12:23:36 jamiesensei Exp $
 * @package newmodule
 **/

    require_once("../../config.php");
    require_once("lib.php");

	$id = required_param('id', PARAM_INT);   // course

    if (! $course = turnitintool_get_record("course", "id", $id)) {
        turnitintool_print_error('courseiderror','turnitintool');
    }

    require_login($course->id);

    add_to_log($course->id, "turnitintool", "view all", "index.php?id=$course->id", "");


/// Get all required stringsnewmodule

    $strturnitintools = get_string("modulenameplural", "turnitintool");
    $strturnitintool  = get_string("modulename", "turnitintool");

    //if (!is_callable('build_navigation')) {
		//$navigation = '';
	//} else {
		//$navigation = build_navigation(array());
	//}

	/// Print the header
	
	turnitintool_header(NULL,$course,$_SERVER["REQUEST_URI"],$strturnitintools, $SITE->fullname, '', '', '', true, '', '');

	//print_header_simple($strturnitintools, '', $navigation, "", "", true, "", navmenu($course));
	
	

/// Get all the appropriate data

    if (! $turnitintools = get_all_instances_in_course("turnitintool", $course)) {
        notice("There are no ".$strturnitintools, "../../course/view.php?id=$course->id");
        die;
    }

/// Print the list of instances (your module will probably extend this)

    $timenow = time();
    $strname  = get_string("name");
    $strweek  = get_string("week");
    $strtopic  = get_string("topic");

    if ($course->format == "weeks") {
        $table->head  = array ($strweek, $strname);
        $table->align = array ("center", "left");
    } else if ($course->format == "topics") {
        $table->head  = array ($strtopic, $strname);
        $table->align = array ("center", "left", "left", "left");
    } else {
        $table->head  = array ($strname);
        $table->align = array ("left", "left", "left");
    }
	$table->class='';

    foreach ($turnitintools as $turnitintool) {
        if (!$turnitintool->visible) {
            //Show dimmed if the mod is hidden
            $link = "<a class=\"dimmed\" href=\"view.php?id=$turnitintool->coursemodule\">$turnitintool->name</a>";
        } else {
            //Show normal if the mod is visible
            $link = "<a href=\"view.php?id=$turnitintool->coursemodule\">$turnitintool->name</a>";
        }

        if ($course->format == "weeks" or $course->format == "topics") {
            $table->data[] = array ($turnitintool->section, $link);
        } else {
            $table->data[] = array ($link);
        }
    }

    echo "<br />";

    turnitintool_print_table($table);

/// Finish the page

    turnitintool_footer($course);

?>
