<?php // $Id: block_library_resources.php,v 1.1 2006/06/13 queendido Exp $ 

$string['actions'] = 'Actions';
$string['addlink'] = 'Add a Search Engine';
$string['blockname'] = 'Library Search';
$string['defaultshow'] = 'Show by default';
$string['delete'] = 'Delete';
$string['display'] = 'Display';
$string['links'] = 'Search Engines';
$string['linktext'] = 'Search Engine Name';
$string['manage_links'] = 'Add/Edit Search Engines';
$string['modify'] = 'Edit';
$string['no'] = 'No';
$string['none'] = 'There are no items to display';
$string['notes'] = 'Additional text';
$string['reference'] = 'Reference';
$string['title_label'] = 'Title:';
$string['url'] = 'URL';
$string['yes'] = 'Yes';

?>
