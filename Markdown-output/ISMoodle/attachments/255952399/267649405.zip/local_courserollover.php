<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from https://moodle.ucl.ac.uk
 *
 * @package    local
 * @subpackage courserollover
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['editcurrentmappings'] = '(Edit current alignments)';
$string['email:content'] = 'Your course rollover for {$a->oldname} is now complete. <br>You can find the new course here: <a href="{$a->link}">{$a->newname}</a><br><br>You can now adjust all of the course dates & deadlines through the course\'s <a href="{$a->datemanager}">Date Manager</a>. <br>Review the <a href="https://wiki.ucl.ac.uk/x/9adBD"> guidance on what to do next</a> to prepare your course for next academic year.<br><br>
If you require additional support please contact <a href="mailto:digi-ed@ucl.ac.uk">digi-ed@ucl.ac.uk</a> with any questions.';
$string['error:nomappings'] = 'No alignments found. Rollover cannot continue';
$string['heading:currentmappings'] = 'Current alignments';
$string['heading:suggestedmappings'] = 'Suggested delivery alignments';
$string['mapping:fail'] = 'Error: Unable to align {$a->mapping} to {$a->course}';
$string['mapping:success'] = 'Aligned {$a->mapping} to {$a->course}';
$string['mappings'] = 'Alignments with Portico deliveries';
$string['mappings:current:info'] = 'The current course is aligned to the following Portico deliveries:';
$string['mappings:info'] = 'These alignments will be used to automatically create enrolment Mappings for the rolled over course. However, those enrolment mappings will not be activated. Enrolment Mappings can be activated after rollover has completed, through the Portico block on the new course (No enrolments will occur until mappings are manually activated).';
$string['mappings:new:info'] = 'Is the rolled-over course delivering the content for these alignments? (If Miscellaneous/Supplementary, is this the audience for your course?)';
$string['mappings:new:info:icon'] = 'If you are happy with the suggested alignment/s, please click on \'Next\'. If you would like to change the suggested alignment/s, please remove them by clicking on the \'bin\' icon and then search for the relevant module by entering the code into the \'Search\' box...';
$string['mappings:none'] = 'No alignments found';
$string['mappings:select'] = 'Select different alignments';
$string['newmappings'] = 'New alignments';
$string['nocurrentmappings'] = 'No alignments found, please search for and select a delivery (module/programme/route) to align to, in order to proceed with the rollover';
$string['nomappings'] = 'No Portico delivery alignments found';
$string['searchmappings'] = 'Search for other alignments:';
$string['suggestedmappings'] = 'Suggested delivery alignments';
