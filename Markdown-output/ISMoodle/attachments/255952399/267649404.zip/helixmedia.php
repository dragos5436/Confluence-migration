<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from https://4-demo.preview-moodle.ucl.ac.uk
 *
 * @package    mod
 * @subpackage helixmedia
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['consumer_key'] = 'MediaCentral Consumer Key';
$string['consumer_key2'] = 'The consumer key used for access to the MediaCentral LTI server.';
$string['helixmedia:addinstance'] = 'Add a new MediaCentral Resource';
$string['helixmedia:manage'] = 'Manage MediaCentral Resources';
$string['helixmedia:view'] = 'View MediaCentral Resources';
$string['hml_in_new_window'] = 'Open MediaCentral Resource';
$string['invalid_launch'] = 'Invalid parameters supplied for MediaCentral LTI launch request. Aborting.';
$string['launch_url'] = 'MediaCentral LTI Launch URL';
$string['launch_url2'] = 'Put the LTI launch URL of the MediaCentral server here. This should be a URL in the format: https://upload.mymedialserver.org/Lti/Launch';
$string['log_launch'] = 'MediaCentral LTI Launch';
$string['log_launchedit'] = 'MediaCentral LTI Edit Launch';
$string['log_launcheditnew'] = 'MediaCentral LTI New Instance Edit Launch';
$string['migrate_found'] = 'All the URL modules linked to active MediaCentral Repository instances are listed below:';
$string['migrate_no_repo_mod'] = 'WARNING: The MediaCentral Repository module is not installed, this is necessary in order to perform the migration process. Please install and configure the Repository module first.';
$string['migrate_not_found'] = 'The following URL modules are linked to inactive MediaCentral instances:';
$string['migrate_not_found_3'] = 'The above content can still be migrated to the new activity module, but this process will only work if the currently installed repository module is still connecting to the same MediaCentral installation which was used by the earlier inactive installations.';
$string['modulename'] = 'Media Resource';
$string['modulename_help'] = '"The Media Resource module provides a method of adding media content securely to a course via integration with UCL media servers.
<br>
<a href=""https://www.ucl.ac.uk/mediacentral/moodle"" target=""_blank"">UCL help pages</a>"';
$string['modulenameplural'] = 'MediaCentral';
$string['modulenamepluralformatted'] = 'MediaCentral Instances';
$string['nohelixmedias'] = 'No MediaCentral Instances found.';
$string['not_authorised'] = 'You are not authorised to perform this MediaCentral operation.';
$string['org_id2'] = 'The organisation ID or name which will be sent to the MediaCentral server. The URL of your MediaCentral installation will be sent if this is left blank.';
$string['pluginadministration'] = 'MediaCentral';
$string['pluginname'] = 'MediaCentral';
$string['repo_migrate_message'] = 'The repository module migration tool will convert content that was created using the MediaCentral repository module so that it uses this activity module instead. Use the link below to start the migration process.';
$string['shared_secret'] = 'MediaCentral Shared Secret';
$string['shared_secret2'] = 'The shared secret used for comunications between Moodle and the MediaCentral server via LTI.';
