Requires Moodle 
   $version = 2007101509;  
   $release = '1.9 + (Build: 20080305)';   // Human-friendly version name


The following core moodle files have been modified.

lib/moodlelib.php
course/lib.php
course/format/topics/format.php
course/format/weeks/format.php
BEFORE doing anything, make a backup copy of these files.

Installation:

Put all of the files from the zip in their appropriate moodle folders.
Put the activity_locking folder in your blocks folder.
Click on the Admin Notifications link to install the block--this will also install all of the appropriate database tables--this is an outdated file, so you will see a notice about that--just ignore it.

With editing turned on, you will see a lock icon after your activities, click it and have fun!

Note:  the editing icons will disappear if you have Ajax enabled in your courses.
Activities on your front page won't lock without a hack to your index.php file to require the locklib.php file.
