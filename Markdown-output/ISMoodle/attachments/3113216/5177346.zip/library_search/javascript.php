   function submitaction(action, linkid) {
        document.forms[0].action.value = action;
        document.forms[0].linkid.value = linkid;
        document.forms[0].submit();
    }        
