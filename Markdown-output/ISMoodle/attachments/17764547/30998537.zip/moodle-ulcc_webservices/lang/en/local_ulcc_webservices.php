<?php
/**
 * Local ulcc web services language files
 *
 * @copyright &copy; 2011 University of London Computer Centre
 * @author http://www.ulcc.ac.uk, http://moodle.ulcc.ac.uk
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package ULCC_webservices
 * @version 1.0
 */

$string['pluginname'] = 'ULCC Webservices';