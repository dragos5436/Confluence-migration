<?php 

    require_once('../../config.php');

    $courseid = optional_param('courseid', PARAM_INT); // courseid            
    $search = trim(optional_param('search', '', PARAM_NOTAGS));  // search string 
    $engine = optional_param('engine', 0, PARAM_INT);
    $link = get_record('block_library_search','id',$engine);
    
    $to = str_replace('%s',urlencode($search),$link->url);
        
    // print_header();
    
    redirect($to);


?>