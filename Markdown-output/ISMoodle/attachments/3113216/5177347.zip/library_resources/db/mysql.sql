# This file contains a complete database schema for all the 
# tables used by this module, written in SQL

# It may also contain INSERT statements for particular data 
# that may be used, especially new entries in the table log_display

# --------------------------------------------------------

#
# Table structure for table `prefix_block_library_resources`
#

CREATE TABLE prefix_block_library_resources (
 `id` int(11) NOT NULL auto_increment,
 `linktext` varchar(50) NOT NULL default '',
 `url` varchar(255) NOT NULL default '',
 `notes` varchar(100) NOT NULL default '',
 `defaultshow` int NOT NULL default 1,
 `context` int NOT NULL default 1,
 PRIMARY KEY  (`id`)
);

#CREATE TABLE `rhul_lib_liaison` (
#`id` INT( 10 ) NOT NULL AUTO_INCREMENT ,
#`name` VARCHAR( 255 ) NOT NULL ,
#`staffdbid` INT NOT NULL ,
#PRIMARY KEY ( `id` ) ,
#INDEX ( `staffdbid` )
#);

#CREATE TABLE `rhul_lib_liaison_subject` (
#`category` INT NOT NULL ,
#`librarian` INT,
#PRIMARY KEY ( `category` , `librarian` )
#);

--
-- Dumping data for table `mdl_block_library_resources`
--

INSERT INTO `mdl_block_library_resources` (`id`, `linktext`, `url`, `notes`, `defaultshow`, `context`) VALUES
(1, 'Reading List', 'http://ls-tlss.ucl.ac.uk/cgi-bin/displaylist?module=08%s', '', 1, 2),
(2, 'Past UCL Exam Papers', 'http://digitool-a.lib.ucl.ac.uk:8881/R?func=search-advanced-go&LOCAL_BASE=1152&find_code1=WRD&request1=%s', '', 1, 2),
(3, 'UCL Library Catalogue', 'http://library.ucl.ac.uk', '', 1, 1),
(4, 'Metalib', 'http://metalib-a.lib.ucl.ac.uk:8331/V', '', 1, 1),
(5, 'UCL Subject Librarians', 'http://www.ucl.ac.uk/Library/whoaz.shtml', '', 1, 1);