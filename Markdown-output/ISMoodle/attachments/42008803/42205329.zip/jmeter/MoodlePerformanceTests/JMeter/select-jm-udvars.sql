/**
* Generate User-defined variables for JMeter performance test-plans.
**/

/**
* 1/. Comma-delimited (preferred): Export to a .csv file for use by a JMeter
*     'Variables From CSV File' config element.
* Example output:-
* CID_PTEST-01;197
* FCMID_PTEST-Forum-001;1664
* FID_PTEST-Forum-001;148
* QCMID_PTEST-Quiz-001;1678
* RCMID_PTEST-Assignment-001;1645
* RCMID_PTEST-Assignment-002;1646
* RCMID_PTEST-PDF-001;1685
* RCMID_PTEST-PDF-002;1686
* RCMID_PTEST-PDF-003;1687
* RPID_UPLOAD;3
**/
-- Course IDs (PTEST-nn)
SELECT
  concat('CID_', c.shortname, ';', c.id) AS jm_udvars
FROM mdl_course c
WHERE c.shortname REGEXP '^PTEST-[[:digit:]]{2}'
UNION ALL
-- Forum CMID/IDs (course 'PTEST-01')
SELECT
    concat(
        concat('FCMID_', f.`name`, ';', cm.id)
    ,   '\n'
    ,   concat('FID_', f.`name`, ';', f.id)
    ) AS jm_udvars
FROM mdl_forum f
    INNER JOIN mdl_course_modules cm
        ON cm.`instance` = f.id
    INNER JOIN mdl_course c
        ON f.course = c.id AND cm.course = c.id
WHERE f.`name` = 'PTEST-Forum-001'
AND c.shortname = 'PTEST-01'
UNION ALL
-- Quiz CMIDs (course 'PTEST-01')
SELECT
    concat('QCMID_', q.`name`, ';', cm.id) AS jm_udvars
FROM mdl_quiz q
    INNER JOIN mdl_course_modules cm
        ON cm.`instance` = q.id
    INNER JOIN mdl_course c
        ON q.course = c.id AND cm.course = c.id
WHERE q.`name` = 'PTEST-Quiz-001'
AND c.shortname = 'PTEST-01'
UNION ALL
-- Resource file CMIDs (course 'PTEST-01')
SELECT
    concat('RCMID_', r.`name`, ';', cm.id) AS jm_udvars
FROM mdl_resource r
    INNER JOIN mdl_course_modules cm
        ON cm.`instance` = r.id
    INNER JOIN mdl_course c
        ON r.course = c.id AND cm.course = c.id
WHERE r.`name` REGEXP 'PTEST-PDF-[[:digit:]]{2}'
AND c.shortname = 'PTEST-01'
UNION ALL
-- Assignment CMIDs (course 'PTEST-01')
SELECT
    concat('RCMID_', a.`name`, ';', cm.id) AS jm_udvars
FROM mdl_assign a
    INNER JOIN mdl_course_modules cm
        ON cm.`instance` = a.id
    INNER JOIN mdl_course c
        ON a.course = c.id AND cm.course = c.id
WHERE a.`name` REGEXP 'PTEST-Assignment-[[:digit:]]{2}'
AND c.shortname = 'PTEST-01'
UNION ALL
SELECT
    concat('RPID_UPLOAD', ';', rp.id) AS jm_udvars
FROM mdl_repository rp
WHERE rp.`type` = 'upload'
ORDER BY jm_udvars;


-- Or, alternatively...


/**
* 2/. Tab-delimited: Export and add to the appropriate 'User Defined Variables'
*     config element within JMeter by copying and using the 'Add from Clipboard'
*     button.
**/
SELECT '\n-- Testplan global:-\n' AS jm_udvars
UNION ALL
-- Course IDs (PTEST-nn)
SELECT
  concat('CID_', c.shortname, '\t', c.id, '\t', 'CID - Course ''', c.shortname, '''') AS jm_udvars
FROM mdl_course c
WHERE c.shortname REGEXP 'PTEST-[[:digit:]]{2}'
UNION ALL
SELECT '\n-- Scenario 01: Forum post:-\n' AS jm_udvars
UNION ALL
-- Forum CMID/IDs (course 'PTEST-01')
SELECT
    concat(
        concat('FCMID_', f.`name`, '\t', cm.id, '\t', 'CMID - Forum ''', f.`name`, ''', course ''', c.shortname, '''')
    ,   '\n'
    ,   concat('FID_', f.`name`, '\t', f.id, '\t', 'ID - Forum ''', f.`name`, ''', course ''', c.shortname, '''')
    ) AS jm_udvars
FROM mdl_forum f
    INNER JOIN mdl_course_modules cm
        ON cm.`instance` = f.id
    INNER JOIN mdl_course c
        ON f.course = c.id AND cm.course = c.id
WHERE f.`name` = 'PTEST-Forum-001'
AND c.shortname = 'PTEST-01'
UNION ALL
SELECT '\n-- Scenario 02: Quiz:-\n' AS jm_udvars
UNION ALL
-- Quiz CMIDs (course 'PTEST-01')
SELECT
    concat('QCMID_', q.`name`, '\t', cm.id, '\t', 'CMID - Quiz ''', q.`name`, ''', course ''', c.shortname, '''') AS jm_udvars
FROM mdl_quiz q
    INNER JOIN mdl_course_modules cm
        ON cm.`instance` = q.id
    INNER JOIN mdl_course c
        ON q.course = c.id AND cm.course = c.id
WHERE q.`name` = 'PTEST-Quiz-001'
AND c.shortname = 'PTEST-01'
UNION ALL
SELECT '\n-- Scenario 03: Resource file download:-\n' AS jm_udvars
UNION ALL
-- Resource file CMIDs (course 'PTEST-01')
SELECT
    concat('RCMID_', r.`name`, '\t', cm.id, '\t', 'CMID - Resource file ''', r.`name`, ''', course ''', c.shortname, '''') AS jm_udvars
FROM mdl_resource r
    INNER JOIN mdl_course_modules cm
        ON cm.`instance` = r.id
    INNER JOIN mdl_course c
        ON r.course = c.id AND cm.course = c.id
WHERE r.`name` REGEXP 'PTEST-PDF-[[:digit:]]{2}'
AND c.shortname = 'PTEST-01'
UNION ALL
SELECT '\n-- Scenario 03: Assignment submission:-\n' AS jm_udvars
UNION ALL
-- Assignment CMIDs (course 'PTEST-01')
SELECT
    concat('RCMID_', a.`name`, '\t', cm.id, '\t', 'CMID - Assignment ''', a.`name`, ''', course ''', c.shortname, '''') AS jm_udvars
FROM mdl_assign a
    INNER JOIN mdl_course_modules cm
        ON cm.`instance` = a.id
    INNER JOIN mdl_course c
        ON a.course = c.id AND cm.course = c.id
WHERE a.`name` REGEXP 'PTEST-Assignment-[[:digit:]]{2}'
AND c.shortname = 'PTEST-01'
UNION ALL
SELECT
    concat('RPID_UPLOAD', '\t', rp.id, '\t', 'Repository ID - Assignment upload')
FROM mdl_repository rp
WHERE rp.`type` = 'upload';
