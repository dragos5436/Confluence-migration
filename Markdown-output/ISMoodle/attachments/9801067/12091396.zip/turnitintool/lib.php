<?php  
define('TII_ENCRYPT',0);
define('TII_LATENCY_SLEEP',1); 
function turnitintool_add_instance($turnitintool) {
	global $USER, $CFG;
	$turnitintool->timecreated = time();
	$_QfloJ = new TIIToolClass;
	$_QflLo=($turnitintool->numparts*2)+2;
	if (!$course = turnitintool_get_record("course", "id", $turnitintool->course)) {
		turnitintool_print_error('coursegeterror','turnitintool',NULL,__FILE__,__LINE__);
		exit();
	}
	$_Q80iI=turnitintool_usersetup($USER,2,1,$_QflLo,get_string('userprocess','turnitintool')); 
	$_Q81OO=$_Q80iI->turnitin_uid;
	if (!turnitintool_is_owner($course->id)) {
		$owner=turnitintool_get_owner($course->id);
		if (is_null($owner)) {
			$owner=$USER;
		}
	} else {
		$owner=$USER;
	}
	$_Q81l6=turnitintool_classsetup($course,$owner,2,$_QflLo,get_string('classprocess','turnitintool')); 
	$_Q8Q6i=$_Q81l6->turnitin_cid;
	$turnitintool->timemodified=time();
	$turnitintool->dateformat="d/m/Y";
	$turnitintool->usegrademark=1;
	$turnitintool->gradedisplay=1;
	$turnitintool->autoupdates=1;
	$turnitintool->commentedittime=1800;
	$turnitintool->commentmaxsize=800;
	$turnitintool->autosubmission=1;
	$turnitintool->shownonsubmission=1;
	$_Q8Qft=turnitintool_insert_record("turnitintool", $turnitintool);
	$_Q8I6l=2;
	for ($_Q8ILi=1;$_Q8ILi<=$turnitintool->numparts;$_Q8ILi++) {
		$_Q8jIQ->courseid=$course->id;
		$_Q8jIQ->ctl=turnitintool_getCTL($course->id);
		$_Q8jIQ->dtstart=time(); 
		$_Q8jIQ->dtdue=strtotime('+7 days');
		$_Q8jIQ->dtpost=strtotime('+7 days');
		$_Q8jt8=strtoupper(uniqid());
		$_Q8jIQ->name=$turnitintool->name." - ".get_string('turnitinpart','turnitintool',$_Q8ILi)." (".$_Q8jt8.")";
		$_Q8jIQ->s_view_report=$turnitintool->studentreports;
		$_Q8jIQ->max_points=$turnitintool->grade;
		$_Q8jIQ->anon=$turnitintool->anon;
		$_Q8jIQ->report_gen_speed=$turnitintool->reportgenspeed;
		$_Q8jIQ->late_accept_flag=$turnitintool->allowlate;
		$_Q8jIQ->submit_papers_to=$turnitintool->submitpapersto;
		$_Q8jIQ->s_paper_check=$turnitintool->spapercheck;
		$_Q8jIQ->internet_check=$turnitintool->internetcheck;
		$_Q8jIQ->journal_check=$turnitintool->journalcheck;
		$_Q8jIQ->uid='';
		$_Q8jIQ->cid='';
		$_Q8jIQ->assignid='';
		$_Q8I6l++;
		$_Q8J1f = $_QfloJ->createAssignment($_Q8jIQ,'INSERT',$owner,$_Q8I6l,$_QflLo,get_string('assignmentprocess','turnitintool',$_Q8ILi)); 
		$_Q8Jii=$_QfloJ->getRcode($_Q8J1f);
		$_Q86oL=false;
		if (!empty($_Q8Jii) AND $_Q8Jii>100) {
			$_Q86oL=true;
			$_Q8ftf=$_QfloJ->getRmessage($_Q8J1f);
		} else if (empty($_Q8Jii)) {
			$_Q86oL=true;
			$_Q8ftf=get_string('apiunavailable','turnitintool');
		}
		if ($_Q86oL) {
			turnitintool_print_error('<strong>'.get_string('inserterror','turnitintool').'</strong><br />'.$_Q8ftf);
			exit();
		}
		$_Q8jIQ->uid=turnitintool_getUID($owner);
		$_Q8jIQ->cid=turnitintool_getCID($course->id);
		$_Q88j6->tiiassignid=$_QfloJ->getAssignid($_Q8J1f);
		$_Q8jIQ->assignid=$_Q88j6->tiiassignid;
		$_Q8jIQ->dtstart=$turnitintool->defaultdtstart;
		$_Q8jIQ->dtdue=$turnitintool->defaultdtdue;
		$_Q8jIQ->dtpost=$turnitintool->defaultdtpost;
		$_Q8jIQ->currentassign=$_Q8jIQ->name;
		$_Q8jIQ->name=str_replace(" (".$_Q8jt8.")"," (Moodle ".$_Q88j6->tiiassignid.")",$_Q8jIQ->name);
		$_Q8I6l++;
		$_Q8jIQ->ufn=$owner->firstname;
		$_Q8jIQ->uln=$owner->lastname;
		$_Q8jIQ->uem=$owner->email;
		$_Q8jIQ->assign=$_Q8jIQ->currentassign;
		$_Q8tj0=false;
		$_Q8to1=0;
		while (!$_Q8tj0 AND $_Q8to1<=10) {
			$_Q8to1++;
			$_Q8J1f=$_QfloJ->queryAssignment($_Q8jIQ,$_Q8I6l,$_QflLo,get_string('synchronisingturnitin','turnitintool'));
			$_Q8Jii=$_QfloJ->getRcode($_Q8J1f);
			if ($_Q8Jii<=100) {
				$_Q8tj0=true;
			}
		}
		$_Q8J1f = $_QfloJ->createAssignment($_Q8jIQ,'UPDATE',$owner,$_Q8I6l,$_QflLo,get_string('assignmentidividualise','turnitintool',$_Q8ILi)); 
		$_Q8Jii=$_QfloJ->getRcode($_Q8J1f);
		$_Q86oL=false;
		if (!empty($_Q8Jii) AND $_Q8Jii>100) {
			$_Q86oL=true;
			$_Q8ftf=$_QfloJ->getRmessage($_Q8J1f);
		} else if (empty($_Q8Jii)) {
			$_Q86oL=true;
			$_Q8ftf=get_string('apiunavailable','turnitintool');
		}
		if ($_Q86oL) {
			error('<strong>'.get_string('inserterror','turnitintool').'</strong><br />'.$_Q8ftf);
			exit();
		}
		$_Q88j6->turnitintoolid=$_Q8Qft;
		$_Q88j6->partname=get_string('turnitinpart','turnitintool',$_Q8ILi);
		$_Q88j6->dtstart=$turnitintool->defaultdtstart;
		$_Q88j6->dtdue=$turnitintool->defaultdtdue;
		$_Q88j6->dtpost=$turnitintool->defaultdtpost;
		$_Q88j6->maxmarks=$turnitintool->grade;
		$_Q88j6->deleted=0;
		if (!$_Q8OQf=turnitintool_insert_record('turnitintool_parts',$_Q88j6,false)) {
			turnitintool_print_error('partdberror','turnitintool',$_Q8ILi,__FILE__,__LINE__);
		}
		$_Q8O6J = new object();
        $_Q8O6J->name        = $turnitintool->name.' - '.$_Q88j6->partname;
        $_Q8O6J->description = ($turnitintool->intro==NULL) ? '' : $turnitintool->intro;
        $_Q8O6J->courseid    = $turnitintool->course;
        $_Q8O6J->groupid     = 0;
        $_Q8O6J->userid      = 0;
        $_Q8O6J->modulename  = 'turnitintool';
        $_Q8O6J->instance    = $_Q8Qft;
        $_Q8O6J->eventtype   = 'due';
        $_Q8O6J->timestart   = $_Q88j6->dtdue;
        $_Q8O6J->timeduration = 0;
        add_event($_Q8O6J);
	}
	@include_once($CFG->dirroot."/lib/gradelib.php");
	if (function_exists('grade_update')) {
		$_Q8OLt=get_coursemodule_from_instance("turnitintool", $_Q8Qft, $turnitintool->course);
		$_Q8oLQ=turnitintool_get_record('modules','name','turnitintool');
		$_Q8CiI['itemname'] = $turnitintool->name;
		$_Q8CiI['idnumber'] = $_Q8Qft;
		$_Q8CiI['gradetype'] = GRADE_TYPE_VALUE;
   	 	$_Q8CiI['grademax']  = $turnitintool->grade;
				$_Q8iIl=turnitintool_get_record('turnitintool_parts','turnitintoolid',$_Q8Qft,'','','','','max(dtpost)');
				$_Q8iIl=current($_Q8iIl);
				$_Q8CiI['hidden']=$_Q8iIl;
   		$_Q8CiI['grademin']  = 0;
		grade_update('mod/turnitintool', $turnitintool->course, 'mod', 'turnitintool', $_Q8Qft, 0, NULL, $_Q8CiI);
	}
	return $_Q8Qft;
}
function turnitintool_update_instance($turnitintool) {
	global $CFG, $USER;
	$turnitintool->timemodified = time();
	$turnitintool->id = $turnitintool->instance;
	$_QfloJ = new TIIToolClass;
	if (!$course = turnitintool_get_record("course", "id", $turnitintool->course)) {
		turnitintool_print_error('coursegeterror','turnitintool',NULL,__FILE__,__LINE__);
		exit();
	}
	if (!$_Q8L1J = turnitintool_get_record("turnitintool", "id", $turnitintool->id)) {
		turnitintool_print_error('turnitintoolgeterror','turnitintool',NULL,__FILE__,__LINE__);
		exit();
	}
	if (!$_Q8L8C = turnitintool_get_records_select("turnitintool_parts", "turnitintoolid=".$turnitintool->id." AND deleted=0",'id')) {
		turnitintool_print_error('partgeterror','turnitintool',NULL,__FILE__,__LINE__);
		exit();
	}
	$_Q8l0O=array_keys($_Q8L8C);
	$_Q8I6l=0;
	$_QflLo=$turnitintool->numparts;
	if (count($_Q8l0O)>$turnitintool->numparts) {                        
		$_QflLo+=count($_Q8l0O)-$turnitintool->numparts;
	}         
	if ($_Q8L1J->numparts<$turnitintool->numparts) {             
		$_QflLo+=$turnitintool->numparts-count($_Q8l0O);
	}
	if ($turnitintool->numparts<count($_Q8l0O) AND turnitintool_count_records('turnitintool_submissions','turnitintoolid',$turnitintool->id)>0) {
		turnitintool_print_error('reducepartserror','turnitintool',NULL,__FILE__,__LINE__);
		exit();
	} else if ($turnitintool->numparts<count($_Q8l0O)) { 
		for ($_Q8ILi=0;$_Q8ILi<count($_Q8l0O);$_Q8ILi++) {
			$_Q8l6J=$_Q8ILi+1;
			if ($_Q8l6J>$turnitintool->numparts) {
				$_Q8I6l++;
				if (turnitintool_is_owner($course->id)) {
					$owner=$USER;
				} else {
					$owner=turnitintool_get_owner($course->id);
				}
				$_Q8jIQ->uid=turnitintool_getUID($owner);
				$_Q8jIQ->cid=turnitintool_getCID($course->id);
				$_Q8jIQ->assignid=turnitintool_getAID($_Q8l0O[$_Q8ILi]);
				$_Q8jIQ->courseid=$course->id;
				$_Q8jIQ->ctl=turnitintool_getCTL($course->id);
				$_Q8jIQ->dtstart=time();
				$_Q8jIQ->dtdue=strtotime('+1 week');
				$_Q8jIQ->dtpost=strtotime('+1 week');
				$_Q8jIQ->name=$turnitintool->name.' - '.turnitintool_partnamefromnum($_Q8l0O[$_Q8ILi]).' (Moodle '.$_Q8jIQ->assignid.')';
				$_Q8J1f = $_QfloJ->deleteAssignment($_Q8jIQ,$owner,$_Q8I6l,$_QflLo,get_string('assignmentdeleteprocess','turnitintool',$_Q8l6J));
				$_Q8Jii=$_QfloJ->getRcode($_Q8J1f);
				$_Q86oL=false;
				if (!empty($_Q8Jii) AND $_Q8Jii>100) {
					$_Q86oL=true;
					$_Q8ftf=$_QfloJ->getRmessage($_Q8J1f);
				} else if (empty($_Q8Jii)) {
					$_Q86oL=true;
					$_Q8ftf=get_string('apiunavailable','turnitintool');
				}
				if ($_Q8Jii==218) {
					$_Q8ftf=get_string('assignmentdoesnotexist','turnitintool');
				}
				if ($_Q86oL AND $_Q8Jii!=411 AND $_Q8Jii!=206) {
					error('<strong>'.get_string('deleteerror','turnitintool').'</strong><br />'.$_Q8ftf);
					exit();
				} else {
					if (!$_Q8lfO=turnitintool_delete_records('turnitintool_submissions','turnitintoolid',$turnitintool->id,'submission_part',$_Q8l0O[$_Q8ILi])) {
						turnitintool_print_error('submissiondeleteerror','turnitintool',NULL,__FILE__,__LINE__);
						exit();
					}
				}
				$_Q88j6->id=$_Q8l0O[$_Q8ILi];
				$_Q88j6->deleted=1;
				if (!$delete=turnitintool_update_record('turnitintool_parts',$_Q88j6,false)) {
					turnitintool_print_error('partdberror','turnitintool',$_Q8ILi,__FILE__,__LINE__);
				}
				turnitintool_delete_records('event', 'modulename','turnitintool','instance',$turnitintool->id,'name',$turnitintool->name.' - '.$_Q88j6->partname);
			}
		}
	}
	unset($_Q8jIQ);
	for ($_Q8ILi=0;$_Q8ILi<$turnitintool->numparts;$_Q8ILi++) {
		$_Q8l6J=$_Q8ILi+1;
		$_Q8I6l++;
		$_Q8jIQ->courseid=$course->id;
		$_Q8jIQ->ctl=turnitintool_getCTL($course->id);
		$_Qt0O1 = isset($_Q8l0O[$_Q8ILi]) ? $_Q8l0O[$_Q8ILi] : null;
		if ($_Q8ILi>=count($_Q8l0O)) {
			$_Q8jIQ->dtstart=time();       
			$_Q8jIQ->dtdue=strtotime('+1 week');   
			$_Q8jIQ->dtpost=strtotime('+1 week');  
		} else {
			$_Q8jIQ->dtstart=$_Q8L8C[$_Qt0O1]->dtstart;
			$_Q8jIQ->dtdue=$_Q8L8C[$_Qt0O1]->dtdue;
			$_Q8jIQ->dtpost=$_Q8L8C[$_Qt0O1]->dtpost;
		}
		$_Q8jIQ->s_view_report=$turnitintool->studentreports;
		$_Q8jIQ->anon=$turnitintool->anon;
		$_Q8jIQ->report_gen_speed=$turnitintool->reportgenspeed;
		$_Q8jIQ->late_accept_flag=$turnitintool->allowlate;
		$_Q8jIQ->submit_papers_to=$turnitintool->submitpapersto;
		$_Q8jIQ->s_paper_check=$turnitintool->spapercheck;
		$_Q8jIQ->internet_check=$turnitintool->internetcheck;
		$_Q8jIQ->journal_check=$turnitintool->journalcheck;
		if (turnitintool_is_owner($course->id)) {
			$owner=$USER;
		} else {
			$owner=turnitintool_get_owner($course->id);
		}
		if ($_Q8ILi<count($_Q8l0O)) {
			$_Qt1Ql=false;
			$_Qt1o1=turnitintool_partnamefromnum($_Q8l0O[$_Q8ILi]);
			$_Q8jIQ->uid=turnitintool_getUID($owner);
			$_Q8jIQ->cid=turnitintool_getCID($course->id);
			$_Q8jIQ->assignid=turnitintool_getAID($_Q8l0O[$_Q8ILi]);
			$_Q8jIQ->name=$turnitintool->name.' - '.$_Qt1o1.' (Moodle '.$_Q8jIQ->assignid.')';
			$_Q8jIQ->currentassign=$_Q8L1J->name.' - '.turnitintool_partnamefromnum($_Q8l0O[$_Q8ILi]).' (Moodle '.$_Q8jIQ->assignid.')';
			$_Q8J1f = $_QfloJ->createAssignment($_Q8jIQ,'UPDATE',$owner,$_Q8I6l,$_QflLo,get_string('assignmentupdate','turnitintool',$_Q8l6J));
		} else {
			$_Qt1Ql=true;
			$_Q8jIQ->uid='';
			$_Q8jIQ->cid='';
			$_Q8jIQ->assignid='';
			$_Q8jIQ->dtstart=time(); 
			$_Q8jIQ->dtdue=time()+86400; 
			$_Q8jIQ->dtpost=time()+86400; 
			$_Qt1o1=get_string('turnitinpart','turnitintool',$_Q8l6J);
			$_Q8jIQ->name=$turnitintool->name.' - '.$_Qt1o1;
			$_Q8J1f = $_QfloJ->createAssignment($_Q8jIQ,'INSERT',$owner,$_Q8I6l,$_QflLo,get_string('assignmentprocess','turnitintool',$_Q8l6J));
		}
		$_Q8Jii=$_QfloJ->getRcode($_Q8J1f);
		$_Q86oL=false;
		if (!empty($_Q8Jii) AND $_Q8Jii>100) {
			$_Q86oL=true;
			$_Q8ftf=$_QfloJ->getRmessage($_Q8J1f);
		} else if (empty($_Q8Jii)) {
			$_Q86oL=true;
			$_Q8ftf=get_string('apiunavailable','turnitintool');
		}
		if ($_Q8Jii==218) {
			$_Q8ftf=get_string('assignmentdoesnotexist','turnitintool');
		}
		if ($_Q86oL) {
			error('<strong>'.get_string('updateerror','turnitintool').'</strong><br />'.$_Q8ftf);
			exit();
		}
		$_Q88j6->tiiassignid=$_QfloJ->getAssignid($_Q8J1f);
		if ($_Qt1Ql) {
			$_Q8jIQ->uid=turnitintool_getUID($owner);
			$_Q8jIQ->cid=turnitintool_getCID($course->id);
			$_Q8jIQ->assignid=$_Q88j6->tiiassignid;
			$_Q8jIQ->currentassign=$_Q8jIQ->name;
			$_Q8jIQ->name.=' (Moodle '.$_Q88j6->tiiassignid.')';
			$_Q8jIQ->max_points=$turnitintool->grade;
			$_Q8jIQ->ufn=$owner->firstname;
			$_Q8jIQ->uln=$owner->lastname;
			$_Q8jIQ->uem=$owner->email;
			$_Q8jIQ->assign=$_Q8jIQ->currentassign;
			$_Q8tj0=false;
			$_Q8to1=0;
			while (!$_Q8tj0 AND $_Q8to1<=10) {
				$_Q8to1++;
				$_Q8J1f=$_QfloJ->queryAssignment($_Q8jIQ,$_Q8I6l,$_QflLo,get_string('synchronisingturnitin','turnitintool'));
				$_Q8Jii=$_QfloJ->getRcode($_Q8J1f);
				if ($_Q8Jii<=100) {
					$_Q8tj0=true;
				}
			}
			$_Q8I6l++;
			$_Q8J1f = $_QfloJ->createAssignment($_Q8jIQ,'UPDATE',$owner,$_Q8I6l,$_QflLo,get_string('assignmentidividualise','turnitintool',$_Q8l6J)); 
			$_Q8Jii=$_QfloJ->getRcode($_Q8J1f);
			$_Q86oL=false;
			if (!empty($_Q8Jii) AND $_Q8Jii>100) {
				$_Q86oL=true;
				$_Q8ftf=$_QfloJ->getRmessage($_Q8J1f);
			} else if (empty($_Q8Jii)) {
				$_Q86oL=true;
				$_Q8ftf=get_string('apiunavailable','turnitintool');
			}
			if ($_Q86oL) {
				error('<strong>'.get_string('inserterror','turnitintool').'</strong><br />'.$_Q8ftf);
				exit();
			}
		}
		$_Q88j6->turnitintoolid=$turnitintool->id;
		$_Q88j6->partname=$_Qt1o1;
		$_Q88j6->deleted=0;
		if ($_Q8ILi>=count($_Q8l0O)) {
			$_Q88j6->dtstart=time();
			$_Q88j6->dtdue=strtotime('+1 week');
			$_Q88j6->dtpost=strtotime('+1 week');
		} else {
			$_Q88j6->dtdue=$_Q8L8C[$_Qt0O1]->dtdue;
			$_Q88j6->dtpost=$_Q8L8C[$_Qt0O1]->dtpost;
		}
		$_Q88j6->dtstart=$_Q8jIQ->dtstart;
		$_Q88j6->dtdue=$_Q8jIQ->dtdue;
		$_Q88j6->dtpost=$_Q8jIQ->dtpost;
		$_Q8O6J = new object();
        $_Q8O6J->name        = $turnitintool->name.' - '.$_Q88j6->partname;
        $_Q8O6J->description = $turnitintool->intro;
        $_Q8O6J->courseid    = $turnitintool->course;
        $_Q8O6J->groupid     = 0;
        $_Q8O6J->userid      = 0;
        $_Q8O6J->modulename  = 'turnitintool';
        $_Q8O6J->instance    = $turnitintool->id;
        $_Q8O6J->eventtype   = 'due';
        $_Q8O6J->timestart   = $_Q88j6->dtdue;
        $_Q8O6J->timeduration = 0;
		if ($_Q8ILi<count($_Q8l0O)) {
			$_Q88j6->id=$_Q8l0O[$_Q8ILi];
			if (!$_Qt1l0=turnitintool_update_record('turnitintool_parts',$_Q88j6,false)) {
				turnitintool_print_error('partdberror','turnitintool',$_Q8ILi,__FILE__,__LINE__);
			}
		} else {
			$_Q88j6->maxmarks=$turnitintool->grade;
			if (!$_Qt1l0=turnitintool_insert_record('turnitintool_parts',$_Q88j6,false)) {
				turnitintool_print_error('partdberror','turnitintool',$_Q8ILi,__FILE__,__LINE__);
			}
		}
		turnitintool_delete_records('event', 'modulename','turnitintool','instance',$turnitintool->id,'name',$_Q8L1J->name.' - '.$_Q88j6->partname);
		add_event($_Q8O6J);
		unset($_Q8jIQ);
	}
	$turnitintool->timemodified=time();
	$update=turnitintool_update_record("turnitintool", $turnitintool);
	@include_once($CFG->dirroot."/lib/gradelib.php");
	if (function_exists('grade_update')) {
		$_Q8OLt=get_coursemodule_from_instance("turnitintool", $turnitintool->id, $turnitintool->course);
		$_Q8oLQ=turnitintool_get_record('modules','name','turnitintool');
		$_QtI1L['itemname'] = $turnitintool->name;
		$_Q8CiI['idnumber'] = $turnitintool->id;
		$_Q8CiI['gradetype'] = GRADE_TYPE_VALUE;
   	 	$_Q8CiI['grademax']  = $turnitintool->grade;
		$_Q8iIl=turnitintool_get_record('turnitintool_parts','turnitintoolid',$turnitintool->id,'','','','','max(dtpost)');
		$_Q8iIl=current($_Q8iIl);
		$_Q8CiI['hidden']=$_Q8iIl;
   		$_Q8CiI['grademin']  = 0;
		grade_update('mod/turnitintool', $turnitintool->course, 'mod', 'turnitintool', $turnitintool->id, 0, NULL, $_Q8CiI);
	}
	return $update;
}
function turnitintool_delete_instance($id) {
	global $CFG, $USER;
	$_Q8J1f = true;
	if (!$turnitintool = turnitintool_get_record("turnitintool", "id", "$id")) {
		return false;
	}
	$_QfloJ = new TIIToolClass;
	if (!$course = turnitintool_get_record("course", "id", $turnitintool->course)) {
		return false;
	}
	$_Q8L8C = turnitintool_get_records("turnitintool_parts", "turnitintoolid", $turnitintool->id);
	$_Q8l0O=array_keys($_Q8L8C);
	$_QflLo=count($_Q8l0O);
	$_Q8I6l=0;
	foreach ($_Q8L8C as $_Q88j6) {
		$_Q8I6l++;
		if (turnitintool_is_owner($course->id)) {
			$owner=$USER;
		} else {
			$owner=turnitintool_get_owner($course->id);
		}
		$_Q8jIQ->uid=turnitintool_getUID($owner);
		$_Q8jIQ->cid=turnitintool_getCID($course->id);
		$_Q8jIQ->assignid=turnitintool_getAID($_Q88j6->id);
		$_Q8jIQ->ctl=turnitintool_getCTL($course->id);
		$_Q8jIQ->name=$turnitintool->name.' - '.turnitintool_partnamefromnum($_Q88j6->id).' (Moodle '.$_Q8jIQ->assignid.')';
		$_Q8J1f = $_QfloJ->deleteAssignment($_Q8jIQ, $owner,$_Q8I6l,$_QflLo,get_string('assignmentdeleteprocess','turnitintool',$_Q8I6l));
		$_Q8Jii=$_QfloJ->getRcode($_Q8J1f);
		$_Q86oL=false;
		if (!empty($_Q8Jii) AND $_Q8Jii>100) {
			$_Q86oL=true;
			$_Q8ftf=$_QfloJ->getRmessage($_Q8J1f);
		} else if (empty($_Q8Jii)) {
			$_Q86oL=true;
			$_Q8ftf=get_string('apiunavailable','turnitintool');
		}
		if ($_Q8Jii==411 OR $_Q8Jii==206 OR $_Q8Jii==228) {
			$_Q86oL=false;
		}
		if ($_Q86oL) {
			turnitintool_print_error('<strong>'.get_string('deleteerror','turnitintool').'</strong><br />RCODE: ('.$_Q8Jii.') '.$_Q8ftf);
			exit();
		} else {
			if (!$_Q8lfO=turnitintool_delete_records('turnitintool_submissions','turnitintoolid',$turnitintool->id,'submission_part',$_Q88j6->id)) {
				$_Q8J1f=false;
			}
		}
		if (!turnitintool_delete_records("turnitintool_parts", "id", $_Q88j6->id)) {
			$_Q8J1f = false;
		}
		turnitintool_delete_records('event', 'modulename','turnitintool','instance',$turnitintool->id,'name',$turnitintool->name.' - '.$_Q88j6->partname);
		unset($_Q8jIQ);
	}
	if (!turnitintool_delete_records("turnitintool", "id", $turnitintool->id)) {
		$_Q8J1f = false;
	}
	if ($_QtIlO=turnitintool_get_records("turnitintool_courses")) {
		foreach ($_QtIlO as $_QtjQj) {
			if (!turnitintool_count_records("course","id",$_QtjQj->courseid)>0) {
				turnitintool_delete_records("turnitintool_courses","courseid",$_QtjQj->courseid);
			}
		}
	}
	@include_once($CFG->dirroot."/lib/gradelib.php");
	if (function_exists('grade_update')) {
		$_Q8OLt=get_coursemodule_from_instance("turnitintool", $turnitintool->id, $turnitintool->course);
		$_Q8CiI['idnumber'] = $turnitintool->id;
		$_Q8CiI['deleted'] = 1;
		grade_update('mod/turnitintool', $turnitintool->course, 'mod', 'turnitintool', $turnitintool->id, 0, NULL, $_Q8CiI);
	}
	return $_Q8J1f;
}
function turnitintool_refresh_events($_QtjQt=0) {
	if ($_QtjQt == 0) {
        if (!$_QtjLL = turnitintool_get_records("turnitintool")) {
            return true;
        }
    } else {
        if (!$_QtjLL = turnitintool_get_records("turnitintool", "course",$_QtjQt)) {
            return true;
        }
    }
	$_Q8oLQ = turnitintool_get_records('modules', 'name','turnitintool','id');
	$_QtJQj=key(current($_Q8oLQ));
	foreach ($_QtjLL as $turnitintool) {
        $_Q8O6J = NULL;
        $_Q8O6J->description = $turnitintool->intro;
		if (!$_Q8L8C = turnitintool_get_records("turnitintool_parts","turnitintoolid",$turnitintool->id)) {
			return false;
		}
		foreach ($_Q8L8C as $_Q88j6) {
			$_Q8O6J->timestart=$_Q88j6->dtdue;
			if ($_QtJCi = turnitintool_get_record('event', 'modulename','turnitintool','instance',$turnitintool->id,'name',$turnitintool->name.' - '.$_Q88j6->name)) {
				$_Q8O6J->id = $_QtJCi->id;
				update_event($_Q8O6J);
			} else {
				$_Q8O6J->courseid    = $turnitintool->course;
				$_Q8O6J->groupid     = 0;
				$_Q8O6J->userid      = 0;
				$_Q8O6J->modulename  = 'turnitintool';
				$_Q8O6J->instance    = $turnitintool->id;
				$_Q8O6J->eventtype   = 'due';
				$_Q8O6J->timeduration = 0;
				$_Qt6ji = turnitintool_get_record('course_modules','module',$_QtJQj,'instance',$turnitintool->id);
				$_Qt6l1=current($_Qt6ji);
				$_Q8O6J->visible = $_Qt6l1->visible;
				add_event($_Q8O6J);
			}	
		}
    }
    return $_Q8J1f;
}
function turnitintool_print_overview($_Qtf0I, &$_QtffO) {
    global $USER, $CFG, $DB;
    if (empty($_Qtf0I) || !is_array($_Qtf0I) || count($_Qtf0I) == 0) {
        return array();
    }
    if (!$_QtjLL=get_all_instances_in_courses('turnitintool',$_Qtf0I)) {
        return;
    }
    $_Qt8jo = array();
	$_Qt8fi=array();
	foreach ($_QtjLL as $_Qtt0O => $turnitintool) {
		$_Qtt8j = time();
		$_Q8L8C=turnitintool_get_records_select('turnitintool_parts','turnitintoolid='.$turnitintool->id.' AND deleted=0','id');
		$_QttoQ = get_context_instance(CONTEXT_MODULE, $turnitintool->coursemodule);
		$_QtOJf=0;
		$_QtOl8=0;
		$_QtoCQ=array();
		foreach ($_Q8L8C as $_Q88j6) {
			$_QtOJf = ($_Q88j6->dtstart>$_QtOJf) ? $_Q88j6->dtstart : $_QtOJf;
			$_QtOl8 = ($_Q88j6->dtpost>$_QtOl8) ? $_Q88j6->dtpost : $_QtOl8;
			$_QtoCQ[$_Q88j6->id]['name']=$_Q88j6->partname;
			$_QtoCQ[$_Q88j6->id]['dtdue']=$_Q88j6->dtdue;
			if (has_capability('mod/turnitintool:grade', $_QttoQ)) { 
				$_QtCjl=turnitintool_get_records_select('turnitintool_submissions','turnitintoolid='.$turnitintool->id.' AND submission_part='.$_Q88j6->id.' AND submission_objectid IS NOT NULL AND userid!=0','','count(userid)');
				$_QtCOi=key($_QtCjl);
				$_QtiOj=turnitintool_get_records_select('turnitintool_submissions','turnitintoolid='.$turnitintool->id.' AND submission_part='.$_Q88j6->id.' AND userid!=0 AND submission_grade IS NOT NULL AND submission_grade>\'\'','','count(userid)');
				$_QtL8l=key($_QtiOj);
				$_Qtlj6=get_users_by_capability($_QttoQ, 'mod/turnitintool:submit', 'u.id', '', '', '', 0, '', false);
				$_QtlJi->submitted=$_QtCOi;
				$_QtlJi->graded=$_QtL8l;
				$_QtlJi->total=count($_Qtlj6);
				$_QtlJi->gplural=($_QtL8l!=1) ? 's' : '';
				$_QtoCQ[$_Q88j6->id]['status']=get_string('tutorstatus','turnitintool',$_QtlJi);
			} else { 
				if ($_QtlC0=turnitintool_get_record_select('turnitintool_submissions','turnitintoolid='.$turnitintool->id.' AND submission_part='.$_Q88j6->id.' AND userid='.$USER->id.' AND submission_objectid IS NOT NULL')) {
					$_QtlJi->modified=date($turnitintool->dateformat.', h:i A',$_QtlC0->submission_modified);
					$_QtlJi->objectid=$_QtlC0->submission_objectid;
					$_QtoCQ[$_Q88j6->id]['status']=get_string('studentstatus','turnitintool',$_QtlJi);
				} else {
					$_QtoCQ[$_Q88j6->id]['status']=get_string('nosubmissions','turnitintool');
				}
			}
		}
		if (($turnitintool->allowlate AND $_QtOJf<=$_Qtt8j) OR ($_QtOJf<=$_Qtt8j AND $_QtOl8>=$_Qtt8j)) { 
			$_QO0ff = '<div class="turnitintool overview"><div class="name">'.get_string('modulename','turnitintool'). ': '.
			'<a '.($turnitintool->visible ? '':' class="dimmed"').
			'title="'.get_string('modulename','turnitintool').'" href="'.$CFG->wwwroot.
			'/mod/turnitintool/view.php?id='.$turnitintool->coursemodule.'">'.
			$turnitintool->name.'</a></div>';
			foreach ($_QtoCQ as $_QO0O6) {
				$_QO0ff .= '<div class="info"><b>'.$_QO0O6['name'].' - '.get_string('dtdue','turnitintool').': '.date($turnitintool->dateformat.', h:i A',$_QO0O6['dtdue']).'</b><br />
						<i>'.$_QO0O6['status'].'</i></div>';
			}
			if (empty($_QtffO[$turnitintool->course]['turnitintool'])) {
				$_QtffO[$turnitintool->course]['turnitintool'] = $_QO0ff;
			} else {
				$_QtffO[$turnitintool->course]['turnitintool'] .= $_QO0ff;
			}
		}
	}
}
function turnitintool_multisort($_QtlJi, $_QO0LJ) {
	$_QO1If=array();
	$_QO0ff=array();
	$_QO18j=array();
	$_QO1lJ=array();
	foreach ($_QtlJi as $_Qtt0O => $_QOQfI) {
	    if(is_numeric(substr($_QOQfI[$_QO0LJ], 0, 1))) {
			$_QOIj8[$_Qtt0O] = $_QOQfI[$_QOILI];
			$_QO18j[$_Qtt0O] = $_QOQfI;
	    } else {
			$_QOj8j[$_Qtt0O] = $_QOQfI[$_QOILI];
			$_QO1lJ[$_Qtt0O] = $_QOQfI;
		}
	}
	unset($_QtlJi);
	array_multisort($_QOIj8, SORT_ASC, SORT_NUMERIC, $_QO18j);
	array_multisort($_QOj8j, SORT_ASC, SORT_STRING, $_QO1lJ);
	return array_merge($_QO18j, $_QO1lJ);
}
function turnitintool_getUID($owner) {
	if (!$_QOJIL = turnitintool_get_record("turnitintool_users", "userid", $owner->id)) {
		return NULL;
	} else {
		return $_QOJIL->turnitin_uid;
	}
}
function turnitintool_getCID($_QtjQt) {
	if (!$_QOJJj = turnitintool_get_record("turnitintool_courses", "courseid", $_QtjQt)) {
		turnitintool_print_error('coursegeterror','turnitintool',NULL,__FILE__,__LINE__);
		exit();
	} else {
		return $_QOJJj->turnitin_cid;
	}
}
function turnitintool_getCTL($_QtjQt) {
	if (!$_QOJJj = turnitintool_get_record("turnitintool_courses", "courseid", $_QtjQt)) {
		turnitintool_print_error('coursegeterror','turnitintool',NULL,__FILE__,__LINE__);
		exit();
	} else {
		return $_QOJJj->turnitin_ctl;
	}
}
function turnitintool_getAID($_QOJlC) {
	if (!$_QO6Lf = turnitintool_get_record("turnitintool_parts", "id", $_QOJlC)) {
		turnitintool_print_error('assigngeterror','turnitintool',NULL,__FILE__,__LINE__);
		exit();
	} else {
		return $_QO6Lf->tiiassignid;
	}
}
function turnitintool_usersetup($_QOf8o,$_QO8QO,$_Q8I6l=1,$_QflLo=1,$_QO88j='') {
	global $CFG;
	$_QfloJ = new TIIToolClass;
	$post->utp=$_QO8QO;
	if (!turnitintool_check_config()) {
		turnitintool_print_error('configureerror','turnitintool',NULL,__FILE__,__LINE__);
		exit();
	}
	if (!$_QOJIL = turnitintool_get_record("turnitintool_users", "userid", $_QOf8o->id)) {
		$post->idsync=1;
		if ($post->utp==1 AND !$CFG->turnitin_studentemail) {
			$post->dis=1;
		} else {
			$post->dis=0;
		}
		$_Q8J1f=$_QfloJ->createUser($post,$_QOf8o,$_Q8I6l,$_QflLo,$_QO88j);
		$_Q8Jii=$_QfloJ->getRcode($_Q8J1f);
		$_QOt08=$_QfloJ->getRmessage($_Q8J1f);
		if ($_Q8Jii>=100) {
			turnitintool_print_error($_QOt08,NULL,NULL,__FILE__,__LINE__);
			exit();
		}
		if (empty($_Q8Jii)) {
			turnitintool_print_error('connecttimeouterror','turnitintool',NULL,__FILE__,__LINE__);
			exit();
		}
		$_QOt6L=$_QfloJ->getUserID($_Q8J1f);
		$_Q80iI=new object();
		$_Q80iI->userid=$_QOf8o->id;
		$_Q80iI->turnitin_uid=$_QOt6L;
		if (!$_Q8Qft=turnitintool_insert_record('turnitintool_users',$_Q80iI)) {
			turnitintool_print_error('userupdateerror','turnitintool',NULL,__FILE__,__LINE__);
			exit();
		}
		$_Q80iI->id=$_Q8Qft;
		return $_Q80iI;
	} else {
		return $_QOJIL;
	}
}
function turnitintool_classsetup($course,$owner,$_Q8I6l=1,$_QflLo=1,$_QO88j='',$_QOO18=true) {
	$_QfloJ = new TIIToolClass;
	if (!turnitintool_check_config()) {
		turnitintool_print_error('configureerror','turnitintool',NULL,__FILE__,__LINE__);
		exit();
	}
	if (!$_QOJJj = turnitintool_get_record("turnitintool_courses", "courseid", $course->id)) {
		$_QOOtJ=false;
	} else {
		$_QOOtJ=true;
	}
	if (!$_QOOtJ) {
		$_Q8jt8=strtoupper(uniqid());
		$_QOo8j=$course->fullname." (".$_Q8jt8.")";
		$post->ctl=$_QOo8j;
		$post->idsync=1;
		$_Q8J1f=$_QfloJ->createClass($post,$owner,$_Q8I6l,$_QflLo,$_QO88j,$_QOO18);
		$_Q8Jii=$_QfloJ->getRcode($_Q8J1f);
		$_QOt08=$_QfloJ->getRmessage($_Q8J1f);
		if ($_Q8Jii>=100) {
			turnitintool_print_error($_QOt08,NULL,NULL,__FILE__,__LINE__);
			exit();
		}
		if (empty($_Q8Jii)) {
			turnitintool_print_error('connecttimeouterror','turnitintool',NULL,__FILE__,__LINE__);
			exit();
		}
		$post->cid=$_QfloJ->getClassID($_Q8J1f);
		$_QOo8j=str_replace("(".$_Q8jt8.")","(Moodle ".$post->cid.")",$_QOo8j);
		$_Q81l6=new object();
		$_Q81l6->courseid=$course->id;
		$_Q81l6->ownerid=$owner->id;
		$_Q81l6->turnitin_cid=$post->cid;
		$_Q81l6->turnitin_ctl=$_QOo8j;
		if (!$_Q8Qft=turnitintool_insert_record('turnitintool_courses',$_Q81l6)) {
			turnitintool_print_error('classupdateerror','turnitintool',NULL,__FILE__,__LINE__);
			exit();
		}
		$_Q81l6->id=$_Q8Qft;
	}
	if (isset($_Q8Qft) AND !$_QOJJj = turnitintool_get_record("turnitintool_courses", "courseid", $course->id)) {
		turnitintool_print_error('classgeterror','turnitintool',NULL,__FILE__,__LINE__);
		exit();
	}
	$post->cid=$_QOJJj->turnitin_cid;
	$post->ctl=$_QOJJj->turnitin_ctl;
	$post->idsync=0;
	$_Q8J1f=$_QfloJ->createClass($post,$owner,$_Q8I6l,$_QflLo,$_QO88j,$_QOO18);
	unset($_Q8Jii);
	unset($_QOt08);
	$_Q8Jii=$_QfloJ->getRcode($_Q8J1f);
	$_QOt08=$_QfloJ->getRmessage($_Q8J1f);
	if ($_Q8Jii>=100) {
		turnitintool_print_error($_QOt08,NULL,NULL,__FILE__,__LINE__);
		exit();
	}
	if (empty($_Q8Jii)) {
		turnitintool_print_error('connecttimeouterror','turnitintool',NULL,__FILE__,__LINE__);
		exit();
	}
	return $_QOJJj;
}
function turnitintool_draw_menu($_Q8OLt,$do) {
	global $CFG,$USER;
	$_QOCO1[] = new tabobject('intro', $CFG->wwwroot.'/mod/turnitintool/view.php'.'?id='.$_Q8OLt->id.'&do=intro', get_string('turnitintoolintro','turnitintool'), get_string('turnitintoolintro','turnitintool'), false);
	if (has_capability('mod/turnitintool:grade', get_context_instance(CONTEXT_MODULE, $_Q8OLt->id))) {
		$_QOCO1[] = new tabobject('submissions', $CFG->wwwroot.'/mod/turnitintool/view.php'.'?id='.$_Q8OLt->id.'&do=submissions', get_string('submitpaper','turnitintool'), get_string('mysubmissions','turnitintool'), false);
		$_QOCO1[] = new tabobject('allsubmissions', $CFG->wwwroot.'/mod/turnitintool/view.php'.'?id='.$_Q8OLt->id.'&do=allsubmissions', get_string('allsubmissions','turnitintool'), get_string('allsubmissions','turnitintool'), false);
		$_QOCO1[] = new tabobject('options', $CFG->wwwroot.'/mod/turnitintool/view.php'.'?id='.$_Q8OLt->id.'&do=options', get_string('options','turnitintool'), get_string('options','turnitintool'), false);
	} else {
		$_QOCO1[] = new tabobject('submissions', $CFG->wwwroot.'/mod/turnitintool/view.php'.'?id='.$_Q8OLt->id.'&do=submissions', get_string('mysubmissions','turnitintool'), get_string('mysubmissions','turnitintool'), false);
	}
	echo '<div class="clearfix"></div>';
	if ($do=='viewtext' OR $do=='notes') {
		$_QOifJ=NULL;
	} else {
		$_QOifJ=$do;
	}
	print_tabs(array($_QOCO1),$_QOifJ);
}
function turnitintool_update_partnames($_Q8OLt,$turnitintool,$post) {
	global $CFG,$USER;
	if (has_capability('mod/turnitintool:grade', get_context_instance(CONTEXT_MODULE, $_Q8OLt->id))) {
		$notice['message']='';
		$_Q86oL=false;
		$_QOl6I=strtotime($post["year_dtstart"].'-'.$post["month_dtstart"].'-'.$post["day_dtstart"].' '.$post["hour_dtstart"].':'.$post["min_dtstart"].':00');
		$_QOlOO=strtotime($post["year_dtdue"].'-'.$post["month_dtdue"].'-'.$post["day_dtdue"].' '.$post["hour_dtdue"].':'.$post["min_dtdue"].':00');
		$_Qo01J=strtotime($post["year_dtpost"].'-'.$post["month_dtpost"].'-'.$post["day_dtpost"].' '.$post["hour_dtpost"].':'.$post["min_dtpost"].':00');
		if ($_QOl6I>=$_QOlOO) {
			$notice['message'].=get_string('partstarterror','turnitintool');
			$_Q86oL=true;
		}
		if ($_QOlOO>$_Qo01J) {
			$notice['message'].=get_string('partdueerror','turnitintool');
			$_Q86oL=true;
		}
		if (empty($post['partname'])) {
			$notice['message'].=get_string('partnameerror','turnitintool');
			$_Q86oL=true;
		}
		if (strlen($post['partname'])>35) {
			$_QtlJi->length=35;
			$_QtlJi->field=get_string('partname','turnitintool');
			$notice['message'].=get_string('maxlength','turnitintool',$_QtlJi);
			$_Q86oL=true;
		}
		if (!ereg ("^[-]?[0-9]+([\.][0-9]+)?$", $post['maxmarks'])) { 
			$notice['message'].=get_string('partmarkserror','turnitintool');
			$_Q86oL=true;
		}
		if ($_Q86oL) {
			$notice['error']=$post['submitted'];
			$notice['post']=$post;
		}
		if (!$_Q86oL) {
			$_Q8jIQ->ctl=turnitintool_getCTL($turnitintool->course);
			$_Q8jIQ->dtstart=$_QOl6I;
			$_Q8jIQ->dtdue=$_QOlOO;
			$_Q8jIQ->dtpost=$_Qo01J;
			if (turnitintool_is_owner($turnitintool->course)) {
				$owner=$USER;
			} else {
				$owner=turnitintool_get_owner($turnitintool->course);
			}
			turnitintool_usersetup($owner,2,1,2,get_string('userprocess','turnitintool'));
			$_Q8jIQ->uid=turnitintool_getUID($owner);
			$_Q8jIQ->cid=turnitintool_getCID($turnitintool->course);
			$_Q8jIQ->assignid=turnitintool_getAID($post['submitted']);
			$_Q8jIQ->s_view_report=$turnitintool->studentreports;
			$_Q8jIQ->max_points=$post['maxmarks'];
			$_Q8jIQ->name=$turnitintool->name.' - '.$post['partname'].' (Moodle '.$_Q8jIQ->assignid.')';
			$_Q8jIQ->currentassign=$turnitintool->name.' - '.turnitintool_partnamefromnum($post['submitted']).' (Moodle '.$_Q8jIQ->assignid.')';
			$_QfloJ = new TIIToolClass;
			$_Q8J1f = $_QfloJ->createAssignment($_Q8jIQ,'UPDATE',$owner,2,2,get_string('assignmentupdate','turnitintool',''));
			$_Q8Jii=$_QfloJ->getRcode($_Q8J1f);
			$_Q86oL=false;
			if (!empty($_Q8Jii) AND $_Q8Jii>100) {
				$_Q86oL=true;
				$_Q8ftf=$_QfloJ->getRmessage($_Q8J1f);
			} else if (empty($_Q8Jii)) {
				$_Q86oL=true;
				$_Q8ftf=get_string('apiunavailable','turnitintool');
			}
			if ($_Q8Jii==218) {
				$_Q8ftf=get_string('assignmentdoesnotexist','turnitintool');
			}
			if ($_Q86oL) {
				turnitintool_print_error('<strong>'.get_string('updateerror','turnitintool').'</strong><br />'.$_Q8ftf);
				exit();
			}
			$_Q88j6->id=$post['submitted'];
			$_Q88j6->dtstart=$_QOl6I;
			$_Q88j6->dtdue=$_QOlOO;
			$_Q88j6->dtpost=$_Qo01J;
			$_Q88j6->partname=$post['partname'];
			$_Q88j6->maxmarks=$post['maxmarks'];
			$_Q88j6->deleted=0;
			$_Q8O6J->timestart=$_Q88j6->dtdue;
			$_Q8O6J->name=$turnitintool->name.' - '.$_Q88j6->partname;
			$_Qo06o=$turnitintool->name.' - '.turnitintool_partnamefromnum($post['submitted']);
			if (!$_Qt1l0=turnitintool_update_record('turnitintool_parts',$_Q88j6,false)) {
				turnitintool_print_error('partdberror','turnitintool',NULL,__FILE__,__LINE__);
			}
			if ($_QtJCi = turnitintool_get_record('event', 'modulename','turnitintool','instance',$turnitintool->id,'name',$_Qo06o)) {
				$_Q8O6J->id = $_QtJCi->id;
				update_event($_Q8O6J);
			}
			@include_once($CFG->dirroot."/lib/gradelib.php"); 
			if (function_exists('grade_update')) {
				$_Q8iIl=turnitintool_get_record('turnitintool_parts','turnitintoolid',$turnitintool->id,'','','','','max(dtpost)');
				$_Q8iIl=current($_Q8iIl);
				$_Q8CiI['hidden']=$_Q8iIl;
				grade_update('mod/turnitintool', $turnitintool->course, 'mod', 'turnitintool', $turnitintool->id, 0, NULL, $_Q8CiI);
			}
			turnitintool_redirect($CFG->wwwroot.'/mod/turnitintool/view.php'.'?id='.$_Q8OLt->id.'&do=intro');
			exit();
		} else {
			return $notice;
		}
	} else {
		turnitintool_print_error('permissiondeniederror','turnitintool',NULL,__FILE__,__LINE__);
	}
}
function turnitintool_delete_part($_Q8OLt,$turnitintool,$_QOJlC) {
	global $CFG,$USER;
	$notice['message']='';
	if ($turnitintool->numparts==1) {
		$_Q86oL=true;
		turnitintool_print_error('onepartdeleteerror','turnitintool',NULL,__FILE__,__LINE__);
	} else if (has_capability('mod/turnitintool:grade', get_context_instance(CONTEXT_MODULE, $_Q8OLt->id))) {
		if (turnitintool_is_owner($turnitintool->course)) {
			$owner=$USER;
		} else {
			$owner=turnitintool_get_owner($turnitintool->course);
		}
		turnitintool_usersetup($owner,2,1,2,get_string('userprocess','turnitintool'));
		$_Q8jIQ->uid=turnitintool_getUID($owner);
		$_Q8jIQ->cid=turnitintool_getCID($turnitintool->course);
		$_Q8jIQ->assignid=turnitintool_getAID($_QOJlC);
		$_Q8jIQ->ctl=turnitintool_getCTL($turnitintool->course);
		$_Q8jIQ->name=$turnitintool->name.' - '.turnitintool_partnamefromnum($_QOJlC).' (Moodle '.$_Q8jIQ->assignid.')';
		$_QfloJ = new TIIToolClass;
		$_Q8J1f = $_QfloJ->deleteAssignment($_Q8jIQ,$owner,2,2,get_string('assignmentdeleteprocess','turnitintool',''));
		$_Q8Jii=$_QfloJ->getRcode($_Q8J1f);
		$_Q86oL=false;
		if (!empty($_Q8Jii) AND $_Q8Jii>100) {
			$_Q86oL=true;
			$_Q8ftf=$_QfloJ->getRmessage($_Q8J1f);
		} else if (empty($_Q8Jii)) {
			$_Q86oL=true;
			$_Q8ftf=get_string('apiunavailable','turnitintool');
		}
		if ($_Q8Jii==411 OR $_Q8Jii==206) {  
			$_Q86oL=false;
		}
		if ($_Q86oL) {
			error('<strong>'.get_string('deleteerror','turnitintool').'</strong><br />RCODE: ('.$_Q8Jii.') '.$_Q8ftf);
			exit();
		} else {
			if (!$_Q8lfO=turnitintool_delete_records('turnitintool_submissions','turnitintoolid',$turnitintool->id,'submission_part',$_QOJlC)) {
				turnitintool_print_error('submissiondeleteerror','turnitintool',NULL,__FILE__,__LINE__);
				exit();
			}
		}
		$_Q8J1f = true;
		$_Q88j6->id=$_QOJlC;
		$_Q88j6->deleted=1;
		if (!turnitintool_update_record("turnitintool_parts", $_Q88j6, false)) {
			turnitintool_print_error('partdeleteerror','turnitintool',NULL,__FILE__,__LINE__);
		}
		turnitintool_delete_records('event', 'modulename','turnitintool','instance',$turnitintool->id,'name',$turnitintool->name.' - '.turnitintool_partnamefromnum($_QOJlC));
		$update->id=$turnitintool->id;
		$update->numparts=$turnitintool->numparts-1;
		if (!turnitintool_update_record("turnitintool",$update)) {
			turnitintool_print_error('turnitintooldeleteerror','turnitintool',NULL,__FILE__,__LINE__);
		}
		turnitintool_redirect($CFG->wwwroot.'/mod/turnitintool/view.php'.'?id='.$_Q8OLt->id.'&do=intro');
		exit();
	} else {
		turnitintool_print_error('permissiondeniederror','turnitintool',NULL,__FILE__,__LINE__);
		exit();
	}
	return $notice;
}
function turnitintool_introduction($_Q8OLt,$turnitintool,$notice='') {
	global $CFG;
	$_QOO18='<style language="text/css">
		.generaltable .c0 {
			font-weight: bold;
			background-color: #F3F3F3;
		}
	</style>';
	$_QOO18.=turnitintool_box_start('generalbox boxwidthwide boxaligncenter eightyfive','introduction',true);
	$_Qo0t8->width='100%';
	$_Qo0t8->tablealign='center';
	$_Qo0t8->cellpadding='4px';
	$_Qo0t8->cellspacing='0px';
	$_Qo0t8->size=array('35%','65%');
	$_Qo0t8->align=array('right','left');
	$_Qo0t8->wrap=array('nowrap',NULL);
	$_Qo0t8->class='uploadtable';
	unset($_Qo18O);
	$_Qo18O=array();
	$_Qo18O[]=get_string('turnitintoolname', 'turnitintool');
	$_Qo18O[]=$turnitintool->name;
	$_Qo0t8->data[]=$_Qo18O;
	if ($turnitintool->defaultdtstart < time() OR has_capability('mod/turnitintool:grade', get_context_instance(CONTEXT_MODULE, $_Q8OLt->id))) {
	    $_Qo1i6=$turnitintool->intro;
    } else {
		$_Qo1i6=get_string('notavailableyet','turnitintool');
	}
	unset($_Qo18O);
	$_Qo18O=array();
	$_Qo18O[]=get_string('turnitintoolintro', 'turnitintool');
	$_Qo18O[]=$_Qo1i6;
	$_Qo0t8->data[]=$_Qo18O;
	unset($_Qo18O);
	$_Qo18O[]=get_string('turnitintoolowner','turnitintool').turnitintool_help_icon('turnitintoolowner',get_string('turnitintoolowner','turnitintool'),'turnitintool',true,false,'',true);
	$owner=turnitintool_get_owner($turnitintool->course);
	$_Qo18O[]='<a href="'.$CFG->wwwroot.'/user/view.php?id='.$owner->id.'&course='.$turnitintool->course.'">'.$owner->firstname.' '.$owner->lastname.'</a> '.turnitintool_ownerselect($_Q8OLt,$turnitintool);
	$_Qo0t8->data[]=$_Qo18O;
	$_QOO18.=turnitintool_print_table($_Qo0t8,true);
	$_QOO18.=turnitintool_box_end(true);
	unset($_Qo0t8);
	$_QOO18.=turnitintool_box_start('generalbox boxwidthwide boxaligncenter eightyfive', 'introduction',true);
	if (!$_Q8L8C=turnitintool_get_records_select("turnitintool_parts","turnitintoolid='".$turnitintool->id."' AND deleted=0","dtstart,dtdue,dtpost,id")) {
		turnitintool_print_error('partgeterror','turnitintool',NULL,__FILE__,__LINE__);
	}
	$_QoQot='';
	foreach ($_Q8L8C as $_Q88j6) {
		if (!empty($_QoQot)) {
			$_QoQot.=':';
		}
		$_QoQot.=$_Q88j6->id;
	}
	$_QOO18.='
	<script language="javascript" type="text/javascript">
		var parts="'.$_QoQot.'";
	</script>';
	$_Qo0t8->width='100%';
	$_Qo0t8->tablealign='center';
	$_Qo0t8->cellpadding='4px';
	$_Qo0t8->cellspacing='0px';
	$_Qo0t8->size=array(NULL,'15%','15%','15%','8%','3%','3%');
	$_Qo0t8->head=array(get_string('partname','turnitintool'),
					   get_string('dtstart','turnitintool'),
					   get_string('dtdue','turnitintool'),
					   get_string('dtpost','turnitintool'),
					   get_string('maxmarks','turnitintool'),
					   '&nbsp;',
					   '&nbsp;');
	$_Qo0t8->align=array('left','center','center','center','center','center','center');
	$_Qo0t8->wrap=array(NULL,'nowrap','nowrap','nowrap','nowrap','nowrap','nowrap');
	$_Qo0t8->class='submissionTable';
	foreach($_Q8L8C as $_Q88j6) {
		if (has_capability('mod/turnitintool:grade', get_context_instance(CONTEXT_MODULE, $_Q8OLt->id))) { 
			if (isset($notice['error']) AND $notice['error']==$_Q88j6->id) {
				$_QoIQf=' class="error"';
				$_Q88j6=turnitintool_array_to_object($notice['post']);
				$_Q88j6->dtstart=strtotime($notice['post']["year_dtstart"].'-'.$notice['post']["month_dtstart"].'-'.$notice['post']["day_dtstart"].' '.$notice['post']["hour_dtstart"].':'.$notice['post']["min_dtstart"].':00');
				$_Q88j6->dtdue=strtotime($notice['post']["year_dtdue"].'-'.$notice['post']["month_dtdue"].'-'.$notice['post']["day_dtdue"].' '.$notice['post']["hour_dtdue"].':'.$notice['post']["min_dtdue"].':00');
				$_Q88j6->dtpost=strtotime($notice['post']["year_dtpost"].'-'.$notice['post']["month_dtpost"].'-'.$notice['post']["day_dtpost"].' '.$notice['post']["hour_dtpost"].':'.$notice['post']["min_dtpost"].':00');
				$_Q88j6->id=$notice['post']['submitted'];
				$_Qoj1I='
				<script language="javascript">
					turnitintool_editpart(parts,'.$_Q88j6->id.');
				</script>';
			} else {
				$_QoIQf='';
			}
			$_Qo18O=array();
			$_Qo18O[0]='<form action="'.$CFG->wwwroot.'/mod/turnitintool/view.php'.'?id='.$_Q8OLt->id.'&do=intro" method="POST"><input type="hidden" name="submitted" value="'.$_Q88j6->id.'" />';
			$_Qo18O[0].='<div id="partname_'.$_Q88j6->id.'"'.$_QoIQf.'><input name="partname" value="'.$_Q88j6->partname.'" type="text" /></div>';
			$_Qo18O[0].='<span id="partnametext_'.$_Q88j6->id.'"></span>';
			$_QoJ06 = array('h'=>date('H',$_Q88j6->dtstart),
						  'min'=>date('i',$_Q88j6->dtstart),
						  'd'=>date('j',$_Q88j6->dtstart),
						  'm'=>date('n',$_Q88j6->dtstart),
						  'Y'=>date('Y',$_Q88j6->dtstart));
			$_Qo18O[1]='<div id="dtstart_'.$_Q88j6->id.'"'.$_QoIQf.'>'.turnitintool_dateselect('dtstart',$_QoJ06,$turnitintool->dateformat).'</div>';
			$_Qo18O[1].='<span id="dtstarttext_'.$_Q88j6->id.'"></span>';
			$_QoJ06 = array('h'=>date('H',$_Q88j6->dtdue),
						  'min'=>date('i',$_Q88j6->dtdue),
						  'd'=>date('j',$_Q88j6->dtdue),
						  'm'=>date('n',$_Q88j6->dtdue),
						  'Y'=>date('Y',$_Q88j6->dtdue));
			$_Qo18O[2]='<div id="dtdue_'.$_Q88j6->id.'"'.$_QoIQf.'>'.turnitintool_dateselect('dtdue',$_QoJ06,$turnitintool->dateformat).'</div>';
			$_Qo18O[2].='<span id="dtduetext_'.$_Q88j6->id.'"></span>';
			$_QoJ06 = array('h'=>date('H',$_Q88j6->dtpost),
						  'min'=>date('i',$_Q88j6->dtpost),
						  'd'=>date('j',$_Q88j6->dtpost),
						  'm'=>date('n',$_Q88j6->dtpost),
						  'Y'=>date('Y',$_Q88j6->dtpost));
			$_Qo18O[3]='<div id="dtpost_'.$_Q88j6->id.'"'.$_QoIQf.'>'.turnitintool_dateselect('dtpost',$_QoJ06,$turnitintool->dateformat).'</div>';
			$_Qo18O[3].='<span id="dtposttext_'.$_Q88j6->id.'"></span>';
			$_Qo18O[4]='<div id="maxmarks_'.$_Q88j6->id.'"'.$_QoIQf.'><input name="maxmarks" type="text" value="'.$_Q88j6->maxmarks.'" /></div>';
			$_Qo18O[4].='<span id="maxmarkstext_'.$_Q88j6->id.'"></span>';
			$_Qo18O[5]='<div id="tick_'.$_Q88j6->id.'"><input type="image" src="images/tickicon.gif" /></div>';
			$_Qo18O[5].='<span id="ticktext_'.$_Q88j6->id.'"></span>
			';
			$_Qo18O[5].='<script language="javascript" type="text/javascript">
				values=new Array();
				values["partnametext"]="'.$_Q88j6->partname.'";
				values["dtstarttext"]="'.date('H:i, '.$turnitintool->dateformat,$_Q88j6->dtstart).'";
				values["dtduetext"]="'.date('H:i, '.$turnitintool->dateformat,$_Q88j6->dtdue).'";
				values["dtposttext"]="'.date('H:i, '.$turnitintool->dateformat,$_Q88j6->dtpost).'";
				values["maxmarkstext"]="'.$_Q88j6->maxmarks.'";
				values["ticktext"]="<a href=\"javascript:;\" onclick=\"turnitintool_editpart(parts,'.$_Q88j6->id.')\" title=\"'.get_string('edit','turnitintool').'\"><img src=\"images/editicon.gif\" class=\"tiiicons\" alt=\"'.get_string('edit','turnitintool').'\" /></a>";
				turnitintool_addvalues('.$_Q88j6->id.',values);
			</script></form>';
			if (turnitintool_count_records('turnitintool_submissions','turnitintoolid',$turnitintool->id,'submission_part',$_Q88j6->id)>0) {
				$_QoJ6l = array("\n","\r");
				$_QoJCo = array('\n','\r');
				$_Qo66L=' onclick="return confirm(\''.str_replace($_QoJ6l, $_QoJCo, get_string('partdeletewarning','turnitintool')).'\');"';
			} else {
				$_Qo66L='';
			}
			$_Qo18O[6]='<a href="'.$CFG->wwwroot.'/mod/turnitintool/view.php'.'?id='.$_Q8OLt->id.'&do=intro&delpart='.$_Q88j6->id.'" title="'.get_string('delete','turnitintool').'"'.$_Qo66L.'><img src="images/trashicon.gif" class="tiiicons" alt="'.get_string('delete','turnitintool').'" /></a>';
		} else { 
			$_Qo18O[0]=$_Q88j6->partname;
			$_Qo18O[1]=date('H:i, '.$turnitintool->dateformat,$_Q88j6->dtstart);
			$_Qo18O[2]=date('H:i, '.$turnitintool->dateformat,$_Q88j6->dtdue);
			$_Qo18O[3]=date('H:i, '.$turnitintool->dateformat,$_Q88j6->dtpost);
			$_Qo18O[4]=$_Q88j6->maxmarks;
			$_Qo18O[5]='&nbsp;';
			$_Qo18O[6]='&nbsp;';
		}
		$_Qo0t8->data[]=$_Qo18O;
		unset($_Qo18O);
	}
	$_QOO18.=turnitintool_print_table($_Qo0t8,true);
	if (isset($_Qoj1I)) {
		$_QOO18.=$_Qoj1I;
	}
	$_QOO18.=turnitintool_box_end(true);
	return $_QOO18;
}
function turnitintool_ownerselect($_Q8OLt,$turnitintool) {
	global $CFG;
	$_QttoQ = get_context_instance(CONTEXT_MODULE, $_Q8OLt->id);
	$_Qtlj6=get_users_by_capability($_QttoQ, 'mod/turnitintool:grade', 'u.id AS id,concat(u.firstname,\' \',u.lastname) as name', '', '', '', 0, '', false);
	$_QOO18='';
	if (count($_Qtlj6)>1 AND has_capability('mod/turnitintool:grade', get_context_instance(CONTEXT_MODULE, $_Q8OLt->id))) {
		$_QOO18.='<span style="display: none;" id="editOwner"><a href="javascript:toggleElements();" title="'.get_string('edit','turnitintool').'"><img src="images/editicon.gif" class="tiiicons" /></a></span>
		<form action="'.$CFG->wwwroot.'/mod/turnitintool/view.php" method="get" id="ownerForm">';
		$_QOO18.='<input name="id" type="hidden" value="'.$_Q8OLt->id.'" />';
		$_QOO18.='<select name="owner" onchange="turnitintool_jumptopage(\''.$CFG->wwwroot.'/mod/turnitintool/view.php?id='.$_Q8OLt->id.'&do=changeowner&owner=\'+this.value)">';
		$_QOO18.='	<option label="'.get_string('changeowner','turnitintool').'" value="NULL" selected="selected">'.get_string('changeowner','turnitintool').'</option>';
		$_QOO18.='	<option label="------------------------------" value="NULL">-----------------------------</option>';
		foreach ($_Qtlj6 as $_Qo6lJ) {
			$_QOO18.='	<option label="'.$_Qo6lJ->name.'" value="'.$_Qo6lJ->id.'">'.$_Qo6lJ->name.'</option>';
		}
		$_QOO18.='</select>';
		$_QOO18.='<input value=">" type="submit" id="submitButton" />';
		$_QOO18.='</form>';
		$_QOO18.='<script language="javascript">';
		$_QOO18.='toggleElements();';
		$_QOO18.='function toggleElements() {
			if (document.getElementById("editOwner").style.display=="inline") {
				document.getElementById("submitButton").style.display="none";
				document.getElementById("editOwner").style.display="none";
				document.getElementById("ownerForm").style.display="inline";
			} else {
				document.getElementById("submitButton").style.display="none";
				document.getElementById("editOwner").style.display="inline";
				document.getElementById("ownerForm").style.display="none";
			}
		}';
		$_QOO18.='</script>';
	}
	return $_QOO18;
}
function turnitintool_ownerprocess($_Q8OLt,$turnitintool,$_Qof68) {
	$_QttoQ = get_context_instance(CONTEXT_MODULE, $_Q8OLt->id);
	$_Qtlj6=get_users_by_capability($_QttoQ, 'mod/turnitintool:grade', 'u.id AS id,concat(u.firstname,\' \',u.lastname) as name', '', '', '', 0, '', false);
	if (!isset($_Qtlj6[$_Qof68])) {
		turnitintool_print_error('permissiondeniederror','turnitintool',NULL,__FILE__,__LINE__);
		exit();
	} else {
		$_QfloJ=new TIIToolClass;
		$owner=turnitintool_get_owner($turnitintool->course);
		$_Qo811=turnitintool_get_moodleuser($_Qof68);
		$_Q8I6l=1;
		$_QflLo=1;
		if (is_null($post->uid=turnitintool_getUID($owner))) {
			turnitintool_usersetup($owner,2,$_Q8I6l,3,get_string('userprocess','turnitintool'));
			$_Q8I6l=2;
			$_QflLo=3;
			$post->uid=turnitintool_getUID($owner);
		}
		if (is_null(turnitintool_getUID($_Qo811))) {
			turnitintool_usersetup($_Qo811,2,$_Q8I6l,3,get_string('userprocess','turnitintool'));
			$_Q8I6l=3;
			$_QflLo=3;
		}
		$post->cid=turnitintool_getCID($turnitintool->course);
		$post->ctl=turnitintool_getCTL($turnitintool->course);
		$post->new_teacher_email=$_Qo811->email;
		$post->email=$owner->email;
		$post->firstname=$owner->firstname;
		$post->lastname=$owner->lastname;
		$_Q8J1f=$_QfloJ->changeOwner($post,$_Q8I6l,$_QflLo,get_string('changingowner','turnitintool'),true);
		$_Q8Jii=$_QfloJ->getRcode($_Q8J1f);
		$_Q86oL=false;
		if (!empty($_Q8Jii) AND $_Q8Jii>100) {
			$_Q86oL=true;
			$_Q8ftf=$_QfloJ->getRmessage($_Q8J1f);
		} else if (empty($_Q8Jii)) {
			$_Q86oL=true;
			$_Q8ftf=get_string('apiunavailable','turnitintool');
		}
		if ($_Q86oL) {
			turnitintool_print_error('<strong>'.get_string('turnitintoolupdateerror','turnitintool').'</strong><br />'.$_Q8ftf,NULL,__FILE__,__LINE__);
			exit();
		} else {
			$_Qo8JO=turnitintool_get_record('turnitintool_courses','courseid',$turnitintool->course);
			$update->id=$_Qo8JO->id;
			$update->ownerid=$_Qof68;
			if (!$_Qo8fj=turnitintool_update_record('turnitintool_courses',$update)) {
				turnitintool_print_error('classupdateerror','turnitintool',NULL,__FILE__,__LINE__);
				exit();
			}
		}
	}
}
function turnitintool_dateselect($_Qo8L1,$_QotIf=NULL,$_QoO18='d/m/Y') {
	$_QoJ06['h']='<select name="hour_'.$_Qo8L1.'">';
	for ($_Q8ILi=0;$_Q8ILi<=23;$_Q8ILi++) { 
		if (!is_null($_QotIf) AND $_QotIf['h']==$_Q8ILi) {
			$_QOifJ=' selected';
		} else if (is_null($_QotIf) AND date('H',time())==$_Q8ILi) {
			$_QOifJ=' selected';
		} else {
			$_QOifJ='';
		}
		$_QoJ06['h'].='<option label="'.str_pad($_Q8ILi,2,"0",0).'" value="'.str_pad($_Q8ILi,2,"0",0).'"'.$_QOifJ.'>'.str_pad($_Q8ILi,2,"0",0).'</option>';
		$_QOifJ='';
	}
	$_QoJ06['h'].='</select>';
	$_QoJ06['min']='<select name="min_'.$_Qo8L1.'">';
	for ($_Q8ILi=0;$_Q8ILi<=59;$_Q8ILi++) { 
		if (!is_null($_QotIf) AND $_QotIf['min']==$_Q8ILi) {
			$_QOifJ=' selected';
		} else if (is_null($_QotIf) AND date('i',time())==$_Q8ILi) {
			$_QOifJ=' selected';
		} else {
			$_QOifJ='';
		}
		$_QoJ06['min'].='<option label="'.str_pad($_Q8ILi,2,"0",0).'" value="'.str_pad($_Q8ILi,2,"0",0).'"'.$_QOifJ.'>'.str_pad($_Q8ILi,2,"0",0).'</option>';
		$_QOifJ='';
	}
	$_QoJ06['min'].='</select>';
	$_QoJ06['d']='<select name="day_'.$_Qo8L1.'">';
	for ($_Q8ILi=1;$_Q8ILi<=31;$_Q8ILi++) { 
		if (!is_null($_QotIf) AND $_QotIf['d']==$_Q8ILi) {
			$_QOifJ=' selected';
		} else if (is_null($_QotIf) AND date('j',time())==$_Q8ILi) {
			$_QOifJ=' selected';
		} else {
			$_QOifJ='';
		}
		$_QoJ06['d'].='<option label="'.str_pad($_Q8ILi,2,"0",0).'" value="'.str_pad($_Q8ILi,2,"0",0).'"'.$_QOifJ.'>'.str_pad($_Q8ILi,2,"0",0).'</option>';
		$_QOifJ='';
	}
	$_QoJ06['d'].='</select>';
	$_QoJ06['m']='<select name="month_'.$_Qo8L1.'">';
	for ($_Q8ILi=1;$_Q8ILi<=12;$_Q8ILi++) { 
		if (!is_null($_QotIf) AND $_QotIf['m']==$_Q8ILi) {
			$_QOifJ=' selected';
		} else if (is_null($_QotIf) AND date('n',time())==$_Q8ILi) {
			$_QOifJ=' selected';
		} else {
			$_QOifJ='';
		}
		$_QoJ06['m'].='<option label="'.str_pad($_Q8ILi,2,"0",0).'" value="'.str_pad($_Q8ILi,2,"0",0).'"'.$_QOifJ.'>'.str_pad($_Q8ILi,2,"0",0).'</option>';
		$_QOifJ='';
	}
	$_QoJ06['m'].='</select>';
	$_QoJ06['Y']='<select name="year_'.$_Qo8L1.'">';
	$_QoOi8=date('Y',strtotime('-10 years'));
	for ($_Q8ILi=1;$_Q8ILi<=20;$_Q8ILi++) { 
		if (!is_null($_QotIf) AND $_QotIf['Y']==$_QoOi8) {
			$_QOifJ=' selected';
		} else if (is_null($_QotIf) AND date('Y',time())==$_QoOi8) {
			$_QOifJ=' selected';
		} else {
			$_QOifJ='';
		}
		$_QoJ06['Y'].='<option label="'.$_QoOi8.'" value="'.$_QoOi8.'"'.$_QOifJ.'>'.$_QoOi8.'</option>';
		$_QoOi8++;
		$_QOifJ='';
	}
	$_QoJ06['Y'].='</select>';
	$_QOO18='';
	if (substr_count($_QoO18,'-')) {
		$_Qoofj=explode('-',$_QoO18);
	} else {
		$_Qoofj=explode('/',$_QoO18);
	}
	$_QOO18.=$_QoJ06['h'].':'.$_QoJ06['min'].',<br />';
	$_Q8ILi=0;
	foreach ($_Qoofj as $_QoCJ6) {
		if ($_Q8ILi!=0) {
			$_QOO18.='/';
		}
		$_QOO18.=$_QoJ06[$_QoCJ6];
		$_Q8ILi++;
	}
	return $_QOO18;
}
function turnitintool_file_path($_Q8OLt,$turnitintool,$userid,$file=true) {
	global $CFG;
	$_Qoiof='/';
	$_QOO18=$turnitintool->course.$_Qoiof.$CFG->moddata.$_Qoiof.'turnitintool'.$_Qoiof.$turnitintool->id.$_Qoiof.$userid;
	return $_QOO18;
}
function turnitintool_draw_similarityscore($_Q8OLt,$turnitintool,$_QtlC0) {
	global $CFG,$USER;
	if (empty($_QtlC0->submission_objectid)) {
		$_QoL66='-';
	} else {
		$_Q8J1f=$_QtlC0->submission_score;
		$_Qol1C=$_QtlC0->submission_objectid;
		if (!$_Q88j6=turnitintool_get_record('turnitintool_parts','id',$_QtlC0->submission_part)) {
			turnitintool_print_error('partgeterror','turnitintool',NULL,__FILE__,__LINE__);
			exit();
		}
		if (!is_null($_Qol1C) AND (has_capability('mod/turnitintool:grade', get_context_instance(CONTEXT_MODULE, $_Q8OLt->id)) OR $turnitintool->studentreports)) {
			$owner = turnitintool_get_owner($turnitintool->course);
			$_QfloJ=new TIIToolClass;
			$post->paperid=$_QtlC0->submission_objectid;
			if (has_capability('mod/turnitintool:grade', get_context_instance(CONTEXT_MODULE, $_Q8OLt->id))) {
				$post->utp=2;
				$post->uid=turnitintool_getUID($owner); 
				$_Qo6lJ=$owner;
			} else {
				$post->utp=1;
				$post->uid=turnitintool_getUID($USER); 
				$_Qo6lJ=$USER;
			}
			if ((!is_null($_Q8J1f) AND !empty($_Q8J1f)) OR $_Q8J1f=="0") {
				$_QollJ=turnitintool_percent_to_gradpos($_Q8J1f);
				$_QC06J="";
				$_Q8J1f.='%';
				$_QC1Q0=$CFG->wwwroot.'/mod/turnitintool/view.php?id='.$_Q8OLt->id.'&jumppage=report&userid='.$_Qo6lJ->id.'&post='.base64_encode(serialize($post));
				$_QoL66='<div class="origLink">			
			<a href="'.$_QC1Q0.'" target="_blank" title="'.get_string('viewreport','turnitintool').'" class="scoreLink"'.$_QollJ.' onclick="screenOpen(\''.$_QC1Q0.'\',\''.$_QtlC0->id.'\',\''.$turnitintool->autoupdates.'\');return false;"><span class="scoreBox"'.$_QC06J.'>'.$_Q8J1f.'</span></a></div>';
			} else {
				$_QC1oQ='#FCFCFC';
				$_QollJ=' style="background-color: '.$_QC1oQ.';text-align: center;"';
				$_QC06J=' style="padding: 0px;"';
				$_Q8J1f=get_string('pending','turnitintool');
				$_QoL66='<div class="origLink">			
			<a name="Pending" class="scoreLink"'.$_QollJ.'><span class="scoreBox"'.$_QC06J.'>'.$_Q8J1f.'</span></a></div>';
			}
		} else {
			$_QoL66='-';
		}
	}
	return $_QoL66;
}
function turnitintool_get_filelink($_Q8OLt,$turnitintool,$_QtlC0,$_QCQfO=false) {
	global $CFG,$USER;
	if (empty($_QtlC0->submission_objectid)) {
		$_QCIj0=$CFG->wwwroot.'/file.php?file=/'.turnitintool_file_path($_Q8OLt,$turnitintool,$_QtlC0->userid,false).'/'.str_replace(" ","_",$_QtlC0->submission_filename);
	} else {
		$owner = turnitintool_get_owner($turnitintool->course);
		if (has_capability('mod/turnitintool:grade', get_context_instance(CONTEXT_MODULE, $_Q8OLt->id))) {
			$_Qo6lJ=$owner;
			$post->utp=2;
			$post->tem=null;
		} else {
			$_Qo6lJ=$USER;
			$post->utp=1;
			$post->tem=$owner->email;
		}
		$_QfloJ=new TIIToolClass;
		$post->uid=turnitintool_getUID($_Qo6lJ); 
		$post->cid=turnitintool_getCID($turnitintool->course); 
		$post->ctl=turnitintool_getCTL($turnitintool->course);
		$_Q88j6=turnitintool_get_record('turnitintool_parts','id',$_QtlC0->submission_part);
		$post->assignid=turnitintool_getAID($_Q88j6->id);
		$post->assign=$turnitintool->name.' - '.$_Q88j6->partname.' (Moodle '.$post->assignid.')';
		$post->paperid=$_QtlC0->submission_objectid;
		if (!$_QCQfO) {
			$_QCIj0=$CFG->wwwroot.'/mod/turnitintool/view.php?id='.$_Q8OLt->id.'&jumppage=submission&userid='.$_Qo6lJ->id.'&post='.base64_encode(serialize($post));
		} else {
			$_QCIj0=$CFG->wwwroot.'/mod/turnitintool/view.php?id='.$_Q8OLt->id.'&jumppage=download&userid='.$_Qo6lJ->id.'&post='.base64_encode(serialize($post));
		}
	}
	return $_QCIj0;
}
function turnitintool_view_student_submissions($_Q8OLt,$turnitintool) {
	global $CFG,$USER;
	$_QOO18='';
	$_Q8ILi=0;
	if (!has_capability('mod/turnitintool:grade', get_context_instance(CONTEXT_MODULE, $_Q8OLt->id))) { 
		if (!$_Q8lfO = turnitintool_get_records_select('turnitintool_submissions','userid='.$USER->id.' AND turnitintoolid='.$turnitintool->id,'id')) {
			$_QOO18.=turnitintool_box_start('generalbox boxwidthwide boxaligncenter centertext eightyfive', 'nosubmissions',true);
			$_QOO18.=get_string('nosubmissions','turnitintool');
			$_QOO18.='<p>[<a href="'.$CFG->wwwroot.'/mod/turnitintool/view.php'.'?id='.$_Q8OLt->id.'&do='.$_REQUEST["do"].'&update=1" title="'.get_string('synchyoursubmissions','turnitintool').'" class="refreshLink">'.get_string('synchyoursubmissions','turnitintool').'</a>]</p>';
			$_QOO18.=turnitintool_box_end(true);
		} else {
			$_QOO18.='
	<table class="toplinkTabs">
		<tr>
			<td class="tabLinks"><ul class="tabrow0 tabRowModified">
				<li><a href="'.$CFG->wwwroot.'/mod/turnitintool/view.php'.'?id='.$_Q8OLt->id.'&do='.$_REQUEST["do"].'&update=1"><span><img src="'.$CFG->wwwroot.'/mod/turnitintool/images/refresh.gif" alt="'.get_string('turnitinrefreshsubmissions','turnitintool').'" class="tiiicons" /> '.get_string('turnitinrefreshsubmissions','turnitintool').'</span></a></li>
			</ul></td>
		</tr>
	</table>';
			$_Qo0t8->width='85%';
			$_Qo0t8->tablealign='center';
			$_Qo0t8->cellpadding='4px';
			$_Qo0t8->cellspacing='0px';
			$_Qo0t8->head=array( get_string('submission','turnitintool'),
								get_string('objectid','turnitintool'),
								get_string('submissionorig','turnitintool'),
								get_string('submissiongrade','turnitintool'),
								get_string('feedback','turnitintool'),
								'',
								'');
			$_Qo0t8->size=array('','14%','8%','8%','4%','4%','4%');
			$_Qo0t8->align=array('left','center','center','center','center','center','center');
			$_Qo0t8->valign=array('top','center','center','center','center','center','center');
			$_Qo0t8->wrap=array(NULL,'nowrap','nowrap','nowrap','nowrap','nowrap','nowrap');
			$_Qo0t8->data=array();
			$_Qo0t8->class='submissionTable';
			foreach ($_Q8lfO as $_QtlC0) {
				unset($_QCItL);
				$_QCItL=array();
				$_QCIj0=turnitintool_get_filelink($_Q8OLt,$turnitintool,$_QtlC0);
				$_QCj0I=turnitintool_get_filelink($_Q8OLt,$turnitintool,$_QtlC0,$_QCQfO=true);
				$_QCjff='';
				if ($_QtlC0->submission_type==1) {
					$_QCJ0f=get_string('fileupload','turnitintool');
				} else if ($_QtlC0->submission_type==2) {
					$_QCJ0f=get_string('textsubmission','turnitintool');
				} else if ($_QtlC0->submission_type==3) {
					$_QCJ0f=get_string('webpage','turnitintool');
				}
				$_QCJC6='';
				if (!empty($_QtlC0->submission_objectid)) {
					$_QCJC6=' onclick="screenOpen(\''.$_QCIj0.'\',\''.$_QtlC0->id.'\',\''.$turnitintool->autoupdates.'\');return false;"';
				}
				if (turnitintool_count_records('turnitintool_parts','turnitintoolid',$turnitintool->id)>1) {
					$_QC6tJ=turnitintool_partnamefromnum($_QtlC0->submission_part).' - ';
				} else {
					$_QC6tJ='';
				}
				$_QCf8o=turnitintool_get_filelink($_Q8OLt,$turnitintool,$_QtlC0,$_QCQfO=true);
				$_QC8Jf='';
				if (!empty($_QtlC0->submission_objectid)) {
					$_QC8Jf=' onclick="screenOpen(\''.$_QCf8o.'\',\''.$_QtlC0->id.'\',\''.$turnitintool->autoupdates.'\');return false;"';
				}
				$_QCj0I='<a href="'.$_QCf8o.'" class="tiiicons" target="_blank"'.$_QC8Jf.'>*</a>';
				$_QCjff.='<a href="'.$_QCIj0.'" target="_blank"'.$_QCJC6.'>'.$_QC6tJ.$_QtlC0->submission_title.'</a><br />';
				if (empty($_QtlC0->submission_objectid)) {
					$_Qol1C=get_string('notyetsubmitted','turnitintool').'<div class="submittoLink"><img src="'.$CFG->wwwroot.'/mod/turnitintool/images/turnitinicon.gif" /><a href="'.$CFG->wwwroot.'/mod/turnitintool/view.php'.'?id='.$_Q8OLt->id.'&up='.$_QtlC0->id.'">'.get_string('submittoturnitin','turnitintool').'</a></div>';
				} else {
					$_Qol1C=$_QtlC0->submission_objectid;
				}
				$_QoL66 = turnitintool_draw_similarityscore($_Q8OLt,$turnitintool,$_QtlC0);
				$_Q8ILi++;
				$_QC8ff=turnitintool_dogradeoutput($_Q8OLt,$turnitintool,$_QtlC0,'black','transparent',false);
				if (empty($_QtlC0->submission_objectid)) {
					$_QO88j='<b>'.get_string('status','turnitintool').':</b> '.get_string('submissionnotyetuploaded','turnitintool');
				} else {
					$_QO88j='<b>'.get_string('status','turnitintool').':</b> '.$_QtlC0->submission_status;
				}
				$_QC8LQ=turnitintool_getnoteslink($_Q8OLt,$turnitintool,$_QtlC0);
				if (!is_null($_QtlC0->submission_objectid)) {
					$_QCQfO='<a href="'.turnitintool_get_filelink($_Q8OLt,$turnitintool,$_QtlC0,true).'" title="'.get_string('downloadsubmission','turnitintool').'" target="_blank"><img src="images/downloadicon.gif" alt="'.get_string('downloadsubmission','turnitintool').'" class="tiiicons" /></a>';
				} else {
					$_QCQfO='';
				}
				$_QoJ6l = array("\n","\r");
				$_QoJCo = array('\n','\r');
				if (empty($_QtlC0->submission_objectid)) {
					$_QCtoL=' onclick="return confirm(\''.str_replace($_QoJ6l, $_QoJCo, get_string('deleteconfirm','turnitintool')).'\');"';
				} else if (has_capability('mod/turnitintool:grade', get_context_instance(CONTEXT_MODULE, $_Q8OLt->id))) {
					$_QCtoL=' onclick="return confirm(\''.str_replace($_QoJ6l, $_QoJCo, get_string('turnitindeleteconfirm','turnitintool')).'\')"';
				} else {
					$_QCtoL=' onclick="return confirm(\''.str_replace($_QoJ6l, $_QoJCo, get_string('studentdeleteconfirm','turnitintool')).'\')"';
				}
				if (!$_Q88j6=turnitintool_get_record('turnitintool_parts','id',$_QtlC0->submission_part)) {
					turnitintool_print_error('partgeterror','turnitintool');
					exit();
				}
				if (empty($_QtlC0->submission_objectid)
					OR has_capability('mod/turnitintool:grade', get_context_instance(CONTEXT_MODULE, $_Q8OLt->id))
					OR ($turnitintool->reportgenspeed==1 AND ($turnitintool->allowlate OR $_Q88j6->dtdue>time()))) {
					$delete='<a href="'.$CFG->wwwroot.'/mod/turnitintool/view.php'.'?id='.$_Q8OLt->id.'&delete='.$_QtlC0->id.'&do='.$_REQUEST["do"].'"'.$_QCtoL.' title="'.get_string('deletesubmission','turnitintool').'"><img src="images/trashicon.gif" alt="'.get_string('deletesubmission','turnitintool').'" class="tiiicons" /></a>';
				} else {
					$delete='-';
				}
				$_QCItL[]=$_QCjff.$_QO88j;
				$_QCItL[]=$_Qol1C;
				$_QCItL[]=$_QoL66;
				$_QCItL[]=$_QC8ff;
				$_QCItL[]=$_QC8LQ;
				$_QCItL[]=$_QCQfO;
				$_QCItL[]=$delete;
				$_Qo0t8->data[]=$_QCItL;
			}
			$_QOO18.=turnitintool_print_table($_Qo0t8,true).'<br />';
			if (!$turnitintool->studentreports) {
				$_QOO18.=turnitintool_box_start('generalbox boxwidthwide boxaligncenter eightyfive', 'introduction',true);
				$_QOO18.=get_string('studentnotallowed','turnitintool');
				$_QOO18.=turnitintool_box_end(true);
			}
		}
	}
	return $_QOO18;
}
function turnitintool_array_to_object($_QtlJi) {
	$_QOO18 = new object();
	foreach ($_QtlJi as $_Qtt0O=>$_QCO80) {
		if (!empty($_Qtt0O)) {
			$_QOO18->$_Qtt0O = $_QCO80;
		}
	}
	return $_QOO18;
}
function turnitintool_overallgrade($turnitintool,$_QCOo6,$userid) {
	$_QCo8l=NULL;
	$_Q8L8C=turnitintool_get_records_select('turnitintool_parts',"turnitintoolid=".$turnitintool->id." AND deleted=0",false);
	$_Q8ILi=1;
	foreach ($_Q8L8C as $_Q88j6) {
		$_QCol0[$_Q88j6->id]=$_Q88j6->maxmarks;
	}
	$_QCCoI=array_sum($_QCol0);
	$_Q8ILi=0;
	foreach ($_QCOo6[$userid] as $_QCCLJ) {
		if (!empty($_QCCLJ->submission_grade) AND !is_null($_QCCLJ->submission_grade) AND $_QCol0[$_QCCLJ->submission_part]!=0) {
			$_QCo8l+=($_QCCLJ->submission_grade/$_QCol0[$_QCCLJ->submission_part])*($_QCol0[$_QCCLJ->submission_part]/$_QCCoI)*$turnitintool->grade;
		}
	}
	if (!is_null($_QCo8l)) {
		return number_format($_QCo8l,1);
	} else {
		return '-';
	}
}
function turnitintool_view_notes($_Q8OLt,$turnitintool,$_QCCLl,$post) {
	global $CFG,$USER;
	$_QOO18='';
	if (!$_QtlC0=turnitintool_get_record('turnitintool_submissions','id',$_QCCLl)) {
		turnitintool_print_error('submissiongeterror','turnitintool',NULL,__FILE__,__LINE__);
		exit();
	}
	if ($_QtlC0->userid==$USER->id OR has_capability('mod/turnitintool:grade', get_context_instance(CONTEXT_MODULE, $_Q8OLt->id))) {
		if ($_QCiOl=turnitintool_get_records_select('turnitintool_comments',"submissionid=".$_QtlC0->id." AND deleted=0")) {
			foreach ($_QCiOl as $_QCLIO) {
				$_QCLfI=turnitintool_get_moodleuser($_QCLIO->userid,NULL,__FILE__,__LINE__);
				$_QClQo=true;
				if (isset($post['action']) AND ($post['action']=='view' OR $post['action']=='edit') AND $post['comment']!=$_QCLIO->id) {
					$_QClQo=false;
				} else {
					$_QOO18.=turnitintool_box_start('generalbox boxwidthwide boxaligncenter eightyfive','notes',true);
					$_QOO18.='<div class="commentBlock"><div class="commentLeft"><b>'.get_string('commentby','turnitintool').':</b> '.$_QCLfI->firstname.' '.$_QCLfI->lastname.'</div>';
					$_QOO18.='<div class="commentRight"><b>'.get_string('posted','turnitintool').':</b> '.date('l, jS F Y, H:i:s',$_QCLIO->date).'</div>';
					$_QOO18.='<hr class="commentRule" />';
					$_QOO18.='<div class="commentComments">'.nl2br($_QCLIO->comment).'</div>';
					$_QOO18.='<br />
					<div class="clearBlock">&nbsp;</div>';
					if ($_QCLIO->userid==$USER->id AND ($_QCLIO->date>=time()-$turnitintool->commentedittime
					OR
					has_capability('mod/turnitintool:grade', get_context_instance(CONTEXT_MODULE, $_Q8OLt->id)))) {
						$_QoJ6l = array("\n","\r");
						$_QoJCo = array('\n','\r');
						$_QOO18.='<div class="commentBottom">
						<form action="'.$CFG->wwwroot.'/mod/turnitintool/view.php'.'?id='.$_Q8OLt->id.'&do=notes&s='.$_QtlC0->id.'" class="commentLeft" method="POST" onsubmit="return confirm(\''.str_replace($_QoJ6l, $_QoJCo, get_string('deletecommentconfirm','turnitintool')).'\')">
						<input name="action" value="delete" type="hidden" />
						<input name="comment" value="'.$_QCLIO->id.'" type="hidden" />
						<input name="submitted" value="'.get_string('deletecomment','turnitintool').'" type="submit" />
						</form>';
						$_QOO18.='<form action="'.$CFG->wwwroot.'/mod/turnitintool/view.php'.'?id='.$_Q8OLt->id.'&do=notes&s='.$_QtlC0->id.'" method="POST" class="commentRight">
						<input name="action" value="view" type="hidden" />
						<input name="comment" value="'.$_QCLIO->id.'" type="hidden" />
						<input name="submitted" value="'.get_string('editcomment','turnitintool').'" type="submit" />
						</form>';
						if (!has_capability('mod/turnitintool:grade', get_context_instance(CONTEXT_MODULE, $_Q8OLt->id))) {
							$_QOO18.='<span class="editNotice">'.get_string('edituntil','turnitintool').' '.date('l, jS F Y, H:i:s',$_QCLIO->date+$turnitintool->commentedittime).'</span>';
						}
						$_QOO18.='</div>
						<div class="clearBlock">&nbsp;</div>';
					}
					$_QOO18.='</div>';
					$_QOO18.=turnitintool_box_end(true);
				}
			}
		} else {
			$_QOO18.=turnitintool_box_start('generalbox boxwidthwide boxaligncenter eightyfive','notes',true);
			$_QOO18.=get_string('nocomments','turnitintool');
			$_QOO18.=turnitintool_box_end(true);
		}
	} else {
		turnitintool_print_error('permissiondeniederror','turnitintool',NULL,__FILE__,__LINE__);
		exit();
	}
	return $_QOO18;
}
function turnitintool_addedit_notes($_Q8OLt,$turnitintool,$_QCCLl,$post,$notice) {
	global $CFG,$USER;
	$_QOO18='';
	if (!$_QtlC0=turnitintool_get_record('turnitintool_submissions','id',$_QCCLl)) {
		turnitintool_print_error('submissiongeterror','turnitintool',NULL,__FILE__,__LINE__);
		exit();
	}
	if ($_QtlC0->userid==$USER->id OR has_capability('mod/turnitintool:grade', get_context_instance(CONTEXT_MODULE, $_Q8OLt->id))) {
		$_QClCl=get_string('addeditcomment','turnitintool');
		$_Qi0C6='<input name="action" value="add" type="hidden" />';
		if (isset($post['action']) AND ($post['action']=='view' OR $post['action']=='edit')) {
			if (!$_QCLIO=turnitintool_get_record('turnitintool_comments','id',$post["comment"])) {
				turnitintool_print_error('submissiongeterror','turnitintool',NULL,__FILE__,__LINE__);
				exit();
			}
			$_Qi0C6='<input name="action" value="edit" type="hidden" /><input name="comment" value="'.$post["comment"].'" type="hidden" />';
			$_QCiOl=$_QCLIO->comment;
		} else if (isset($post["comments"])) {
			$_QCiOl=$post["comments"];
		} else {
			$_QCiOl='';
		}
		$_QOO18.=turnitintool_box_start('generalbox boxwidthwide boxaligncenter eightyfive','notes',true);
		$_QOO18.='<b>'.$_QClCl.'</b><br />';
		$_Qo0t8->width='100%';
		$_Qo0t8->tablealign='center';
		$_Qo0t8->cellpadding='8px';
		$_Qo0t8->cellspacing='0px';
		$_Qo0t8->size=array('25%','75%');
		$_Qo0t8->align=array('right','left');
		$_Qo0t8->wrap=array('nowrap',NULL);
		$_Qo0t8->class='uploadtable';
		$_QCItL[]=get_string('comment','turnitintool').' (<span id="charsBlock">'.strlen($_QCiOl).'/'.$turnitintool->commentmaxsize.'</span> chars)';
		$_QCItL[]='<textarea class="submissionText" name="comments" onkeyup="turnitintool_countchars(this,\'charsBlock\','.$turnitintool->commentmaxsize.',\''.get_string('maxcommentjserror','turnitintool',$turnitintool->commentmaxsize).'\')" onclick="turnitintool_countchars(this,\'charsBlock\','.$turnitintool->commentmaxsize.',\''.get_string('maxcommentjserror','turnitintool',$turnitintool->commentmaxsize).'\')">'.$_QCiOl.'</textarea>';
		$_Qo0t8->data[]=$_QCItL;
		unset($_QCItL);
		$_QCItL[]='&nbsp;';
		$_QCItL[]=$_Qi0C6.'<a href="'.$CFG->wwwroot.'/mod/turnitintool/view.php'.'?id='.$_Q8OLt->id.'&do=notes&s='.$_QtlC0->id.'"><input name="cancel" value="Cancel" type="button" /></a>
		<input name="submitted" value="'.$_QClCl.'" type="submit" />';
		$_Qo0t8->data[]=$_QCItL;
		unset($_QCItL);
		$_QOO18.='<form action="'.$CFG->wwwroot.'/mod/turnitintool/view.php'.'?id='.$_Q8OLt->id.'&do=notes&s='.$_QtlC0->id.'" method="post">';
		$_QOO18.=turnitintool_print_table($_Qo0t8,true);
		$_QOO18.='</form>';
		$_QOO18.=turnitintool_box_end(true);
	} else {
		turnitintool_print_error('permissiondeniederror','turnitintool',NULL,__FILE__,__LINE__);
		exit();
	}
	return $_QOO18;
}
function turnitintool_get_moodleuser($userid,$_Qi118=NULL,$_Qi1f8=NULL,$_QiQI6=NULL) {
	if (!$user=turnitintool_get_record('user','id',$userid)) {
		turnitintool_print_error('usergeterror','turnitintool',$_Qi118,$_Qi1f8,$_QiQI6);
		exit();
	}
	if (empty($user->email)) {
		$_QiIj0=explode('.',$user->username);
		array_pop($_QiIj0);
		$user->email=join('.',$_QiIj0);
	}
	return $user;
}
function turnitintool_process_notes($_Q8OLt,$turnitintool,$_QCCLl,$post) {
	global $CFG,$USER;
	$_QOO18=array();
	if (!$_QtlC0=turnitintool_get_record('turnitintool_submissions','id',$_QCCLl)) {
		turnitintool_print_error('submissiongeterror','turnitintool',NULL,__FILE__,__LINE__);
		exit();
	}
	if ($_QtlC0->userid==$USER->id OR has_capability('mod/turnitintool:grade', get_context_instance(CONTEXT_MODULE, $_Q8OLt->id))) { 
		$_QiIJf=has_capability('mod/turnitintool:grade', get_context_instance(CONTEXT_MODULE, $_Q8OLt->id));
		if (isset($post["action"]) AND $post["action"]!="view") {
			$_QCLIO=new object();
			if (($post["action"]=="edit" OR $post["action"]=="delete") AND !$_QCLIO=turnitintool_get_record('turnitintool_comments','id',$post["comment"])) {
				turnitintool_print_error('commentgeterror','turnitintool',NULL,__FILE__,__LINE__);
				exit();
			}
			if ($post["action"]=="delete" AND (($_QCLIO->userid==$USER->id AND $_QCLIO->date>=time()-$turnitintool->commentedittime) OR $_QiIJf)) {
				$update->id=$post["comment"];
				$update->deleted=1;
				turnitintool_update_record('turnitintool_comments',$update);
				turnitintool_redirect($CFG->wwwroot.'/mod/turnitintool/view.php?id='.$_Q8OLt->id.'&do=notes&s='.$_QtlC0->id);
				exit();
			} else if (($post["action"]=="edit" AND (($_QCLIO->userid==$USER->id AND $_QCLIO->date>=time()-$turnitintool->commentedittime) OR $_QiIJf)) OR $post["action"]=="add") { 
				if (empty($post["comments"])) {
					$_QOO18['error']=true;
					$_QOO18['message']=get_string('nocommenterror','turnitintool');
				} else if (strlen($post["comments"])>$turnitintool->commentmaxsize) {
					$_QtlJi->actual=strlen($post["comments"]);
					$_QtlJi->allowed=$turnitintool->commentmaxsize;
					$_QOO18['error']=true;
					$_QOO18['message']=get_string('maxcommenterror','turnitintool',$_QtlJi);
				} else if ($post["action"]=="edit") {
					$update->id=$post["comment"];
					$update->comment=strip_tags($post["comments"]);
					$update->date=time();
					turnitintool_update_record('turnitintool_comments',$update);
					turnitintool_redirect($CFG->wwwroot.'/mod/turnitintool/view.php?id='.$_Q8OLt->id.'&do=notes&s='.$_QtlC0->id);	
					exit();
				} else {
					$_Q8OQf->submissionid=$_QtlC0->id;
					$_Q8OQf->userid=$USER->id;
					$_Q8OQf->comment=strip_tags($post["comments"]);
					$_Q8OQf->date=time();
					$_Q8OQf->deleted=0;
					turnitintool_insert_record('turnitintool_comments',$_Q8OQf,false);
					turnitintool_redirect($CFG->wwwroot.'/mod/turnitintool/view.php?id='.$_Q8OLt->id.'&do=notes&s='.$_QtlC0->id);	
					exit();
				}
			} else {
				turnitintool_print_error('permissiondeniederror','turnitintool',NULL,__FILE__,__LINE__);
				exit();
			}
		}
	} else {
		turnitintool_print_error('permissiondeniederror','turnitintool',NULL,__FILE__,__LINE__);
		exit();
	}
	return $_QOO18;
}
function turnitintool_process_options($_Q8OLt,$turnitintool,$post) {
	global $CFG, $turnitintool;
	$turnitintool->dateformat=$post['dateformat'];
	$turnitintool->autosubmission=$post['autosubmission'];
	$turnitintool->shownonsubmission=$post['shownonsubmission'];
	if (isset($post['usegrademark'])) {
		$turnitintool->usegrademark=$post['usegrademark'];
	}
	$turnitintool->gradedisplay=$post['gradedisplay'];
	$turnitintool->autoupdates=$post['autoupdates'];
	$turnitintool->commentedittime=$post['commentedittime'];
	$turnitintool->commentmaxsize=$post['commentmaxsize'];
	if (turnitintool_update_record('turnitintool',$turnitintool,false)) {
		return get_string('optionsupdatesaved','turnitintool');
	} else {
		return get_string('optionsupdateerror','turnitintool');
	}
}
function turnitintool_view_options($_Q8OLt,$turnitintool) {
	global $CFG;
	$_QOO18='<form action="'.$CFG->wwwroot.'/mod/turnitintool/view.php'.'?id='.$_Q8OLt->id.'&do=options" method="post">';
	$_QOO18.='<input name="submitted" type="hidden" value="1" />';
	$_QOO18.=turnitintool_box_start('generalbox boxwidthwide boxaligncenter eightyfive','notes',true);
	$_QOO18.='<fieldset class="clearfix"><legend>'.get_string('generalsettings','turnitintool').'</legend>';
	$_Qo0t8->width='100%';
	$_Qo0t8->tablealign='center';
	$_Qo0t8->cellpadding='4px';
	$_Qo0t8->cellspacing='0px';
	$_Qo0t8->size=array('35%','65%');
	$_Qo0t8->align=array('right','left');
	$_Qo0t8->wrap=array('nowrap',NULL);
	$_Qo0t8->class='uploadtable';
	unset($_QCItL);
	$_QCItL[0]=get_string('dateformat','turnitintool').turnitintool_help_icon('dateformat',get_string('dateformat','turnitintool'),'turnitintool',true,false,'',true);
	$_QCItL[1]='<select name="dateformat" class="formwide">';
	$_QOifJ=array('d/m/Y'=>'','d-m-Y'=>'','d/m/y'=>'','d-m-y'=>'','Y/m/d'=>'','Y-m-d'=>'','y/m/d'=>'','y-m-d'=>'');
	$_QOifJ[$turnitintool->dateformat]=' selected';
	$_QCItL[1].='<option label="DD/MM/YYYY" value="d/m/Y"'.$_QOifJ['d/m/Y'].'>DD/MM/YYYY</option>';
	$_QCItL[1].='<option label="DD-MM-YYYY" value="d-m-Y"'.$_QOifJ['d-m-Y'].'>DD-MM-YYYY</option>';
	$_QCItL[1].='<option label="YYYY/MM/DD" value="Y/m/d"'.$_QOifJ['Y/m/d'].'>YYYY/MM/DD</option>';
	$_QCItL[1].='<option label="YYYY-MM-DD" value="Y-m-d"'.$_QOifJ['Y-m-d'].'>YYYY-MM-DD</option>';
	$_QCItL[1].='</select>';
	$_Qo0t8->data[]=$_QCItL;
	unset($_QOifJ);
	$_QOifJ=array('1'=>'','0'=>'');
	$_QOifJ[$turnitintool->autosubmission]=' selected';
	unset($_QCItL);
	$_QCItL[0]=get_string('autosubmit','turnitintool').turnitintool_help_icon('autosubmit',get_string('autosubmit','turnitintool'),'turnitintool',true,false,'',true);
	$_QCItL[1]='<select name="autosubmission" class="formwide">';
	$_QCItL[1].='<option label="'.get_string('autosubmiton','turnitintool').'" value="1"'.$_QOifJ['1'].'>'.get_string('autosubmiton','turnitintool').'</option>';
	$_QCItL[1].='<option label="'.get_string('autosubmitoff','turnitintool').'" value="0"'.$_QOifJ['0'].'>'.get_string('autosubmitoff','turnitintool').'</option>';
	$_QCItL[1].='</select>';
	$_Qo0t8->data[]=$_QCItL;
	$_QOO18.=turnitintool_print_table($_Qo0t8,true);
	$_QOO18.=turnitintool_box_end(true);
	$_QOO18.='</fieldset>';
	unset($_Qo0t8->data);
	$_QOO18.=turnitintool_box_start('generalbox boxwidthwide boxaligncenter eightyfive','notes',true);
	$_QOO18.='<fieldset class="clearfix">';
	$_QOO18.='<legend>'.get_string('gradessettings','turnitintool').'</legend>';
	if ($CFG->turnitin_usegrademark) {
		unset($_QOifJ);
		$_QOifJ=array('1'=>'','0'=>'');
		$_QOifJ[$turnitintool->usegrademark]=' selected';
		unset($_QCItL);
		$_QCItL[0]=get_string('turnitinusegrademark','turnitintool').turnitintool_help_icon('turnitinusegrademark',get_string('turnitinusegrademark','turnitintool'),'turnitintool',true,false,'',true);
		$_QCItL[1]='<select name="usegrademark" class="formwide">';
		$_QCItL[1].='<option label="'.get_string('yesgrademark','turnitintool').'" value="1"'.$_QOifJ['1'].'>'.get_string('yesgrademark','turnitintool').'</option>';
		$_QCItL[1].='<option label="'.get_string('nogrademark','turnitintool').'" value="0"'.$_QOifJ['0'].'>'.get_string('nogrademark','turnitintool').'</option>';
		$_QCItL[1].='</select>';
		$_Qo0t8->data[]=$_QCItL;
	}
	unset($_QOifJ);
	$_QOifJ=array('1'=>'','2'=>'');
	$_QOifJ[$turnitintool->gradedisplay]=' selected';
	unset($_QCItL);
	$_QCItL[0]=get_string('displaygradesas','turnitintool').turnitintool_help_icon('displaygradesas',get_string('displaygradesas','turnitintool'),'turnitintool',true,false,'',true);
	$_QCItL[1]='<select name="gradedisplay" class="formwide">';
	$_QCItL[1].='<option label="'.get_string('displaygradesaspercent','turnitintool').'" value="1"'.$_QOifJ['1'].'>'.get_string('displaygradesaspercent','turnitintool').'</option>';
	$_QCItL[1].='<option label="'.get_string('displaygradesasfraction','turnitintool').'" value="2"'.$_QOifJ['2'].'>'.get_string('displaygradesasfraction','turnitintool').'</option>';
	$_QCItL[1].='</select>';
	$_Qo0t8->data[]=$_QCItL;
	unset($_QOifJ);
	$_QOifJ=array('1'=>'','0'=>'');
	$_QOifJ[$turnitintool->autoupdates]=' selected';
	unset($_QCItL);
	$_QCItL[0]=get_string('autorefreshgrades','turnitintool').turnitintool_help_icon('autorefreshgrades',get_string('autorefreshgrades','turnitintool'),'turnitintool',true,false,'',true);
	$_QCItL[1]='<select name="autoupdates" class="formwide">';
	$_QCItL[1].='<option label="'.get_string('yesgrades','turnitintool').'" value="1"'.$_QOifJ['1'].'>'.get_string('yesgrades','turnitintool').'</option>';
	$_QCItL[1].='<option label="'.get_string('nogrades','turnitintool').'" value="0"'.$_QOifJ['0'].'>'.get_string('nogrades','turnitintool').'</option>';
	$_QCItL[1].='</select>';
	$_Qo0t8->data[]=$_QCItL;
	unset($_QOifJ);
	$_QOifJ=array('1'=>'','0'=>'');
	$_QOifJ[$turnitintool->shownonsubmission]=' selected';
	unset($_QCItL);
	$_QCItL[0]=get_string('submissionlist','turnitintool').turnitintool_help_icon('submissionlist',get_string('submissionlist','turnitintool'),'turnitintool',true,false,'',true);
	$_QCItL[1]='<select name="shownonsubmission" class="formwide">';
	$_QCItL[1].='<option label="'.get_string('shownonsubmissions','turnitintool').'" value="1"'.$_QOifJ['1'].'>'.get_string('shownonsubmissions','turnitintool').'</option>';
	$_QCItL[1].='<option label="'.get_string('showonlysubmissions','turnitintool').'" value="0"'.$_QOifJ['0'].'>'.get_string('showonlysubmissions','turnitintool').'</option>';
	$_QCItL[1].='</select>';
	$_Qo0t8->data[]=$_QCItL;
	$_QOO18.=turnitintool_print_table($_Qo0t8,true);
	$_QOO18.=turnitintool_box_end(true);
	$_QOO18.='</fieldset>';
	unset($_Qo0t8->data);
	$_QOO18.=turnitintool_box_start('generalbox boxwidthwide boxaligncenter eightyfive','notes',true);
	$_QOO18.='<fieldset class="clearfix">';
	$_QOO18.='<legend>'.get_string('commentssettings','turnitintool').'</legend>';
	unset($_QCItL);
	$_QOifJ=array('0'=>'','300'=>'','600'=>'','900'=>'','1200'=>'','1500'=>'','1800'=>'','3600'=>'','7200'=>'','10800'=>'','14400'=>'','18000'=>'','21600'=>'','43200'=>'','86400'=>'');
	$_QOifJ[$turnitintool->commentedittime]=' selected';
	$_QCItL[0]=get_string('commenteditwindow','turnitintool').turnitintool_help_icon('commenteditwindow',get_string('commenteditwindow','turnitintool'),'turnitintool',true,false,'',true);
	$_QCItL[1]='<select name="commentedittime" class="formwide">';
	$_QCItL[1].='<option label="'.get_string('nolimit','turnitintool').'" value="0"'.$_QOifJ['0'].'>'.get_string('nolimit','turnitintool').'</option>';
	$_QCItL[1].='<option label="5 '.get_string('minutes','turnitintool').'" value="300"'.$_QOifJ['300'].'>5 '.get_string('minutes','turnitintool').'</option>';
	$_QCItL[1].='<option label="10 '.get_string('minutes','turnitintool').'" value="600"'.$_QOifJ['600'].'>10 '.get_string('minutes','turnitintool').'</option>';
	$_QCItL[1].='<option label="15 '.get_string('minutes','turnitintool').'" value="900"'.$_QOifJ['900'].'>15 '.get_string('minutes','turnitintool').'</option>';
	$_QCItL[1].='<option label="20 '.get_string('minutes','turnitintool').'" value="1200"'.$_QOifJ['1200'].'>20 '.get_string('minutes','turnitintool').'</option>';
	$_QCItL[1].='<option label="25 '.get_string('minutes','turnitintool').'" value="1500"'.$_QOifJ['1500'].'>25 '.get_string('minutes','turnitintool').'</option>';
	$_QCItL[1].='<option label="30 '.get_string('minutes','turnitintool').'" value="1800"'.$_QOifJ['1800'].'>30 '.get_string('minutes','turnitintool').'</option>';
	$_QCItL[1].='<option label="1 '.get_string('hours','turnitintool').'" value="3600"'.$_QOifJ['3600'].'>1 '.get_string('hours','turnitintool').'</option>';
	$_QCItL[1].='<option label="2 '.get_string('hours','turnitintool').'" value="7200"'.$_QOifJ['7200'].'>2 '.get_string('hours','turnitintool').'</option>';
	$_QCItL[1].='<option label="3 '.get_string('hours','turnitintool').'" value="10800"'.$_QOifJ['10800'].'>3 '.get_string('hours','turnitintool').'</option>';
	$_QCItL[1].='<option label="4 '.get_string('hours','turnitintool').'" value="14400"'.$_QOifJ['14400'].'>4 '.get_string('hours','turnitintool').'</option>';
	$_QCItL[1].='<option label="5 '.get_string('hours','turnitintool').'" value="18000"'.$_QOifJ['18000'].'>5 '.get_string('hours','turnitintool').'</option>';
	$_QCItL[1].='<option label="6 '.get_string('hours','turnitintool').'" value="21600"'.$_QOifJ['21600'].'>6 '.get_string('hours','turnitintool').'</option>';
	$_QCItL[1].='<option label="12 '.get_string('hours','turnitintool').'" value="43200"'.$_QOifJ['43200'].'>12 '.get_string('hours','turnitintool').'</option>';
	$_QCItL[1].='<option label="24 '.get_string('hours','turnitintool').'" value="86400"'.$_QOifJ['86400'].'>24 '.get_string('hours','turnitintool').'</option>';
	$_QCItL[1].='</select>';
	$_Qo0t8->data[]=$_QCItL;
	unset($_QCItL);
	$_QOifJ=array('100'=>'','200'=>'','300'=>'','400'=>'','500'=>'','600'=>'','700'=>'','800'=>'','900'=>'','1000'=>'','1100'=>'','1200'=>'','1300'=>'','1400'=>'','1500'=>'');
	$_QOifJ[$turnitintool->commentmaxsize]=' selected';
	$_QCItL[0]=get_string('maxcommentsize','turnitintool').turnitintool_help_icon('maxcommentsize',get_string('maxcommentsize','turnitintool'),'turnitintool',true,false,'',true);
	$_QCItL[1]='<select name="commentmaxsize" class="formwide">';
	for ($_Q8ILi=1;$_Q8ILi<=15;$_Q8ILi++) {
		$_Q8l6J=$_Q8ILi*100;
		$_QCItL[1].='<option label="'.$_Q8l6J.' '.get_string('characters','turnitintool').'" value="'.$_Q8l6J.'"'.$_QOifJ[$_Q8l6J].'>'.$_Q8l6J.' '.get_string('characters','turnitintool').'</option>';
	}
	$_QCItL[1].='</select>';
	$_Qo0t8->data[]=$_QCItL;
	$_QOO18.=turnitintool_print_table($_Qo0t8,true);
	$_QOO18.=turnitintool_box_end(true);
	$_QOO18.='</fieldset>';
	unset($_Qo0t8->data);
	$_QOO18.=turnitintool_box_start('generalbox boxwidthwide boxaligncenter eightyfive','notes',true);
	$_QOO18.=turnitintool_print_table($_Qo0t8,true);
	unset($_QCItL);
	$_QCItL[0]='';
	$_QCItL[1]='<input type="submit" value="'.get_string('savechanges','turnitintool').'" />';
	$_Qo0t8->data[]=$_QCItL;
	$_QOO18.=turnitintool_print_table($_Qo0t8,true);
	$_QOO18.=turnitintool_box_end(true);
	$_QOO18.='</form>';
	return $_QOO18;
}
function turnitintool_doheaderlinks($_Q8OLt,$turnitintool,$_QClCl,$_QiIf1,$_QiIoI) {
	global $CFG;
	$_QiICC='<a href="'.$CFG->wwwroot.'/mod/turnitintool/view.php?id='.$_Q8OLt->id.'&do='.$_REQUEST["do"].'&ob=%%OB%%">'.$_QClCl.'</a>';
	if (isset($_REQUEST["ob"]) AND $_REQUEST["ob"]==$_QiIf1) {
		$_QiICC.=' <img src="images/order_down.gif" class="ordericons" />';
		$_QiICC=str_replace('%%OB%%',$_QiIoI,$_QiICC);
	} else if (isset($_REQUEST["ob"]) AND $_REQUEST["ob"]==$_QiIoI) {
		$_QiICC.=' <img src="images/order_up.gif" class="ordericons" />';
		$_QiICC=str_replace('%%OB%%',$_QiIf1,$_QiICC);
	} else if (!isset($_REQUEST["ob"]) AND $_QiIf1==1) {
		$_QiICC.=' <img src="images/order_down.gif" class="ordericons" />';
		$_QiICC=str_replace('%%OB%%',$_QiIoI,$_QiICC);
	} else {
		$_QiICC=str_replace('%%OB%%',$_QiIf1,$_QiICC);
	}
	return $_QiICC;
}
function turnitintool_revealuser($_Q8OLt,$turnitintool,$post) {
	global $CFG;
	$_QiILJ=$post["anonid"];
	$_QtlC0=turnitintool_get_record('turnitintool_submissions','submission_objectid',$_QiILJ);
	$_Q8ftf=$post["reason"][$_QiILJ];
	if ($_Q8ftf==get_string('revealreason','turnitintool') OR empty($_Q8ftf)) {
		turnitintool_print_error('revealerror','turnitintool',$CFG->wwwroot.'/mod/turnitintool/view.php?id='.$_Q8OLt->id.'&do=allsubmissions',NULL,__FILE__,__LINE__);
		exit();
	} else {
		$_QfloJ = new TIIToolClass;
		$owner=turnitintool_get_owner($turnitintool->course);
		$_Q8jIQ->uid=turnitintool_getUID($owner);
		$_Q8jIQ->cid=turnitintool_getCID($turnitintool->course);
		$_Q8jIQ->paperid=$_QtlC0->submission_objectid;
		$_Q8jIQ->utp=2;
		$_Q8jIQ->anon_reason=$_Q8ftf;
		$_QtlJi->from=1;
		$_QtlJi->to=1;
		$_Q8J1f=$_QfloJ->revealAnon($_Q8jIQ,$owner,1,1,get_string('updatestudent','turnitintool',$_QtlJi));
		$_Q8Jii=$_QfloJ->getRcode($_Q8J1f);
		$_Q86oL=false;
		if (!empty($_Q8Jii) AND $_Q8Jii>100) {
			$_Q86oL=true;
			$_Q8ftf=$_QfloJ->getRmessage($_Q8J1f);
		} else if (empty($_Q8Jii)) {
			$_Q86oL=true;
			$_Q8ftf=get_string('apiunavailable','turnitintool');
		}
		if ($_Q86oL) {
			turnitintool_print_error('<strong>'.get_string('submissionupdateerror','turnitintool').'</strong><br />'.$_Q8ftf,NULL,NULL,NULL,__FILE__,__LINE__);
			exit();
		}
		$update->id=$_QtlC0->id;
		$update->submission_unanon=1;
		$update->submission_unanonreason=$_Q8ftf;
		turnitintool_update_record('turnitintool_submissions',$update);
	}
}
function turnitintool_view_all_submissions($_Q8OLt,$turnitintool,$_Qijto='1') {
	global $CFG;
	$_QfloJ=new TIIToolClass;
	$_QiJ8f=array();
	$_QOO18='';
	$_QiJLi=$CFG->prefix.'turnitintool_submissions';
	$_Qi6LI=$CFG->prefix.'user';
	$_QifjI=$CFG->prefix.'turnitintool';
	$_Qifij=$CFG->prefix.'turnitintool_parts';
	$_Qi86L=$CFG->prefix.'role_assignments';
	$_Qit1j=get_roles_with_capability('moodle/legacy:student', CAP_ALLOW);
	$_QiO10='';
	foreach ($_Qit1j as $_QiOL1) {
		if (!empty($_QiO10)) {
			$_QiO10.=" OR ";
		}
		$_QiO10.="r.roleid=".$_QiOL1->id."";
	}
	$_QttoQ = get_context_instance(CONTEXT_COURSE, $turnitintool->course);
	$_Qioj1=turnitintool_get_records_sql("SELECT id,collation(firstname) collation FROM ".$CFG->prefix."user");
	$_QiCIJ=current($_Qioj1);
	$_QiCio=$_QiCIJ->collation;
	$_QiiJl='';
	$_Qiiol='
		<style>
			.gradeTable div.leftmark {
				padding-left: 18px;
				background-image: url(images/leftmarker.gif);
				background-position: 5px center;
				background-repeat: no-repeat;
			}
			.gradeTable div.lastmark {
				padding-left: 18px;
				background-image: url(images/leftmarkerlast.gif);
				background-position: 5px center;
				background-repeat: no-repeat;
			}
			.gradeTable a.fileicon {
				padding-left: 18px;
				background-image: url(images/fileicon.gif);
				background-position: 2px 0px;
				background-repeat: no-repeat;
			}
		</style>';
	$_QiiCo=true;
	if ($turnitintool->numparts!=1 AND !$turnitintool->anon) { 
		if ($turnitintool->shownonsubmission) {
			$_QiiJl.="(SELECT u.id AS userid,u.firstname COLLATE ".$_QiCio." AS firstname,u.lastname COLLATE ".$_QiCio." AS lastname,AVG(s.submission_score) avscore,AVG(s.submission_grade) avgrade,MAX(s.submission_objectid) lastid,MIN(s.submission_objectid) firstid,0 nonmoodle,MAX(s.submission_unanon) unanon,COUNT(s.submission_objectid) count,MAX(s.submission_score) highscore,MIN(s.submission_score) lowscore,MIN(s.submission_modified) mindate,MAX(s.submission_modified) maxdate FROM ".$_Qi86L." r JOIN ".$_Qi6LI." u ON u.id=r.userid LEFT OUTER JOIN ".$_QiJLi." s ON s.userid=u.id AND s.turnitintoolid=".$turnitintool->id." WHERE r.contextid=".$_QttoQ->id." AND (".$_QiO10.") GROUP BY userid) UNION ";
		}
		$_QiiJl.="(SELECT concat('nm-',submission_nmuserid) COLLATE ".$_QiCio." AS userid,submission_nmfirstname COLLATE ".$_QiCio." AS firstname,submission_nmlastname COLLATE ".$_QiCio." AS lastname,AVG(submission_score) avscore,AVG(submission_grade) avgrade,MAX(submission_objectid) lastid,MIN(submission_objectid) firstid,1 nonmoodle,MAX(submission_unanon) unanon,COUNT(submission_objectid) count,MAX(submission_score) highscore,MIN(submission_score) lowscore,MIN(submission_modified) mindate,MAX(submission_modified) maxdate FROM ".$_QiJLi." WHERE userid=0 AND turnitintoolid=".$turnitintool->id." GROUP BY userid,firstname,lastname) UNION (SELECT s.userid AS userid,u.firstname COLLATE ".$_QiCio." AS firstname,u.lastname COLLATE ".$_QiCio." AS lastname,AVG(s.submission_score) avscore,AVG(s.submission_grade) avgrade,MAX(s.submission_objectid) lastid,MIN(s.submission_objectid) firstid,0 nonmoodle,MAX(s.submission_unanon) unanon,COUNT(s.submission_objectid) count,MAX(s.submission_score) highscore,MIN(s.submission_score) lowscore,MIN(s.submission_modified) mindate,MAX(s.submission_modified) maxdate FROM ".$_QiJLi." s JOIN ".$_Qi6LI." u ON u.id=s.userid WHERE s.userid!=0 AND s.turnitintoolid=".$turnitintool->id." GROUP BY userid)";
		if ($_Qijto=='1') {
			$_QiL18=' ORDER BY ABS(avscore) DESC,lastname ASC';
			$_QiLOL='ABS(submission_score) DESC';
		} else if ($_Qijto=='2') {
			$_QiL18=' ORDER BY ABS(avscore) ASC,lastname ASC';
			$_QiLOL='ABS(submission_score) ASC';
		} else if ($_Qijto=='3') {
			$_QiL18=' ORDER BY ABS(avgrade) DESC,lastname ASC';
			$_QiLOL='ABS(submission_grade) DESC';
		} else if ($_Qijto=='4') {
			$_QiL18=' ORDER BY ABS(avgrade) ASC,lastname ASC';
			$_QiLOL='ABS(submission_grade) ASC';
		} else if ($_Qijto=='5') {
			$_QiL18=' ORDER BY ABS(maxdate) DESC,lastname ASC';
			$_QiLOL='ABS(submission_modified) DESC';
		} else if ($_Qijto=='6') {
			$_QiL18=' ORDER BY ABS(mindate) ASC,lastname ASC';
			$_QiLOL='ABS(submission_modified) ASC';
		} else if ($_Qijto=='7') {
			$_QiL18=' ORDER BY lastname DESC';
			$_QiLOL='submission_title DESC';
		} else if ($_Qijto=='8') {
			$_QiL18=' ORDER BY lastname ASC';
			$_QiLOL='submission_title ASC';
		}
		if (!$_QilO1=turnitintool_get_records_sql($_QiiJl.$_QiL18)) {
			$_QilO1=array();
		} else {
			$_QiiCo=false;
			$_Qiloo='';
			$_QL088='';
			$_Q8ILi=1;
			foreach ($_QilO1 as $_Qtt0O=>$_QL0tj) {
				if ($_Q8ILi==count($_QilO1)) {
					$_QL1j1='';
				} else {
					$_QL1j1=',';
				}
				$_Qiloo.='"'.$_QL0tj->userid.'"'.$_QL1j1;
				$_QL088.='"'.$_QL0tj->count.'"'.$_QL1j1;
				$_Q8ILi++;
			}
			$_QOO18.= $_Qiiol.'
		<script language="javascript" type="text/javascript">
			var users= new Array('.$_Qiloo.');
			var count= new Array('.$_QL088.');
		</script>
		<script src="turnitintool.js" language="javascript" type="text/javascript"></script>
			';
		}
		foreach ($_QilO1 as $_Qtt0O=>$_QL0tj) {
			if (!$_QL0tj->nonmoodle) {
				$_QL1fo="userid=".$_QL0tj->userid." AND turnitintoolid=".$turnitintool->id;
			} else {
				$_QL1fo="submission_nmuserid='".str_replace('nm-','',$_QL0tj->userid)."' AND turnitintoolid=".$turnitintool->id;
			}
			$_QLQ11='SELECT * FROM '.$_QiJLi.' WHERE '.$_QL1fo.' ORDER BY '.$_QiLOL;
			if ($_Q8lfO=turnitintool_get_records_select('turnitintool_submissions',$_QL1fo,$_QiLOL)) {
				if ($_QL0tj->count>0) { 
					$_QLQQ1='
					<script language="javascript" type="text/javascript">
					document.write("<a href=\"javascript:;\" onclick=\"toggleview(\''.$_QL0tj->userid.'\',\''.$_QL0tj->count.'\');\">");
					</script>
					<img src="images/clearpixel.gif" class="plusminus" id="userblock_'.$_QL0tj->userid.'" />
					<script language="javascript" type="text/javascript">
					document.write(\'</a>\');
					document.getElementById(\'userblock_'.$_QL0tj->userid.'\').src="images/plus.gif";
					</script>';
				} else { 
					$_QLQQ1='
					<img src="images/clearpixel.gif" class="plusminus" id="userblock_'.$_QL0tj->userid.'" />
					';
				}
				if ($_QL0tj->nonmoodle) {
					$_Qo18O['student']='<div class="student"><i>'.$_QLQQ1.$_QL0tj->lastname.', '.$_QL0tj->firstname.' ('.get_string('nonmoodleuser','turnitintool').')</i> - ('.$_QL0tj->count.' '.get_string('submissions','turnitintool').')</div>';
				} else {
					$_Qo18O['student']='<div class="student">'.$_QLQQ1.'<a href="'.$CFG->wwwroot.'/user/view.php?id='.$_QL0tj->userid.'&course='.$turnitintool->course.'">'.$_QL0tj->lastname.', '.$_QL0tj->firstname.'</a> - ('.$_QL0tj->count.' '.get_string('submissions','turnitintool').')</div>';
				}
				$_Qo18O['modified']='<div class="student">&nbsp;</div>';
				$_QoL66=($_QL0tj->lowscore==$_QL0tj->highscore OR empty($_QL0tj->lowscore)) ? $_QL0tj->highscore.'%' : $_QL0tj->lowscore.'%>'.$_QL0tj->highscore.'%';
				if ($_QoL66=='%') {
					$_QoL66='-';
				}
				$_Qo18O['score']='<div class="student">'.$_QoL66.'</div>';
				$_QCOo6[$_QL0tj->userid]=$_Q8lfO;
				$_QCo8l=turnitintool_overallgrade($turnitintool,$_QCOo6,$_QL0tj->userid);
				if ($_QCo8l!='-' AND $turnitintool->gradedisplay==2) { 
					$_QCo8l.='/'.$turnitintool->grade;
				} else if ($_QCo8l!='-' AND $turnitintool->gradedisplay==1) { 
					$_QCo8l=round($_QCo8l/$turnitintool->grade*100,1).'%';
				}
				$_Qo18O['grade']='<div class="student">'.$_QCo8l.'</div>';
				$_Qo18O['feedback']='<div class="student">&nbsp;</div>';
				$_Qo18O['download']='<div class="student">&nbsp;</div>';
				$_Qo18O['delete']='<div class="student">&nbsp;</div>';
				$_QiJ8f[]=$_Qo18O;
				$_Q8ILi=0;
				foreach ($_Q8lfO as $_QtlC0) {
					$_Q8ILi++;
					$_QLQIf=($_Q8ILi==$_QL0tj->count) ? ' lastmark' : ' leftmark';
					if (!$_Q88j6=turnitintool_get_record('turnitintool_parts','id',$_QtlC0->submission_part)) {
						turnitintool_print_error('partgeterror','turnitintool',NULL,__FILE__,__LINE__);
						exit();
					}
					$_QCIj0=turnitintool_get_filelink($_Q8OLt,$turnitintool,$_QtlC0);
					$_QCJC6='';
					if (!empty($_QtlC0->submission_objectid)) {
						$_QCJC6=' onclick="screenOpen(\''.$_QCIj0.'\',\''.$_QtlC0->id.'\',\''.$turnitintool->autoupdates.'\');return false;"';
					}
					$_Qo18O['student']='<div id="toggle_'.$_QL0tj->userid.'_'.$_Q8ILi.'_1" class="submission'.$_QLQIf.'"><a href="'.$_QCIj0.'" target="_blank" class="fileicon"'.$_QCJC6.'>'.$_Q88j6->partname.' - '.$_QtlC0->submission_title.'</a></div>';
					$_QLQff='-';
					if (empty($_QtlC0->submission_objectid) AND $turnitintool->autosubmission) {
						$_QLQff='<div class="submittoLinkSmall"><img src="'.$CFG->wwwroot.'/mod/turnitintool/icon.gif" /><a href="'.$CFG->wwwroot.'/mod/turnitintool/view.php'.'?id='.$_Q8OLt->id.'&up='.$_QtlC0->id.'">'.get_string('submittoturnitin','turnitintool').'</a></div>';
					} else if (!is_null($_QtlC0->id)) {
						$_QLQff=(empty($_QtlC0->submission_objectid)) ? '-' : date($turnitintool->dateformat.', h:i A',$_QtlC0->submission_modified);
						if ($_QtlC0->submission_modified>$_Q88j6->dtdue) {
							$_QLQff='<span style="color: red;">'.$_QLQff.'</span>';
						}
					}
					$_Qo18O['modified']='<div id="toggle_'.$_QL0tj->userid.'_'.$_Q8ILi.'_2" class="submission">'.$_QLQff.'</div>';
					$_QoL66 = turnitintool_draw_similarityscore($_Q8OLt,$turnitintool,$_QtlC0);
					$_Qo18O['score']='<div id="toggle_'.$_QL0tj->userid.'_'.$_Q8ILi.'_3" class="submission">'.$_QoL66.'</div>';
					$_QC8ff=turnitintool_dogradeoutput($_Q8OLt,$turnitintool,$_QtlC0);
					$_Qo18O['grade']='<div id="toggle_'.$_QL0tj->userid.'_'.$_Q8ILi.'_4" class="submission"><form action="'.$CFG->wwwroot.'/mod/turnitintool/view.php'.'?id='.$_Q8OLt->id.'&do=allsubmissions" method="POST">'.$_QC8ff.'</form></div>';
					if (!$_QL0tj->nonmoodle) {
						$_QC8LQ=turnitintool_getnoteslink($_Q8OLt,$turnitintool,$_QtlC0);
					} else {
						$_QC8LQ='-';
					}
					$_Qo18O['feedback']='<div id="toggle_'.$_QL0tj->userid.'_'.$_Q8ILi.'_5" class="submission">'.$_QC8LQ.'</div>';
					if (!is_null($_QtlC0->submission_objectid)) {
						$_QCQfO='<a href="'.turnitintool_get_filelink($_Q8OLt,$turnitintool,$_QtlC0,$_QCQfO=true).'" title="'.get_string('downloadsubmission','turnitintool').'" target="_blank"><img src="images/downloadicon.gif" alt="'.get_string('downloadsubmission','turnitintool').'" class="tiiicons" /></a>';
					} else {
						$_QCQfO='';
					}
					$_Qo18O['download']='<div id="toggle_'.$_QL0tj->userid.'_'.$_Q8ILi.'_6" class="submission" target="_blank">'.$_QCQfO.'</div>';
					$_QoJ6l = array("\n","\r");
					$_QoJCo = array('\n','\r');
					if (empty($_QtlC0->submission_objectid)) {
						$_QCtoL=' onclick="return confirm(\''.str_replace($_QoJ6l, $_QoJCo, get_string('deleteconfirm','turnitintool')).'\');"';
					} else {
						$_QCtoL=' onclick="return confirm(\''.str_replace($_QoJ6l, $_QoJCo, get_string('turnitindeleteconfirm','turnitintool')).'\')"';
					}
					if (empty($_QtlC0->submission_objectid) OR has_capability('mod/turnitintool:grade', get_context_instance(CONTEXT_MODULE, $_Q8OLt->id))) {
						$delete='<a href="'.$CFG->wwwroot.'/mod/turnitintool/view.php'.'?id='.$_Q8OLt->id.'&delete='.$_QtlC0->id.'&do='.$_REQUEST["do"].'"'.$_QCtoL.' title="'.get_string('deletesubmission','turnitintool').'"><img src="images/trashicon.gif" alt="'.get_string('deletesubmission','turnitintool').'" class="tiiicons" /></a>';
					} else {
						$delete='-';
					}
					$_Qo18O['delete']='<div id="toggle_'.$_QL0tj->userid.'_'.$_Q8ILi.'_7" class="submission">'.$delete.'</div>';
					$_QiJ8f[]=$_Qo18O;
				}
			} else {
				$_QLQQ1='
					<img src="images/clearpixel.gif" class="plusminus" id="userblock_'.$_QL0tj->userid.'" />
					';
				$_Qo18O['student']='<div class="student">'.$_QLQQ1.'<a href="'.$CFG->wwwroot.'/user/view.php?id='.$_QL0tj->userid.'&course='.$turnitintool->course.'">'.$_QL0tj->lastname.', '.$_QL0tj->firstname.'</a> - ('.$_QL0tj->count.' '.get_string('submissions','turnitintool').')</div>';
				$_Qo18O['modified']='<div class="student">&nbsp;</div>';
				$_Qo18O['score']='<div class="student">&nbsp;</div>';
				$_Qo18O['grade']='<div class="student">&nbsp;</div>';
				$_Qo18O['feedback']='<div class="student">&nbsp;</div>';
				$_Qo18O['download']='<div class="student">&nbsp;</div>';
				$_Qo18O['delete']='<div class="student">&nbsp;</div>';
				$_QiJ8f[]=$_Qo18O;
			}
		}
	} else if (!$turnitintool->anon) { 
		if ($turnitintool->shownonsubmission) {
			$_QiiJl.="(SELECT u.id AS userid,u.firstname COLLATE ".$_QiCio." AS firstname,u.lastname COLLATE ".$_QiCio." AS lastname,s.submission_score submission_score,s.submission_grade submission_grade,MAX(s.submission_objectid) submission_objectid,0 nonmoodle,s.id id,s.submission_part submission_part,s.submission_filename submission_filename,s.submission_title submission_title,s.submission_gmimaged submission_gmimaged,s.submission_modified submission_modified FROM ".$_Qi86L." r JOIN ".$_Qi6LI." u ON u.id=r.userid LEFT OUTER JOIN ".$_QiJLi." s ON s.userid=u.id AND s.turnitintoolid=".$turnitintool->id." WHERE r.contextid=".$_QttoQ->id." AND (".$_QiO10.") GROUP BY userid) UNION ";
		}
		$_QiiJl.="(SELECT concat('nm-',submission_nmuserid) COLLATE ".$_QiCio." AS userid,submission_nmfirstname COLLATE ".$_QiCio." AS firstname,submission_nmlastname COLLATE ".$_QiCio." AS lastname,submission_score,submission_grade,MAX(submission_objectid),1 nonmoodle,id,submission_part,submission_filename,submission_title,submission_gmimaged,submission_modified FROM ".$_QiJLi." WHERE userid=0 AND turnitintoolid=".$turnitintool->id." GROUP BY userid,firstname,lastname) UNION (SELECT s.userid AS userid,u.firstname COLLATE ".$_QiCio." AS firstname,u.lastname COLLATE ".$_QiCio." AS lastname,s.submission_score submission_score,s.submission_grade submission_grade,MAX(s.submission_objectid) submission_objectid,0 nonmoodle,s.id id,s.submission_part submission_part,s.submission_filename submission_filename,s.submission_title submission_title,s.submission_gmimaged submission_gmimaged,s.submission_modified submission_modified FROM ".$_QiJLi." s JOIN ".$_Qi6LI." u ON u.id=s.userid WHERE s.userid!=0 AND s.turnitintoolid=".$turnitintool->id." GROUP BY userid)";
		if ($_Qijto=='1') {
			$_QiL18=' ORDER BY ABS(submission_score) DESC,lastname ASC';
		} else if ($_Qijto=='2') {
			$_QiL18=' ORDER BY ABS(submission_score) ASC,lastname ASC';
		} else if ($_Qijto=='3') {
			$_QiL18=' ORDER BY ABS(submission_grade) DESC,lastname ASC';
		} else if ($_Qijto=='4') {
			$_QiL18=' ORDER BY ABS(submission_grade) ASC,lastname ASC';
		} else if ($_Qijto=='5') {
			$_QiL18=' ORDER BY ABS(submission_modified) DESC,lastname ASC';
		} else if ($_Qijto=='6') {
			$_QiL18=' ORDER BY ABS(submission_modified) ASC,lastname ASC';
		} else if ($_Qijto=='7') {
			$_QiL18=' ORDER BY lastname DESC';
		} else if ($_Qijto=='8') {
			$_QiL18=' ORDER BY lastname ASC';
		}
		if (!$_Q8lfO=turnitintool_get_records_sql($_QiiJl.$_QiL18)) {
			$_Q8lfO=array();
		} else {
			$_QiiCo=false;
		}
		foreach ($_Q8lfO as $_QtlC0) {
			if (is_null($_QtlC0->id)) {
				$_Qo18O['student']='<div class="student"><b>'.get_string('file').':</b> '.get_string('nosubmission','turnitintool').'<br /><b>'.get_string('student','turnitintool').':</b> <a href="'.$CFG->wwwroot.'/user/view.php?id='.$_QtlC0->userid.'&course='.$turnitintool->course.'">'.$_QtlC0->lastname.', '.$_QtlC0->firstname.'</a></div>';
				$_Qo18O['modified']='<div class="student">&nbsp;</div>';
				$_Qo18O['score']='<div class="student">&nbsp;</div>';
				$_Qo18O['grade']='<div class="student">&nbsp;</div>';
				$_Qo18O['feedback']='<div class="student">&nbsp;</div>';
				$_Qo18O['download']='<div class="student">&nbsp;</div>';
				$_Qo18O['delete']='<div class="student">&nbsp;</div>';
				$_QiJ8f[]=$_Qo18O;
			} else {
				$_QCIj0=turnitintool_get_filelink($_Q8OLt,$turnitintool,$_QtlC0);
				if (!$_Q88j6=turnitintool_get_record('turnitintool_parts','id',$_QtlC0->submission_part)) {
					turnitintool_print_error('partgeterror','turnitintool',NULL,__FILE__,__LINE__);
					exit();
				}
				$_QCJC6='';
				if (!empty($_QtlC0->submission_objectid)) {
					$_QCJC6=' onclick="screenOpen(\''.$_QCIj0.'\',\''.$_QtlC0->id.'\',\''.$turnitintool->autoupdates.'\');return false;"';
				}
				if (!$_QtlC0->nonmoodle) {
					$_QLQi8='<a href="'.$CFG->wwwroot.'/user/view.php?id='.$_QtlC0->userid.'&course='.$turnitintool->course.'">'.$_QtlC0->lastname.', '.$_QtlC0->firstname.'</a>';
				} else {
					$_QLQi8='<i>'.$_QtlC0->lastname.', '.$_QtlC0->firstname.' ('.get_string('nonmoodleuser','turnitintool').')</i>';
				}
				$_Qo18O['student']='<div class="student"><b>'.get_string('file').':</b> <a href="'.$_QCIj0.'" target="_blank" class="tiiicons"'.$_QCJC6.'>'.$_QtlC0->submission_title.'</a><br /><b>'.get_string('student','turnitintool').'</b>: '.$_QLQi8.'</div>';
				$_QLQff='-';
				if (empty($_QtlC0->submission_objectid) AND $turnitintool->autosubmission) {
					$_QLQff='<div class="submittoLinkSmall"><img src="'.$CFG->wwwroot.'/mod/turnitintool/icon.gif" /><a href="'.$CFG->wwwroot.'/mod/turnitintool/view.php'.'?id='.$_Q8OLt->id.'&up='.$_QtlC0->id.'">'.get_string('submittoturnitin','turnitintool').'</a></div>';
				} else if (!is_null($_QtlC0->id)) {
					$_QLQff=(empty($_QtlC0->submission_objectid)) ? '-' : date($turnitintool->dateformat.', h:i A',$_QtlC0->submission_modified);
					if ($_QtlC0->submission_modified>$_Q88j6->dtdue) {
						$_QLQff='<span style="color: red;">'.$_QLQff.'</span>';
					}
				}
				$_Qo18O['modified']='<div class="student">'.$_QLQff.'</div>';
				$_QoL66 = turnitintool_draw_similarityscore($_Q8OLt,$turnitintool,$_QtlC0);
				$_Qo18O['score']='<div class="student">'.$_QoL66.'</div>';
				$_QC8ff=turnitintool_dogradeoutput($_Q8OLt,$turnitintool,$_QtlC0);
				$_Qo18O['grade']='<div class="student"><form action="'.$CFG->wwwroot.'/mod/turnitintool/view.php'.'?id='.$_Q8OLt->id.'&do=allsubmissions" method="POST">'.$_QC8ff.'</form></div>';
				if (!$_QtlC0->nonmoodle) {
					$_QC8LQ=turnitintool_getnoteslink($_Q8OLt,$turnitintool,$_QtlC0);
				} else {
					$_QC8LQ='-';
				}
				$_Qo18O['feedback']='<div class="student">'.$_QC8LQ.'</div>';
				$_QoJ6l = array("\n","\r");
				$_QoJCo = array('\n','\r');
				if (empty($_QtlC0->submission_objectid)) {
					$_QCtoL=' onclick="return confirm(\''.str_replace($_QoJ6l, $_QoJCo, get_string('deleteconfirm','turnitintool')).'\');"';
				} else {
					$_QCtoL=' onclick="return confirm(\''.str_replace($_QoJ6l, $_QoJCo, get_string('turnitindeleteconfirm','turnitintool')).'\')"';
				}
				if (!is_null($_QtlC0->submission_objectid)) {
					$_QCQfO='<a href="'.turnitintool_get_filelink($_Q8OLt,$turnitintool,$_QtlC0,$_QCQfO=true).'" title="'.get_string('downloadsubmission','turnitintool').'" target="_blank"><img src="images/downloadicon.gif" alt="'.get_string('downloadsubmission','turnitintool').'" class="tiiicons" /></a>';
				} else {
					$_QCQfO='';
				}
				$_Qo18O['download']='<div class="student">'.$_QCQfO.'</div>';
				if (empty($_QtlC0->submission_objectid) OR has_capability('mod/turnitintool:grade', get_context_instance(CONTEXT_MODULE, $_Q8OLt->id))) {
					$delete='<a href="'.$CFG->wwwroot.'/mod/turnitintool/view.php'.'?id='.$_Q8OLt->id.'&delete='.$_QtlC0->id.'&do='.$_REQUEST["do"].'"'.$_QCtoL.' title="'.get_string('deletesubmission','turnitintool').'"><img src="images/trashicon.gif" alt="'.get_string('deletesubmission','turnitintool').'" class="tiiicons" /></a>';
				} else {
					$delete='-';
				}
				$_Qo18O['delete']='<div class="student">'.$delete.'</div>';
				$_QiJ8f[]=$_Qo18O;
			}
		}
	} else { 
		if (!$_Q8L8C=turnitintool_get_records_select('turnitintool_parts','turnitintoolid='.$turnitintool->id.' AND deleted=0','dtstart,dtdue,dtpost,id')) {
			turnitintool_print_error('partgeterror','turnitintool',NULL,__FILE__,__LINE__);
			exit();
		} else {
			$_QiiCo=false; 
		}
		$_Qiloo=''; 
		$_QL088=''; 
		$_Q8l6J=0;
		foreach ($_Q8L8C as $_Q88j6) { 
			$_QiiJl='';
			if ($turnitintool->shownonsubmission) { 
				$_QiiJl.="(SELECT u.id AS userid,u.firstname COLLATE ".$_QiCio." AS firstname,u.lastname COLLATE ".$_QiCio." AS lastname,s.submission_score submission_score,s.submission_grade submission_grade,MAX(s.submission_objectid) submission_objectid,0 nonmoodle,s.id id,".$_Q88j6->id." submission_part,s.submission_filename submission_filename,s.submission_title submission_title,s.submission_gmimaged submission_gmimaged,s.submission_unanon unanon,s.submission_modified submission_modified FROM ".$_Qi86L." r JOIN ".$_Qi6LI." u ON u.id=r.userid LEFT OUTER JOIN ".$_QiJLi." s ON s.userid=u.id AND s.turnitintoolid=".$turnitintool->id." AND s.submission_part=".$_Q88j6->id." WHERE r.contextid=".$_QttoQ->id." AND (".$_QiO10.") GROUP BY userid) UNION ";
			}
			$_QiiJl.="(SELECT concat('nm-',submission_nmuserid) COLLATE ".$_QiCio." AS userid,submission_nmfirstname COLLATE ".$_QiCio." AS firstname,submission_nmlastname COLLATE ".$_QiCio." AS lastname,submission_score,submission_grade,MAX(submission_objectid),1 nonmoodle,id,".$_Q88j6->id." submission_part,submission_filename,submission_title,submission_gmimaged,submission_unanon unanon,submission_modified FROM ".$_QiJLi." WHERE userid=0 AND turnitintoolid=".$turnitintool->id." AND submission_part=".$_Q88j6->id." GROUP BY userid,firstname,lastname) UNION (SELECT s.userid AS userid,u.firstname COLLATE ".$_QiCio." AS firstname,u.lastname COLLATE ".$_QiCio." AS lastname,s.submission_score submission_score,s.submission_grade submission_grade,MAX(s.submission_objectid) submission_objectid,0 nonmoodle,s.id id,".$_Q88j6->id." submission_part,s.submission_filename submission_filename,s.submission_title submission_title,s.submission_gmimaged submission_gmimaged,s.submission_unanon unanon,s.submission_modified submission_modified FROM ".$_QiJLi." s JOIN ".$_Qi6LI." u ON u.id=s.userid WHERE s.userid!=0 AND s.turnitintoolid=".$turnitintool->id." AND s.submission_part=".$_Q88j6->id." GROUP BY userid)";
			if ($_Qijto=='1') {
				$_QiL18=' ORDER BY ABS(submission_score) DESC,lastname ASC';
			} else if ($_Qijto=='2') {
				$_QiL18=' ORDER BY ABS(submission_score) ASC,lastname ASC';
			} else if ($_Qijto=='3') {
				$_QiL18=' ORDER BY ABS(submission_grade) DESC,lastname ASC';
			} else if ($_Qijto=='4') {
				$_QiL18=' ORDER BY ABS(submission_grade) ASC,lastname ASC';
			} else if ($_Qijto=='5') {
				$_QiL18=' ORDER BY ABS(submission_modified) DESC,lastname ASC';
			} else if ($_Qijto=='6') {
				$_QiL18=' ORDER BY ABS(submission_modified) ASC,lastname ASC';
			} else if ($_Qijto=='7') {
				$_QiL18=' ORDER BY lastname DESC';
			} else if ($_Qijto=='8') {
				$_QiL18=' ORDER BY lastname ASC';
			}
			if (!$_Q8lfO=turnitintool_get_records_sql($_QiiJl.$_QiL18)) {
				$_Q8lfO=array();
			}
			if (count($_Q8lfO)) { 
				$_QLQQ1='
				<script language="javascript" type="text/javascript">
				document.write("<a href=\"javascript:;\" onclick=\"toggleview(\''.$_Q88j6->id.'\',\''.count($_Q8lfO).'\');\">");
				</script>
				<img src="images/clearpixel.gif" class="plusminus" id="userblock_'.$_Q88j6->id.'" />
				<script language="javascript" type="text/javascript">
				document.write(\'</a>\');
				document.getElementById(\'userblock_'.$_Q88j6->id.'\').src="images/plus.gif";
				</script>';
			} else { 
				$_QLQQ1='
				<img src="images/clearpixel.gif" class="plusminus" id="userblock_'.$_Q88j6->id.'" />
				';
			}
			$_Qo18O['student']='<div class="student"><b>'.$_QLQQ1.$_Q88j6->partname.'</b></div>';
			$_Qo18O['modified']='<div class="student">&nbsp;</div>';
			$_Qo18O['score']='<div class="student">&nbsp;</div>';
			$_Qo18O['grade']='<div class="student">&nbsp;</div>';
			$_Qo18O['feedback']='<div class="student">&nbsp;</div>';
			$_Qo18O['download']='<div class="student">&nbsp;</div>';
			$_Qo18O['delete']='<div class="student">&nbsp;</div>';
			$_QiJ8f[]=$_Qo18O;
			$_Q8ILi=0;
			foreach ($_Q8lfO as $_QtlC0) {
				$_Q8ILi++;
				$_QLQIf=($_Q8ILi==count($_Q8lfO)) ? ' lastmark' : ' leftmark';
				if (!$_QtlC0->unanon AND $_Q88j6->dtpost>time() AND !empty($_QtlC0->submission_filename)) {
					$_Q8ftf=(isset($_POST["reason"][$_QtlC0->submission_objectid])) ? $_POST["reason"][$_QtlC0->submission_objectid] : get_string('revealreason','turnitintool');
					$_QLQi8='<b>'.get_string('student','turnitintool').':</b> <span id="studentname_'.$_QtlC0->submission_objectid.'"><i>'.get_string('anonenabled','turnitintool').'</i><br /></span><span id="anonform_'.$_QtlC0->submission_objectid.'"><form action="'.$CFG->wwwroot.'/mod/turnitintool/view.php?id='.$_Q8OLt->id.'&do=allsubmissions" method="POST" onsubmit="return anonValidate(this.reason);">&nbsp;&nbsp;&nbsp;<input id="reason" name="reason['.$_QtlC0->submission_objectid.']" value="'.$_Q8ftf.'" type="text" onclick="this.value=\'\';" /><input id="anonid" name="anonid" value="'.$_QtlC0->submission_objectid.'" type="hidden" />&nbsp;<input value="'.get_string('reveal','turnitintool').'" type="submit" /></form></span>';
					$_QLQi8.='<script language="javascript" type="text/javascript">
		toggleAnonView('.$_QtlC0->submission_objectid.',false);
	</script>';
				} else if (($_Q88j6->dtpost<=time() OR $_QtlC0->unanon) AND !$_QtlC0->nonmoodle) {
					$_QLQi8='<b>'.get_string('student','turnitintool').':</b> '.'<a href="'.$CFG->wwwroot.'/user/view.php?id='.$_QtlC0->userid.'&course='.$turnitintool->course.'">'.$_QtlC0->lastname.', '.$_QtlC0->firstname.'</a>';
				} else if (($_Q88j6->dtpost<=time() OR $_QtlC0->unanon) AND $_QtlC0->nonmoodle) {
					$_QLQi8='<b>'.get_string('student','turnitintool').':</b> <i>'.$_QtlC0->lastname.', '.$_QtlC0->firstname.' ('.get_string('nonmoodleuser','turnitintool').')</i>';
				} else {
					$_QLQi8='<b>'.get_string('student','turnitintool').':</b> <i>'.get_string('anonenabled','turnitintool').'</i>';
				}
				$_QClCl='';
				if (!empty($_QtlC0->submission_title)) {
					$_QCIj0=turnitintool_get_filelink($_Q8OLt,$turnitintool,$_QtlC0);
					$_QCJC6='';
					if (!empty($_QtlC0->submission_objectid)) {
						$_QCJC6=' onclick="screenOpen(\''.$_QCIj0.'\',\''.$_QtlC0->id.'\',\''.$turnitintool->autoupdates.'\');return false;"';
					}
					$_QCj0I=turnitintool_get_filelink($_Q8OLt,$turnitintool,$_QtlC0,$_QCQfO=true);
					$_QClCl='<b>'.get_string('file','turnitintool').':</b> <a href="'.$_QCIj0.'" target="_blank" class="tiiicons"'.$_QCJC6.'>'.$_QtlC0->submission_title.'</a><br />';
				} else {
					$_QClCl='<b>'.get_string('file','turnitintool').':</b> '.get_string('nosubmission','turnitintool').'<br />';
				}
				$_Qo18O['student']='<div id="toggle_'.$_Q88j6->id.'_'.$_Q8ILi.'_1" class="submission'.$_QLQIf.'">'.$_QClCl.$_QLQi8.'</div>';
				$_QLQff='-';
				if (empty($_QtlC0->submission_objectid) AND $turnitintool->autosubmission AND !empty($_QLQll)) {
					$_QLQff='<div class="submittoLinkSmall"><img src="'.$CFG->wwwroot.'/mod/turnitintool/icon.gif" /><a href="'.$CFG->wwwroot.'/mod/turnitintool/view.php'.'?id='.$_Q8OLt->id.'&up='.$_QtlC0->id.'">'.get_string('submittoturnitin','turnitintool').'</a></div>';
				} else if (!is_null($_QtlC0->id)) {
					$_QLQff=(empty($_QtlC0->submission_objectid)) ? '-' : date($turnitintool->dateformat.' h:i A',$_QtlC0->submission_modified);
					if ($_QtlC0->submission_modified>$_Q88j6->dtdue) {
						$_QLQff='<span style="color: red;">'.$_QLQff.'</span>';
					}
				}
				$_Qo18O['modified']='<div id="toggle_'.$_Q88j6->id.'_'.$_Q8ILi.'_2" class="submission">'.$_QLQff.'</div>';
				$_QoL66 = turnitintool_draw_similarityscore($_Q8OLt,$turnitintool,$_QtlC0);
				$_Qo18O['score']='<div id="toggle_'.$_Q88j6->id.'_'.$_Q8ILi.'_3" class="submission">'.$_QoL66.'</div>';
				$_QC8ff=turnitintool_dogradeoutput($_Q8OLt,$turnitintool,$_QtlC0);
				$_Qo18O['grade']='<div id="toggle_'.$_Q88j6->id.'_'.$_Q8ILi.'_4" class="submission"><form action="'.$CFG->wwwroot.'/mod/turnitintool/view.php'.'?id='.$_Q8OLt->id.'&do=allsubmissions" method="POST">'.$_QC8ff.'</form></div>';
				if (!$_QtlC0->nonmoodle AND !is_null($_QtlC0->id)) {
					$_QC8LQ=turnitintool_getnoteslink($_Q8OLt,$turnitintool,$_QtlC0);
				} else {
					$_QC8LQ='-';
				}
				$_Qo18O['feedback']='<div id="toggle_'.$_Q88j6->id.'_'.$_Q8ILi.'_5" class="submission">'.$_QC8LQ.'</div>';
				if (!is_null($_QtlC0->submission_objectid) AND $_Q88j6->dtpost<=time()) {
					$_QCQfO='<a href="'.turnitintool_get_filelink($_Q8OLt,$turnitintool,$_QtlC0,$_QCQfO=true).'" title="'.get_string('downloadsubmission','turnitintool').'" target="_blank"><img src="images/downloadicon.gif" alt="'.get_string('downloadsubmission','turnitintool').'" class="tiiicons" /></a>';
				} else {
					$_QCQfO='';
				}
				$_Qo18O['download']='<div id="toggle_'.$_Q88j6->id.'_'.$_Q8ILi.'_6" class="submission">'.$_QCQfO.'</div>';
				$_QoJ6l = array("\n","\r");
				$_QoJCo = array('\n','\r');
				if (empty($_QtlC0->submission_objectid)) {
					$_QCtoL=' onclick="return confirm(\''.str_replace($_QoJ6l, $_QoJCo, get_string('deleteconfirm','turnitintool')).'\');"';
				} else {
					$_QCtoL=' onclick="return confirm(\''.str_replace($_QoJ6l, $_QoJCo, get_string('turnitindeleteconfirm','turnitintool')).'\')"';
				}
				if ((empty($_QtlC0->submission_objectid) OR has_capability('mod/turnitintool:grade', get_context_instance(CONTEXT_MODULE, $_Q8OLt->id))) AND !is_null($_QtlC0->id)) {
					$delete='<a href="'.$CFG->wwwroot.'/mod/turnitintool/view.php'.'?id='.$_Q8OLt->id.'&delete='.$_QtlC0->id.'&do='.$_REQUEST["do"].'"'.$_QCtoL.' title="'.get_string('deletesubmission','turnitintool').'"><img src="images/trashicon.gif" alt="'.get_string('deletesubmission','turnitintool').'" class="tiiicons" /></a>';
				} else {
					$delete='-';
				}
				$_Qo18O['delete']='<div id="toggle_'.$_Q88j6->id.'_'.$_Q8ILi.'_7" class="submission">'.$delete.'</div>';
				$_QiJ8f[]=$_Qo18O;
			}
			$_Q8l6J++;
			if ($_Q8l6J==count($_Q8L8C)) {
				$_QL1j1='';
			} else {
				$_QL1j1=',';
			}
			$_Qiloo.='"'.$_Q88j6->id.'"'.$_QL1j1;
			$_QL088.='"'.count($_Q8lfO).'"'.$_QL1j1;
		}
		$_QOO18='
		<script language="javascript" type="text/javascript">
			function toggleAnonView(userview,onoff) {
				var anonform=document.getElementById(\'anonform_\'+userview);
				var studentname=document.getElementById(\'studentname_\'+userview);
				if (onoff==true) {
					anonform.style.display="inline";
					studentname.innerHTML="'.get_string('anonenabled','turnitintool').'";
				} else {
					anonform.style.display="none";
					studentname.innerHTML="<input value=\"'.get_string('anonenabled','turnitintool').'\" type=\"button\" onclick=\"toggleAnonView("+userview+",true)\" />";
				}
			}
			function anonValidate(reason) {
				if (!reason.value || reason.value=="'.get_string('revealreason','turnitintool').'") {
					reason.style.color="red";
					reason.style.borderColor="red";
					alert("'.get_string('revealerror','turnitintool').'");
					return false;
				} else {
					return true;
				}
			}
		</script>';
		$_QOO18.= $_Qiiol.'
		<script language="javascript" type="text/javascript">
			var users= new Array('.$_Qiloo.');
			var count= new Array('.$_QL088.');
		</script>
		<script src="turnitintool.js" language="javascript" type="text/javascript"></script>
			';
	}
	if ($_QiiCo) {
		$_QiJ8f=array(array('student'=>'<div class="student">'.get_string('nosubmissions','turnitintool').'</div>','modified'=>'<div class="student">&nbsp;</div>','score'=>'<div class="student">&nbsp;</div>','grade'=>'<div class="student">&nbsp;</div>','feedback'=>'<div class="student">&nbsp;</div>','download'=>'<div class="student">&nbsp;</div>','delete'=>'<div class="student">&nbsp;</div>'));
	}
	$_QOO18.=turnitintool_draw_submission_table($_Q8OLt, $turnitintool, $_QiJ8f);
	if ($turnitintool->numparts!=1 OR $turnitintool->anon) {
		$_QOO18 .= '
		<script language="javascript" type="text/javascript">
			assignmentcheck('.$turnitintool->id.');
			togglehideall(true);
			setuserchoice();
		</script>';
	}
	return $_QOO18;
}
function turnitintool_draw_submission_table($_Q8OLt, $turnitintool, $_QtlJi=array()) {
	global $CFG;
	$_Qo0t8->width='85%';
	$_Qo0t8->tablealign='center';
	$_Qo0t8->cellpadding='0px';
	$_Qo0t8->cellspacing='0px';
	$_Qo0t8->size=array('','12%','8%','10%','4%','4%','4%');
	$_Qo0t8->align=array('left','center','center','center','center','center','center');
	$_Qo0t8->class='gradeTable';
	if (!$turnitintool->anon) {
		$_QLI1Q=turnitintool_doheaderlinks($_Q8OLt,$turnitintool,get_string('submissionstudent','turnitintool'),'7','8');
	} else {
		$_QLI1Q=get_string('submissionstudent','turnitintool');
	}
	$_QLj0C=turnitintool_doheaderlinks($_Q8OLt,$turnitintool,get_string('posted','turnitintool'),'5','6');
	$_QLjO0=turnitintool_doheaderlinks($_Q8OLt,$turnitintool,get_string('submissionorig','turnitintool'),'1','2');
	$_QLJ80=turnitintool_doheaderlinks($_Q8OLt,$turnitintool,get_string('submissiongrade','turnitintool'),'3','4');
	$_QL6Jj=get_string('feedback','turnitintool');
	$_Qo0t8->head=array($_QLI1Q,
							$_QLj0C,
							$_QLjO0,
							$_QLJ80,
							$_QL6Jj,
							'',
							''
							);
	foreach ($_QtlJi as $_QOQfI) {
		$_QL6JC=$_QOQfI['student'];
		$_QL6Oo=$_QOQfI['modified'];
		$_QLfJI=$_QOQfI['score'];
		$_QLfOf=$_QOQfI['grade'];
		$_QL811=$_QOQfI['feedback'];
		$_QL8jt=$_QOQfI['download'];
		$_QL8iQ=$_QOQfI['delete'];
		$_Qo0t8->data[]=array($_QL6JC,$_QL6Oo,$_QLfJI,$_QLfOf,$_QL811,$_QL8jt,$_QL8iQ);
	}
	$_QOO18='<table class="toplinkTabs"><tr><td class="toggleLinks">';
	if ($turnitintool->numparts!=1 OR $turnitintool->anon) {
		$_QOO18.= '<script language="javascript" type="text/javascript">
		document.write(\'<a href="javascript:;" onclick="toggleshowall()">'.get_string('showall','turnitintool').'</a> / <a href="javascript:;" onclick="togglehideall()">'.get_string('hideall','turnitintool').'</a>\');
		</script>
		';
	}
	$_QOO18.='</td><td class="tabLinks"><ul class="tabrow0 tabRowModified">
	<li><a href="'.$CFG->wwwroot.'/mod/turnitintool/view.php'.'?id='.$_Q8OLt->id.'&do='.$_REQUEST["do"].'&update=1"><span><img src="'.$CFG->wwwroot.'/mod/turnitintool/images/refresh.gif" alt="'.get_string('turnitinrefreshsubmissions','turnitintool').'" class="tiiicons" /> '.get_string('turnitinrefreshsubmissions','turnitintool').'</span></a></li>
	<li><a href="'.$CFG->wwwroot.'/mod/turnitintool/view.php'.'?id='.$_Q8OLt->id.'&do='.$_REQUEST["do"].'&enroll=1"><span><img src="'.$CFG->wwwroot.'/mod/turnitintool/images/enrollicon.gif" alt="'.get_string('turnitinenrollstudents','turnitintool').'" class="tiiicons" /> '.get_string('turnitinenrollstudents','turnitintool').'</span></a></li>
</ul></td></tr></table>';
	$_QOO18.=turnitintool_print_table($_Qo0t8,true);
	return $_QOO18;
}
function turnitintool_getnoteslink($_Q8OLt,$_QLtfI,$_QtlC0) {
	global $CFG;
	$_QO1If=turnitintool_count_records('turnitintool_comments','submissionid',$_QtlC0->id);
	$_QC8LQ='(<a href="'.$CFG->wwwroot.'/mod/turnitintool/view.php'.'?id='.$_Q8OLt->id.'&do=notes&s='.$_QtlC0->id.'" title="'.get_string('notes','turnitintool').'">'.$_QO1If.'</a>)';
	return $_QC8LQ;
}
function turnitintool_enroll_all_students($_Q8OLt,$turnitintool) {
	$_Qtlj6=get_users_by_capability($_QttoQ, 'mod/turnitintool:submit', 'u.id', '', '', '', 0, '', false);
	if ($_QLtCo=turnitintool_search_users($turnitintool->course,'','','','')) {
		$_QflLo=0;
		$_Q8I6l=0;
		$_QLOji=array();
		$_QLOJC=array();
		foreach ($_QLtCo as $_QLOlC) {
			if (has_capability('mod/turnitintool:submit', get_context_instance(CONTEXT_MODULE, $_Q8OLt->id), $_QLOlC->id) AND !has_capability('mod/turnitintool:admin', get_context_instance(CONTEXT_MODULE, $_Q8OLt->id), $_QLOlC->id)) {
				$_QflLo++;
				$_QLOji[]=$_QLOlC;
				if (turnitintool_count_records('turnitintool_users','userid',$_QLOlC->id)<1) {
					$_QLOJC[]=$_QLOlC;
				}
			}
		}
		unset($_QLtCo);
		$_QflLo=$_QflLo+count($_QLOJC);
		foreach ($_QLOJC as $_QLo0J) {
			$_Q8I6l++;
			turnitintool_usersetup($_QLo0J,1,$_Q8I6l,$_QflLo,get_string('userprocess','turnitintool'));
		}
		$_QfloJ = new TIIToolClass;
		if (!$course = turnitintool_get_record('course','id',$turnitintool->course)) {
			turnitintool_print_error('coursegeterror','turnitintool',NULL,__FILE__,__LINE__);
			exit();
		}
		$post->cid=turnitintool_getCID($course->id); 
		$post->utp=1;
		$post->ctl=turnitintool_getCTL($course->id);
		$owner = turnitintool_get_owner($turnitintool->course);
		$post->tem=turnitintool_get_tutor_email($owner->id);
		$_QLoL6=0;
		$_QLC6L=count($_QLOji);
		foreach ($_QLOji as $_QLOlC) {
			$post->uid=turnitintool_getUID($_QLOlC); 
			$post->email=$_QLOlC->email;
			$post->firstname=$_QLOlC->firstname;
			$post->lastname=$_QLOlC->lastname;
			$_Q8I6l++;
			$_QLoL6++;
			$_QLiJL=$_QfloJ->joinClass($post,$_QLOlC,$_Q8I6l,$_QflLo,get_string('joiningclass','turnitintool','('.$_QLoL6.'/'.$_QLC6L.' '.get_string('students').')'));
			$_QOt08=$_QfloJ->getRmessage($_QLiJL);
			$_Q8Jii=$_QfloJ->getRcode($_QLiJL);
			if ($_Q8Jii>=100 AND $_Q8Jii!=1002) {
				turnitintool_print_error($_QOt08." CODE: ".$_Q8Jii,NULL,NULL,__FILE__,__LINE__);
				exit();
			}
		}
		turnitintool_update_all_report_scores($_Q8OLt,$turnitintool,true,true);
	}
}
function turnitintool_dogradeoutput($_Q8OLt,$turnitintool,$_QtlC0,$_QLiiI='#666666',$_QLL11='transparent',$_QLLfo=true) {
	global $CFG, $USER;
	$_QfloJ = new TIIToolClass;
	$owner=turnitintool_get_owner($turnitintool->course);
	if (has_capability('mod/turnitintool:grade', get_context_instance(CONTEXT_MODULE, $_Q8OLt->id))) {
		$_Qo6lJ=$owner;
		$post->utp=2;
		$post->tem=null;
	} else {
		$_Qo6lJ=$USER;
		$post->utp=1;
		$post->tem=$owner->email;
	}
	if (!$_Q88j6 = turnitintool_get_record('turnitintool_parts','id',$_QtlC0->submission_part)) {
		turnitintool_print_error('partgeterror','turnitintool',NULL,__FILE__,__LINE__);
		exit();
	}
	$_QOO18='';
	if ($CFG->turnitin_usegrademark AND $turnitintool->usegrademark AND ($post->utp==2 OR ($post->utp==1 AND $_Q88j6->dtpost<=time()))) {
		$post->uid=turnitintool_getUID($_Qo6lJ);
		$post->paperid=$_QtlC0->submission_objectid;
		$_QLLt1=$CFG->wwwroot.'/mod/turnitintool/view.php?id='.$_Q8OLt->id.'&jumppage=grade&userid='.$_Qo6lJ->id.'&post='.base64_encode(serialize($post));	
		$_QOO18='';
		$_QCJC6='';
		if (!empty($_QtlC0->submission_objectid)) {
			$_QCJC6=' onclick="screenOpen(\''.$_QLLt1.'\',\''.$_QtlC0->id.'\',\''.$turnitintool->autoupdates.'\');return false;"';
		}
		if (!empty($_QtlC0->submission_grade)) {
			$_QOO18.='<input name="grade['.$_QtlC0->id.']" type="text" readonly="readonly" size="3" class="gradebox" value="'.$_QtlC0->submission_grade.'" style="border: 0px solid white;background-color: '.$_QLL11.';color: '.$_QLiiI.';" />/'.$_Q88j6->maxmarks.' ';
		}
		if (!empty($_QtlC0->submission_objectid) AND ($post->utp==2 OR ($post->utp==1 AND $_Q88j6->dtpost<=time()))) {
			if (!$_QtlC0->submission_gmimaged) {
				$_QOO18.='<img src="images/grademarkapple_grey.gif" class="tiiicons" />';
			} else {
				$_QOO18.='<a href="'.$_QLLt1.'"'.$_QCJC6.'><img src="images/grademarkapple.gif" class="tiiicons" /></a>';
			}
		}
	} else {
		if ($post->utp==2 AND $_QLLfo) {
			$_QOO18.='
			<span id="hideshow_'.$_QtlC0->id.'"><input name="grade['.$_QtlC0->id.']" id="grade_'.$_QtlC0->id.'" type="text" size="3" class="gradebox" value="'.$_QtlC0->submission_grade.'" style="border: 1px inset;color: black;" />/'.$_Q88j6->maxmarks.'</span>';
			$_QOO18.='<input src="images/tickicon.gif" name="updategrade" value="updategrade" id="tick_'.$_QtlC0->id.'" class="tiiicons" type="image" />';
			$_QOO18.='<script language="javascript" type="text/javascript">
				viewgrade(\''.$_QtlC0->id.'\',\''.$_QLiiI.'\',\''.$_QLL11.'\');
			</script>';
		} else if ($post->utp==2 OR $_Q88j6->dtpost<=time()) {
			$_QOO18.='
			<input name="grade['.$_QtlC0->id.']" id="grade_'.$_QtlC0->id.'" type="text" size="3" class="gradebox" value="'.$_QtlC0->submission_grade.'" style="border: 0px;color: black;background-color: '.$_QLL11.'" readonly="readonly" />/'.$_Q88j6->maxmarks;
		}
	}
	if (empty($_QOO18)) {
		$_QOO18='-';
	}
	return $_QOO18;
}
function turnitintool_update_grades($_Q8OLt,$turnitintool,$post) {
	$notice='';
	$_QflLo=0;
	$_QfloJ = new TIIToolClass;
	$owner=turnitintool_get_owner($turnitintool->course);
	foreach ($post['grade'] as $id => $_QLLil) {
		if (!$_QtlC0=turnitintool_get_record('turnitintool_submissions','id',$id)) {
			turnitintool_print_error('submissiongeterror','turnitintool',NULL,__FILE__,__LINE__);
			exit();
		}
		if ($_QLLil!=$_QtlC0->submission_grade) {
			$_QflLo++;
		}
	}
	$_Q8I6l=0;
	foreach ($post['grade'] as $id => $_QLLil) {
		if (!$_QtlC0=turnitintool_get_record('turnitintool_submissions','id',$id)) {
			turnitintool_print_error('submissiongeterror','turnitintool',NULL,__FILE__,__LINE__);
			exit();
		}
		if (!$_Q88j6=turnitintool_get_record_select('turnitintool_parts',"id=".$_QtlC0->submission_part." AND deleted=0")) {
			turnitintool_print_error('partgeterror','turnitintool',NULL,__FILE__,__LINE__);
			exit();
		}
		if ($_QLLil!=$_QtlC0->submission_grade) {
			$user=turnitintool_get_moodleuser($_QtlC0->userid,NULL,__FILE__,__LINE__);
			$update = new object;
			$update->id=$id;
			$update->submission_grade=(empty($_QLLil)) ? NULL : $_QLLil;
			if ($_QLLil>$_Q88j6->maxmarks) {
				$_QtlJi->fullname=$user->firstname.' '.$user->lastname;
				$_QtlJi->part=turnitintool_partnamefromnum($_QtlC0->submission_part);
				$_QtlJi->maximum=$_Q88j6->maxmarks;
				$notice.=get_string('submissiongradetoohigh','turnitintool',$_QtlJi);
			} else {
				if (!$_Q8J1f=turnitintool_update_record('turnitintool_submissions',$update)) {
					$notice=get_string('submissionupdateerror','turnitintool');
				}
			}
			$post=new object();
			$post->uid=turnitintool_getUID($owner);
			$post->utp=2;
			$post->paperid=$_QtlC0->submission_objectid;
			$post->score=$_QLLil;
			$_Q8I6l++;
			$_QLljo->num=$_Q8I6l;
			$_QLljo->total=$_QflLo;
			$_Q8J1f=$_QfloJ->pushGrade($post,$owner,$_Q8I6l,$_QflLo,get_string('pushinggrade','turnitintool',$_QLljo),true);
			$_QOt08=$_QfloJ->getRmessage($_Q8J1f);
			$_Q8Jii=$_QfloJ->getRcode($_Q8J1f);
			if (!empty($_Q8Jii) AND $_Q8Jii>100) {
				$_Q86oL=true;
				turnitintool_print_error($_QfloJ->getRmessage($_Q8J1f).' CODE: '.$_Q8Jii,NULL,NULL,__FILE__,__LINE__);
				exit();
			} else if (empty($_Q8Jii)) {
				$_Q86oL=true;
				turnitintool_print_error('apiunavailable','turnitintool',NULL,__FILE__,__LINE__);
				exit();
			}
			@include_once($CFG->dirroot."/lib/gradelib.php");
			if (function_exists('grade_update')) {
				$_QtI1L=turnitintool_buildgrades($turnitintool,$user);
				$_Q8OLt=get_coursemodule_from_instance("turnitintool", $turnitintool->id, $turnitintool->course);
				$_Q8CiI['idnumber'] = $turnitintool->id;
				grade_update('mod/turnitintool', $turnitintool->course, 'mod', 'turnitintool', $turnitintool->id, 0, $_QtI1L, $_Q8CiI);
			}
		}
	}
	return $notice;
}
function turnitintool_update_all_report_scores($_Q8OLt,$turnitintool,$_QLliQ=false,$_QOO18=true) {
	global $USER,$CFG,$notice;
	$_QfloJ=new TIIToolClass;
	if (((isset($_SESSION["_QLllt"][$turnitintool->id]) AND $_SESSION["_QLllt"][$turnitintool->id]==1) OR isset($_REQUEST['type'])) AND !$_QLliQ) {
		return false;
	} else {
		if (!$owner = turnitintool_get_owner($turnitintool->course)) {
			turnitintool_print_error('tutorgeterror','turnitintool',NULL,__FILE__,__LINE__);
			exit();
		}
		if (!$course = turnitintool_get_record('course','id',$turnitintool->course)) {
			turnitintool_print_error('coursegeterror','turnitintool',NULL,__FILE__,__LINE__);
			exit();
		}
		if (!$_Q8L8C=turnitintool_get_records_select('turnitintool_parts',"turnitintoolid=".$turnitintool->id." AND deleted=0")) {
			turnitintool_print_error('partgeterror','turnitintool',NULL,__FILE__,__LINE__);
			exit();
		}
		if (has_capability('mod/turnitintool:grade', get_context_instance(CONTEXT_MODULE, $_Q8OLt->id)) OR $turnitintool->studentreports OR $_QLliQ) {
			$post->utp=2;
			$_Q8I6l=2;
			$_QflLo=count($_Q8L8C)+1;
			turnitintool_usersetup($owner,2,1,$_QflLo,get_string('userprocess','turnitintool'));
			$post->uid=turnitintool_getUID($owner); 
			$post->cid=turnitintool_getCID($course->id); 
			$post->tem=$owner->email; 
			$post->ctl=turnitintool_getCTL($course->id);
			foreach ($_Q8L8C as $_Q88j6) {
				$post->assignid=turnitintool_getAID($_Q88j6->id); 
				$post->assign=$turnitintool->name.' - '.turnitintool_partnamefromnum($_Q88j6->id).' (Moodle '.$post->assignid.')';
				$_QO88j->user=get_string('student','turnitintool');
				$_QO88j->proc=$_Q8I6l-1;
				$_Q8J1f=$_QfloJ->listSubmissions($post,$owner,$_Q8I6l,$_QflLo,get_string('updatingscores','turnitintool',$_QO88j),$_QOO18);
				$_Ql0t8=$_QfloJ->getSubmissionArray($_Q8J1f);
				$_QOt08=$_QfloJ->getRmessage($_Q8J1f);
				$_Q8Jii=$_QfloJ->getRcode($_Q8J1f);
				if ($_Q8Jii>=100 AND isset($_REQUEST['do']) AND $_REQUEST['do']=='allsubmissions') {
					$notice=$_QOt08;
				} else if ($_Q8Jii>=100 AND isset($_REQUEST['do']) AND $_REQUEST['do']=='submissions') {
					$notice['error']=$_QOt08;
				}
				if ($_Q8Jii>=100 OR empty($_Q8Jii)) {
					$_QLiJL=false;
				} else {
					if (!$_Qt8jo=turnitintool_get_records('turnitintool_submissions','turnitintoolid',$turnitintool->id,'','submission_objectid,id,submission_grade')) {
						$_Qt8jo=array();
					}
					turnitintool_delete_records_select('turnitintool_submissions','submission_objectid IS NOT NULL AND submission_objectid!=\'\' AND submission_part=\''.$_Q88j6->id.'\'');
					foreach ($_Ql0t8 as $_Qtt0O => $_QCO80) {
							$_Q8OQf=new object;
							$_Q8OQf->turnitintoolid=$turnitintool->id;
							$_Q8OQf->submission_part=$_Q88j6->id;
							$_Q8OQf->submission_title=$_QCO80["title"];
							$_Q8OQf->submission_type=1;
							$_Q8OQf->submission_filename=str_replace(" ","_",$_QCO80["title"]).'.doc';
							$_Q8OQf->submission_objectid=$_Qtt0O;
							$_Q8OQf->submission_score=$_QCO80["overlap"];
							if ($CFG->turnitin_usegrademark AND $turnitintool->usegrademark) {
								$_Q8OQf->submission_grade=turnitintool_processgrade($_QCO80["grademark"],$_Q88j6,$owner,$post,$_Qtt0O,$_Q8I6l,$_QflLo);
							} else {
								$_Q8OQf->submission_grade=$_Qt8jo[$_Qtt0O]->submission_grade;
							}
							$_Q8OQf->submission_status=get_string('submissionuploadsuccess','turnitintool');
							$_Q8OQf->submission_queued=0;
							$_Q8OQf->submission_attempts=0;
							$_Q8OQf->submission_gmimaged = $_QCO80["grademarkstatus"]>0 ? 1 : 0;
							$_Q8OQf->submission_modified=strtotime($_QCO80["date_submitted"]);
							$_Q8OQf->submission_parent=0;
							$_Q8OQf->submission_unanon=($_QCO80["anon"]==1) ? 0 : 1;
							if ($_QOf8o=turnitintool_get_record('turnitintool_users','turnitin_uid',$_QCO80["userid"])) {
								$_Q8OQf->submission_nmuserid=0;
								$_Q8OQf->submission_nmfirstname=NULL;
								$_Q8OQf->submission_nmlastname=NULL;
								$_Q8OQf->userid=$_QOf8o->userid;
								if ($_Qo6lJ=turnitintool_get_moodleuser($_QOf8o->userid,NULL,__FILE__,__LINE__) AND count(turnitintool_search_users($turnitintool->course,'',$_Qo6lJ->email))<1) {
									enrol_into_course($course,$_Qo6lJ,'turnitintool');
								}
							} else {
								$_Q8OQf->submission_nmuserid=($_QCO80["userid"]=="-1") ? md5($_QCO80["firstname"].$_QCO80["lastname"]) : $_QCO80["userid"];
								if (!empty($_QCO80["firstname"])) {
									$_Q8OQf->submission_nmfirstname=$_QCO80["firstname"];
								} else {
									$_Q8OQf->submission_nmfirstname='Unnamed';
								}
								if (!empty($_QCO80["lastname"])) {
									$_Q8OQf->submission_nmlastname=$_QCO80["lastname"];
								} else {
									$_Q8OQf->submission_nmlastname='User';
								}
								$_Q8OQf->userid=0;
							}
							$_Q8Qft=turnitintool_insert_record('turnitintool_submissions',$_Q8OQf);
							if (isset($_Qt8jo[$_Qtt0O])) {
								if ($_QCiOl=turnitintool_get_records('turnitintool_comments','submissionid',$_Qt8jo[$_Qtt0O]->id)) {
									foreach ($_QCiOl as $_QCLIO) {
										$update->id=$_QCLIO->id;
										$update->submissionid=$_Q8Qft;
										turnitintool_update_record('turnitintool_comments',$update);
									}
								}
							}
							$_QtlC0=$_Q8OQf;
						@include_once($CFG->dirroot."/lib/gradelib.php");
						if (function_exists('grade_update') AND $_QtlC0->userid!=0) {
							$user=turnitintool_get_moodleuser($_QtlC0->userid,NULL,__FILE__,__LINE__);
							$_Q8OLt=get_coursemodule_from_instance("turnitintool", $turnitintool->id, $turnitintool->course);
							$_QtI1L=turnitintool_buildgrades($turnitintool,$user);
							$_QtI1L->userid=$user->id;
							$_Q8CiI['idnumber'] = $turnitintool->id;
							grade_update('mod/turnitintool', $turnitintool->course, 'mod', 'turnitintool', $turnitintool->id, 0, $_QtI1L, $_Q8CiI);
						}
					}
				}
				$_Q8I6l++;
			}
			if (isset($_QLiJL)) {
				$_SESSION["_QLllt"][$turnitintool->id]='0';
				return $_QLiJL;
			} else {
				$_SESSION["_QLllt"][$turnitintool->id]='1';
				return true;
			}
		}
	}
}
function turnitintool_processgrade($_QC8ff,$_Q88j6,$owner,$post,$_Qol1C,$_Q8I6l,$_QflLo) {
	$_QC8ff=(empty($_QC8ff)) ? NULL : $_QC8ff;
	if ($_QC8ff<=$_Q88j6->maxmarks) { 
		$_QOO18=$_QC8ff;
	} else {                       
		$_QOO18=$_Q88j6->maxmarks;
		$post->oid=$_Qol1C;
		$post->score=$_QOO18;
		$_QfloJ = new TIIToolClass;
		$_QLiJL=$_QfloJ->setGradeMark($post,$owner,$_Q8I6l,$_QflLo,get_string('correctingovergrade','turnitintool'));
	}
	return $_QOO18;
}
function turnitintool_view_report($_Q8OLt,$turnitintool,$userid,$_QtlC0,$do) {
	global $USER,$CFG;
	if (has_capability('mod/turnitintool:grade', get_context_instance(CONTEXT_MODULE, $_Q8OLt->id))) {
		$owner = turnitintool_get_owner($turnitintool->course);
		$_Qo6lJ=$owner;
		$post->utp=2;
	} else {
		$_Qo6lJ=$USER;
		$post->utp=1;
	}
	turnitintool_update_all_report_scores($_Q8OLt,$turnitintool,true,true);
	$_QfloJ=new TIIToolClass;
	$post->uid=turnitintool_getUID($_Qo6lJ); 
	$post->paperid=$_QtlC0->submission_objectid;
	turnitintool_redirect($_QfloJ->getReportLink($post,$_Qo6lJ));
	exit();
}
function turnitintool_percent_to_gradpos($_Ql0Lf,$_Ql1IL='36') {
	$_Ql1iI=floor(($_Ql0Lf/100)*(-380));
	$_QollJ=' style="background: url(images/gradback.jpg) no-repeat '.$_Ql1IL.'px '.$_Ql1iI.'px";';
	return $_QollJ;
}
function turnitintool_percent_to_color($_Ql0Lf) {
	$_QC1oQ[0]=array(90,250,30);
	$_QC1oQ[5]=array(90,250,30);
	$_QC1oQ[10]=array(90,250,30);
	$_QC1oQ[15]=array(90,250,30);
	$_QC1oQ[20]=array(125,245,30);
	$_QC1oQ[25]=array(145,240,30);
	$_QC1oQ[30]=array(190,235,30);
	$_QC1oQ[35]=array(203,229,30);
	$_QC1oQ[40]=array(216,222,30);
	$_QC1oQ[45]=array(222,216,30);
	$_QC1oQ[50]=array(229,203,30);
	$_QC1oQ[55]=array(235,193,30);
	$_QC1oQ[60]=array(240,180,30);
	$_QC1oQ[65]=array(245,165,30);
	$_QC1oQ[70]=array(250,145,30);
	$_QC1oQ[75]=array(253,115,30);
	$_QC1oQ[80]=array(255,65,30);
	$_QC1oQ[85]=array(255,28,30);
	$_QC1oQ[90]=array(255,8,30);
	$_QC1oQ[95]=array(255,0,30);
	$_QC1oQ[100]=array(255,0,30);
	$_QlQOi=turnitintool_roundnearest($_Ql0Lf,5);
	$_QC1oQ=turnitintool_rgb2hex($_QC1oQ[$_QlQOi][0],$_QC1oQ[$_QlQOi][1],$_QC1oQ[$_QlQOi][2]);
	return $_QC1oQ;
}
function turnitintool_roundnearest($_QtlJi, $_QlQo1) {
	$_QLiJL = 0;
	$_QlIji = $_QtlJi % $_QlQo1;
	return ( $_QlIji > ( $_QlQo1 / 2)) ? $_QtlJi + ( $_QlQo1 - $_QlIji) : $_QtlJi - $_QlIji; 
}
function turnitintool_rgb2hex($_QljQ1, $_Qlj6L, $_Qlj81) {
	return sprintf('#%02X%02X%02X', $_QljQ1, $_Qlj6L, $_Qlj81);
}
function turnitintool_delete_submission($_Q8OLt,$turnitintool,$userid,$_QtlC0) {
	global $USER,$CFG;
	if (empty($_QtlC0->submission_objectid)
			OR
	     has_capability('mod/turnitintool:grade', get_context_instance(CONTEXT_MODULE, $_Q8OLt->id))
		 	OR
		 $turnitintool->reportgenspeed==1
		 ) {
		if ($userid!=$_QtlC0->userid AND !has_capability('mod/turnitintool:grade', get_context_instance(CONTEXT_MODULE, $_Q8OLt->id))) {
			turnitintool_print_error('permissiondeniederror','turnitintool',NULL,__FILE__,__LINE__);
			exit();
		}
		if (!turnitintool_delete_records('turnitintool_submissions','id',$_QtlC0->id)) {
			turnitintool_print_error('submissiondeleteerror','turnitintool',NULL,__FILE__,__LINE__);
		}
		if (has_capability('mod/turnitintool:grade', get_context_instance(CONTEXT_MODULE, $_Q8OLt->id))
			OR
			$turnitintool->reportgenspeed==1) {
			if (!empty($_QtlC0->submission_objectid)) {
				$owner=turnitintool_get_owner($turnitintool->course);
				$_QfloJ = new TIIToolClass;
				turnitintool_usersetup($owner,2,1,2,get_string('userprocess','turnitintool'));
				$post->uid=turnitintool_getUID($owner); 
				$post->paperid=$_QtlC0->submission_objectid;
				$post->utp=2;
				$_Q8J1f=$_QfloJ->deleteSubmission($post,$owner,2,2,get_string('deletingsubmission','turnitintool'));
				$_QOt08=$_QfloJ->getRmessage($_Q8J1f);
				$_Q8Jii=$_QfloJ->getRcode($_Q8J1f);
				if (empty($_Q8Jii)) {
					$_QOt08.=get_string('turnitindeletionerror','turnitintool');
					turnitintool_print_error($_QOt08,NULL,NULL,__FILE__,__LINE__);
				}
				if ($_Q8Jii>=100) {
					$_QOt08.="<br />".get_string('turnitindeletionerror','turnitintool');
					turnitintool_print_error($_QOt08,NULL,NULL,__FILE__,__LINE__);
				}
			}
			turnitintool_redirect($CFG->wwwroot.'/mod/turnitintool/view.php?id='.$_Q8OLt->id.'&user='.$userid.'&do='.$_REQUEST["do"]);
			exit();
		} else {
			turnitintool_redirect($CFG->wwwroot.'/mod/turnitintool/view.php?id='.$_Q8OLt->id.'&do='.$_REQUEST["do"]);
			exit();
		}
		exit();
	}
}
function turnitintool_update_choice_cookie($turnitintool) {
	global $CFG;
	$_Qlj8J = array();
	$_QlJf1='';
	$_QlJOQ='';
	if (isset($_COOKIE["turnitintool_choice_user"])) {
		$_Qlf0i=$_COOKIE["turnitintool_choice_user"];
		$_Qlj8J=explode("_",$_Qlf0i);
	}
	if (isset($_COOKIE["turnitintool_choice_count"])) {
		$_Ql8IC=$_COOKIE["turnitintool_choice_count"];
		$_Ql881=explode("_",$_Ql8IC);
	}
	for ($_Q8ILi=0;$_Q8ILi<count($_Qlj8J);$_Q8ILi++) {
		if (substr_count($_Qlj8J[$_Q8ILi],'nm-')>0 AND !$turnitintool->anon) {
			$_Ql8Cf=str_replace('nm-','',$_Qlj8J[$_Q8ILi]);
			$_QtCOi = turnitintool_count_records('turnitintool_submissions','submission_nmuserid',$_Ql8Cf,'turnitintoolid',$turnitintool->id);
		} else if (!$turnitintool->anon) {
			$_QtCOi = turnitintool_count_records('turnitintool_submissions','userid',$_Qlj8J[$_Q8ILi],'turnitintoolid',$turnitintool->id);
		} else {
			$_Qlt0i = turnitintool_count_records('turnitintool_submissions','submission_part',$_Qlj8J[$_Q8ILi],'turnitintoolid',$turnitintool->id,'userid',0);
			$_Q8OLt=get_coursemodule_from_instance('turnitintool',$turnitintool->id,$turnitintool->course);
			$_QttoQ = get_context_instance(CONTEXT_MODULE, $_Q8OLt->id);
			$_Qlt10=count(get_users_by_capability($_QttoQ, 'mod/turnitintool:submit', 'u.id', '', '', '', 0, '', false));
			$_QtCOi=$_Qlt0i+$_Qlt10;
		}
		if ($_QtCOi!=0) {
			$_QlJf1.=$_Qlj8J[$_Q8ILi];
			$_QlJOQ.=$_QtCOi;
		}
		if ($_Q8ILi!=count($_Qlj8J)-1) {
			$_QlJf1.='_';
			$_QlJOQ.='_';
		}
	}
	setcookie("turnitintool_choice_user",$_QlJf1,0,"/");
	setcookie("turnitintool_choice_count",$_QlJOQ,0,"/");
}
function turnitintool_get_tutor_email($userid) {
	$user=turnitintool_get_moodleuser($userid,NULL,__FILE__,__LINE__);
	if (empty($user->email)) {
		$_QltfL=explode('.',$user->username);
		array_pop($_QltfL);
		$_Qltl0=join('.',$_QltfL);
	} else {
		$_Qltl0=$user->email;
	}
	return $_Qltl0;
}
function turnitintool_view_submission_form($_Q8OLt,$turnitintool,$_QlOJI=NULL) {
	global $CFG,$USER,$COURSE;
	if ($turnitintool->allowlate==1) {
		$_Qlo18=turnitintool_get_records_select('turnitintool_parts', "turnitintoolid=".$turnitintool->id." AND deleted=0 AND dtstart < ".time()."");
	} else {
		$_Qlo18=turnitintool_get_records_select('turnitintool_parts', "turnitintoolid=".$turnitintool->id." AND deleted=0 AND dtstart < ".time()." AND dtdue > ".time()."");
	}
	$_QloL0=count($_Qlo18);
	$_QlCiQ=turnitintool_count_records_select('turnitintool_submissions','userid='.$USER->id.' AND turnitintoolid='.$turnitintool->id);
	$_QlCiO=turnitintool_count_records_select('turnitintool_submissions','turnitintoolid='.$turnitintool->id);
	$_QttoQ = get_context_instance(CONTEXT_MODULE, $_Q8OLt->id);
	$_Qli16=count(get_users_by_capability($_QttoQ, 'mod/turnitintool:submit', 'u.id', '', '', '', 0, '', false));
	$_QliOl=false;
	if (has_capability('mod/turnitintool:grade', get_context_instance(CONTEXT_MODULE, $_Q8OLt->id))) {
		$_QlL80=true;
		foreach ($_Qlo18 as $_Qll6t) {
			$_Qllo6=turnitintool_count_records_select('turnitintool_submissions','turnitintoolid='.$turnitintool->id.' AND submission_part='.$_Qll6t->id);
			if ($_Qllo6<$turnitintool->numparts*$_Qli16) {
				$_QliOl=true;
			}
		}
	} else {
		$_QlL80=false;
		foreach ($_Qlo18 as $_Qll6t) {
			if (!turnitintool_get_records_select('turnitintool_submissions','turnitintoolid='.$turnitintool->id.' AND submission_part='.$_Qll6t->id.' AND userid='.$USER->id)) {
				$_QliOl=true;
			}
		}
	}
	if ($_QliOl AND $_Qli16>0) {
		$_QOO18=turnitintool_box_start('generalbox boxwidthwide boxaligncenter eightyfive', 'submitbox',true);
		$type=0;
		if (isset($_REQUEST['type'])) {
			$type=$_REQUEST['type'];
		}
		$_Q8lfO=turnitintool_get_records_select('turnitintool_submissions','userid='.$USER->id.' AND turnitintoolid='.$turnitintool->id);
		$_Qo0t8->width='100%';
		$_Qo0t8->tablealign='center';
		$_Qo0t8->cellpadding='8px';
		$_Qo0t8->cellspacing='0px';
		$_Qo0t8->size=array('25%','75%');
		$_Qo0t8->align=array('right','left');
		$_Qo0t8->wrap=array('nowrap',NULL);
		$_Qo0t8->class='uploadtable';
		unset($_Qo18O);
		$_Qo18O=array();
		$_Qo18O[0]=get_string('submissiontype', 'turnitintool').turnitintool_help_icon('submissiontype',get_string('submissiontype','turnitintool'),'turnitintool',true,false,'',true);
		if ($turnitintool->type==0) {
			if ($type==1) {
				$_QOifJ=array('',' selected','','');
			} else if ($type==2) {
				$_QOifJ=array('','',' selected','');
			} else if ($type==3) {
				$_QOifJ=array('','','',' selected');
			} else {
				$_QOifJ=array(' selected','','','');
				$type=0;
			}
			$_Qo18O[1]='<select onchange="turnitintool_jumptopage(this.value)">';
			$_Qo18O[1].='<option label="Select Submission Type" value="'.$CFG->wwwroot.'/mod/turnitintool/view.php'.'?id='.$_Q8OLt->id.'&do=submissions"'.$_QOifJ[0].'>Select Submission Type</option>
			';
			$_Qo18O[1].='<option label="-----------------" value="#">-----------------</option>';
			$_I006L=turnitintool_filetype_array(false);
			foreach ($_I006L as $_I00ii => $_I01jo) {
				$_Qo18O[1].='
				<option label="'.$_I01jo.'" value="'.$CFG->wwwroot.'/mod/turnitintool/view.php'.'?id='.$_Q8OLt->id.'&do=submissions&type='.$_I00ii.'"'.$_QOifJ[$_I00ii].'>'.$_I01jo.'</option>';
			}
			$_Qo18O[1].='
			</select>';
		} else if ($turnitintool->type==1) {
			$type=1;
			$_Qo18O[1]=get_string('fileupload','turnitintool');
		} else if ($turnitintool->type==2) {
			$type=2;
			$_Qo18O[1]=get_string('textsubmission','turnitintool');
		} else {
			$type=3;
			$_Qo18O[1]=get_string('webpage','turnitintool');
		}
		$_QOO18.='<b>'.get_string('submit','turnitintool').'</b><br />
	<form enctype="multipart/form-data" action="'.$CFG->wwwroot.'/mod/turnitintool/view.php'.'?id='.$_Q8OLt->id.'&do=submissions&type='.$type.'" method="POST">';
		$_Qo0t8->data[]=$_Qo18O;
		if (isset($type) AND $type!=0) {
			$_I01ii='';
			if (isset($_REQUEST['submissiontitle'])) {
				$_I01ii=$_REQUEST['submissiontitle'];
			}
			$_I0QJl=false;
			if ($_QlL80) {
				unset($_Qo18O);
				$_Qo18O=array();
				$_Qo18O[0]=get_string('studentsname', 'turnitintool').turnitintool_help_icon('studentsname',get_string('studentsname','turnitintool'),'turnitintool',true,false,'',true);
				$_QttoQ = get_context_instance(CONTEXT_MODULE, $_Q8OLt->id);
				$_QLtCo=get_users_by_capability($_QttoQ, 'mod/turnitintool:submit', '', '', '', '', 0, '', false);
				if (count($_QLtCo)>0) {
					$_Qo18O[1]='<select name="userid">';
					foreach ($_QLtCo as $_QLOlC) {
						if (has_capability('mod/turnitintool:submit',get_context_instance(CONTEXT_MODULE, $_Q8OLt->id), $_QLOlC->id, false)) {
							$_I0I1Q=turnitintool_count_records_select('turnitintool_submissions','userid='.$_QLOlC->id.' AND turnitintoolid='.$turnitintool->id);
							if ($_I0I1Q<$turnitintool->numparts) {
								if (isset($_REQUEST["userid"]) AND $_REQUEST["userid"]==$_QLOlC->id) {
									$_QOifJ=' selected';
								} else {
									$_QOifJ='';
								}
								$_Qo18O[1].='<option label="'.$_QLOlC->firstname.' '.$_QLOlC->lastname.'" value="'.$_QLOlC->id.'"'.$_QOifJ.'>'.$_QLOlC->lastname.', '.$_QLOlC->firstname.'</option>';
							}
						}
					}
					$_Qo18O[1].='</select>';
					if ($_Qo18O[1]=='<select name="userid">'.'</select>') {
						$_Qo18O[1]='<i>'.get_string('allsubmissionsmade','turnitintool').'</i>';
						$_I0QJl=true;
					}
				} else {
					$_Qo18O[1]='<i>'.get_string('noenrolledstudents','turnitintool').'</i>';
				}
				$_Qo0t8->data[]=$_Qo18O;
			}
			if (!$_I0QJl) {
				unset($_Qo18O);
				$_Qo18O=array();
				$_Qo18O[0]=get_string('submissiontitle', 'turnitintool').turnitintool_help_icon('submissiontitle',get_string('submissiontitle','turnitintool'),'turnitintool',true,false,'',true);
				$_Qo18O[1]='<input type="hidden" name="submissiontype" value="'.$type.'" />';
				$_Qo18O[1].='<input type="text" name="submissiontitle" class="formwide" maxlength="200" value="'.$_I01ii.'" />';
				$_Qo0t8->data[]=$_Qo18O;
				if ($turnitintool->allowlate==1) {
					$_Q8L8C=turnitintool_get_records_select('turnitintool_parts',"turnitintoolid='".$turnitintool->id."' AND deleted=0 AND dtstart < '".time()."'",'dtstart,dtdue,dtpost,id');
				} else {
					$_Q8L8C=turnitintool_get_records_select('turnitintool_parts',"turnitintoolid='".$turnitintool->id."' AND deleted=0 AND dtstart < '".time()."' AND dtdue > '".time()."'",'dtstart,dtdue,dtpost,id');
				}
				$_QtoCQ=get_object_vars($_Q8L8C);
				$_I0IjI=array();
				if (is_array($_Q8lfO)) {
					foreach ($_Q8lfO as $_QtlC0) {
						$_I0IjI[]=$_QtlC0->submission_part;
					}
				}
				if (count($_Q8L8C)>1) {
					unset($_Qo18O);
					$_Qo18O=array();
					$_Qo18O[0]=get_string('submissionpart', 'turnitintool').turnitintool_help_icon('submissionpart',get_string('submissionpart','turnitintool'),'turnitintool',true,false,'',true);
					$_Qo18O[1]='<select name="submissionpart" class="formwide">';
					$_Q8ILi=0;
					foreach ($_Q8L8C as $_Q88j6) { 
						if (!in_array($_Q88j6->id,$_I0IjI) OR $_QlL80) {
							$_Qo18O[1].='<option label="'.$_Q88j6->partname.'" value="'.$_Q88j6->id.'">'.$_Q88j6->partname.'</option>';
						}
						$_Q8ILi++;
					}
					$_Qo18O[1].='</select>';
					$_Qo0t8->data[]=$_Qo18O;
				} else {
					unset($_Qo18O);
					$_Qo18O=array();
					$_Qo18O[0]=get_string('submissionpart', 'turnitintool').turnitintool_help_icon('submissionpart',get_string('submissionpart','turnitintool'),'turnitintool',true,false,'',true);
					foreach ($_Q8L8C as $_Q88j6) { 
						if (!in_array($_Q88j6->id,$_I0IjI) OR $_QlL80) {
							$_Qo18O[1]=$_Q88j6->partname.'<input type="hidden" name="submissionpart" value="'.$_Q88j6->id.'" />';
							break;
						}
					}
					$_Qo0t8->data[]=$_Qo18O;
				}
				if ($type==1) {
					unset($_Qo18O);
					$_Qo18O=array();
					$_Qo18O[0]=get_string('filetosubmit', 'turnitintool').turnitintool_help_icon('filetosubmit',get_string('filetosubmit','turnitintool'),'turnitintool',true,false,'',true);
					$_Qo18O[1]='<input type="hidden" name="MAX_FILE_SIZE" value="'.$turnitintool->maxfilesize.'" />';
					$_Qo18O[1].='<input type="file" name="submissionfile" size="55%" />';
					$_Qo0t8->data[]=$_Qo18O;
				}
				if ($type==2) {
					unset($_Qo18O);
					$_I0Iii='';
					if (isset($_REQUEST['submissiontext'])) {
						$_I0Iii=$_REQUEST['submissiontext'];
					}
					$_Qo18O=array();
					$_Qo18O[0]=get_string('texttosubmit', 'turnitintool').turnitintool_help_icon('texttosubmit',get_string('texttosubmit','turnitintool'),'turnitintool',true,false,'',true);
					$_Qo18O[1]='<textarea name="submissiontext" class="submissionText">'.$_I0Iii.'</textarea>';
					$_Qo0t8->data[]=$_Qo18O;
				}
				if ($type==3) {
					unset($_Qo18O);
					$_I0IlI='';
					if (isset($_REQUEST['submissionurl'])) {
						$_I0IlI=$_REQUEST['submissionurl'];
					}
					$_Qo18O=array();
					$_Qo18O[0]=get_string('urltosubmit', 'turnitintool').turnitintool_help_icon('urltosubmit',get_string('urltosubmit','turnitintool'),'turnitintool',true,false,'',true);
					$_Qo18O[1]='<input type="text" name="submissionurl" class="formwide" value="'.$_I0IlI.'" />';
					$_Qo0t8->data[]=$_Qo18O;
				}
				$_I0jCC='';
				if (isset($_REQUEST['agreement'])) {
					$_I0jCC=' checked';
				}
				if (!$_QlL80) {
					unset($_Qo18O);
					$_Qo18O=array();
					$_Qo18O[0]='<input type="checkbox" name="agreement" value="1"'.$_I0jCC.' />';
					$_Qo18O[1]=$CFG->turnitin_agreement;
					$_Qo0t8->data[]=$_Qo18O;
				} else {
					unset($_Qo18O);
					$_Qo18O=array();
					$_Qo18O[0]='';
					$_Qo18O[1]='<input type="hidden" name="agreement" value="1" />';
					$_Qo0t8->data[]=$_Qo18O;
				}
				unset($_Qo18O);
				$_Qo18O=array();
				$_Qo18O[0]='&nbsp;';
				$_Qo18O[1]='<input type="submit" value="'.get_string('addsubmission', 'turnitintool').'" />';
				$_Qo0t8->data[]=$_Qo18O;
			}
		}
		$_QOO18.=turnitintool_print_table($_Qo0t8,true);
		$_QOO18.='
		</form>';
		$_QOO18.=turnitintool_box_end(true).'<br />';
	} else if (turnitintool_count_records_select('turnitintool_parts', "turnitintoolid='".$turnitintool->id."' AND dtstart < '".time()."' AND dtdue > '".time()."'")==0) {
		$_QOO18=turnitintool_box_start('generalbox boxwidthwide boxaligncenter eightyfive', 'submitbox',true);
		$_QOO18.=get_string('nosubmissionsdue','turnitintool');
		$_QOO18.=turnitintool_box_end(true).'<br />';
	} else {
		$_QOO18=turnitintool_box_start('generalbox boxwidthwide boxaligncenter eightyfive', 'submitbox',true);
		$_QttoQ = get_context_instance(CONTEXT_MODULE, $_Q8OLt->id);
		$_Qlt10=count(get_users_by_capability($_QttoQ, 'mod/turnitintool:submit', 'u.id', '', '', '', 0, '', false));
		if ($_Qlt10>0) {
			$_QOO18.=get_string('submittedmax','turnitintool');
		} else {
			$_QOO18.=get_string('noenrolledstudents','turnitintool');
		}
		$_QOO18.=turnitintool_box_end(true).'<br />';
	}
	return $_QOO18;
}
function turnitintool_partnamefromnum($_QOJlC) {
	if ($_Q88j6=turnitintool_get_record('turnitintool_parts','id',$_QOJlC)) {
		return $_Q88j6->partname;
	} else {
		return false;
	}
}
function turnitintool_duplicate_submission_title($turnitintool,$_QClCl,$userid) {
	if (!$_Q8J1f=turnitintool_get_record('turnitintool_submissions','turnitintoolid',$turnitintool->id,'submission_title',$_QClCl,'userid',$userid)) {
		$_QLiJL=false;
	} else {
		$_QLiJL=true;
	}
	return $_QLiJL;
}
function turnitintool_checkforsubmission($turnitintool,$_Q8OLt,$_QOJlC,$userid) {
	global $USER,$CFG;
	turnitintool_update_all_report_scores($_Q8OLt,$turnitintool,true,true);
	$_I0JCf=turnitintool_count_records('turnitintool_submissions','submission_part',$_QOJlC,'userid',$userid);
	if ($_I0JCf>0) {
		return true;
	} else {
		return false;
	}
}
function turnitintool_dofileupload($turnitintool,$_Q8OLt,$userid,$_I06jQ) {
	global $USER,$CFG;
	$_Q86oL=false;
	$notice=array("error"=>'',"subid"=>'');
	$_I06oJ = new upload_manager;
	if (turnitintool_checkforsubmission($turnitintool,$_Q8OLt,$_I06jQ['submissionpart'],$userid)) {
		$notice["error"].=get_string('alreadysubmitted','turnitintool').'<br />';
		$_Q86oL=true;
	}
	$_I01ii='';
	if (isset($_I06jQ['submissiontitle'])) {
		$_I01ii=$_I06jQ['submissiontitle'];
	}
	if (empty($_FILES['submissionfile']['name'])) {
		$notice["error"].=get_string('submissionfileerror','turnitintool').'<br />';
		$_Q86oL=true;
	}
	$_I08jC=array('doc','docx','rtf','txt','pdf','htm','html');
	if (!in_array(array_pop(explode('.',$_FILES['submissionfile']['name'])),$_I08jC)) {
		$notice["error"].=get_string('submissionfiletypeerror','turnitintool',join(', ',$_I08jC)).'<br />';
		$_Q86oL=true;
	}
	if (empty($_I01ii)) {
		$notice["error"].=get_string('submissiontitleerror','turnitintool').'<br />';
		$_Q86oL=true;
	}
	if (turnitintool_duplicate_submission_title($turnitintool,$_I01ii,$userid)) {
		$notice["error"].=get_string('submissiontitleduplicate','turnitintool').'<br />';
		$_Q86oL=true;
	}
	if (!isset($_I06jQ['agreement'])) {
		$notice["error"].=get_string('submissionagreementerror','turnitintool').'<br />';
		$_Q86oL=true;
	}
	$_FILES['submissionfile']['name']=str_replace(' ','_',$_FILES['submissionfile']['name']);
	$_FILES['submissionfile']['name']=str_replace('(','_',$_FILES['submissionfile']['name']);
	$_FILES['submissionfile']['name']=str_replace(')','_',$_FILES['submissionfile']['name']);
	$_FILES['submissionfile']['name']=$_I06jQ['submissionpart'].'_'.$_FILES['submissionfile']['name'];
	if (!$_I06oJ->preprocess_files()) {
		$notice["error"].=$_I06oJ->notify;
		$_Q86oL=true;
	}
	if (substr_count(turnitintool_file_path($_Q8OLt,$turnitintool,$userid),'/')>0) {
		$_I08L0=turnitintool_file_path($_Q8OLt,$turnitintool,$userid);
	} else {
		$_I08L0=str_replace('/','\\',turnitintool_file_path($_Q8OLt,$turnitintool,$userid));
	}
	if (!$_I06oJ->save_files($_I08L0)) {
		turnitintool_print_error('fileuploaderror','turnitintool',NULL,__FILE__,__LINE__);
		exit();
	}
	if (!$_Q86oL) {
		$_I0t1t = new object();
		$_I0t1t->userid=$userid;
		$_I0t1t->turnitintoolid=$turnitintool->id;
		$_I0t1t->submission_title=$_I01ii;
		$_I0t1t->submission_part=$_I06jQ['submissionpart'];
		$_I0t1t->submission_type=$_I06jQ['submissiontype'];
		$_I0t1t->submission_filename=$_FILES['submissionfile']['name'];
		$_I0t1t->submission_queued=NULL;
		$_I0t1t->submission_attempts=0;
		$_I0t1t->submission_gmimaged=0;
		$_I0t1t->submission_objectid=NULL;
		$_I0t1t->submission_score=NULL;
		$_I0t1t->submission_grade=NULL;
		$_I0t1t->submission_status=NULL;
		$_I0t1t->submission_modified=time();
		if (!$_Q8Qft=turnitintool_insert_record('turnitintool_submissions',$_I0t1t)) {
			turnitintool_print_error('submissioninserterror','turnitintool',NULL,__FILE__,__LINE__);
			exit();
		}
		if (has_capability('mod/turnitintool:grade', get_context_instance(CONTEXT_MODULE, $_Q8OLt->id)) AND !$turnitintool->autosubmission) {
			turnitintool_redirect($CFG->wwwroot.'/mod/turnitintool/view.php?id='.$_Q8OLt->id.'&do=allsubmissions');
			exit();
		} else if (!$turnitintool->autosubmission) {
			turnitintool_redirect($CFG->wwwroot.'/mod/turnitintool/view.php?id='.$_Q8OLt->id.'&do='.$_REQUEST['do']);
			exit();
		}
		$notice["subid"]=$_Q8Qft;
	}
	return $notice;
}
function turnitintool_dotextsubmission($turnitintool,$_Q8OLt,$userid,$_I06jQ) {
	global $USER,$CFG;
	$_Q86oL=false;
	$notice=array("error"=>'',"subid"=>'');
	if (turnitintool_checkforsubmission($turnitintool,$_Q8OLt,$_I06jQ['submissionpart'],$userid)) {
		$notice["error"].=get_string('alreadysubmitted','turnitintool').'<br />';
		$_Q86oL=true;
	}
	$_I01ii='';
	if (isset($_I06jQ['submissiontitle'])) {
		$_I01ii=$_I06jQ['submissiontitle'];
	}
	if (empty($_I01ii)) {
		$notice["error"].=get_string('submissiontitleerror','turnitintool').'<br />';
		$_Q86oL=true;
	}
	if (turnitintool_duplicate_submission_title($turnitintool,$_I01ii,$userid)) {
		$notice["error"].=get_string('submissiontitleduplicate','turnitintool').'<br />';
		$_Q86oL=true;
	}
	if (empty($_I06jQ['submissiontext'])) {
		$notice["error"].=get_string('submissiontexterror','turnitintool').'<br />';
		$_Q86oL=true;
	}
	if (!isset($_I06jQ['agreement'])) {
		$notice["error"].=get_string('submissionagreementerror','turnitintool').'<br />';
		$_Q86oL=true;
	}
	$_I0tlt=stripslashes($_I06jQ['submissiontext']);
	if (substr_count(turnitintool_file_path($_Q8OLt,$turnitintool,$userid),'/')>0) {
		$_I08L0=turnitintool_file_path($_Q8OLt,$turnitintool,$userid);
	} else {
		$_I08L0=str_replace('/','\\',turnitintool_file_path($_Q8OLt,$turnitintool,$userid));
	}
	$_I0OJ0=$CFG->dataroot.'/'.$_I08L0;
	if (!file_exists($_I0OJ0)) {
		mkdir($_I0OJ0,0777,true);
	}
	$_I0Olt=fopen($_I0OJ0.'/'.str_replace(' ','_',$_I01ii).'.txt','w+');
	if (!fwrite($_I0Olt,$_I0tlt)) {
		turnitintool_print_error('filewriteerror','turnitintool',NULL,__FILE__,__LINE__);
		exit();
	}
	if (!$_Q86oL) {
		$_I0t1t = new object();
		$_I0t1t->userid=$userid;
		$_I0t1t->turnitintoolid=$turnitintool->id;
		$_I0t1t->submission_title=$_I01ii;
		$_I0t1t->submission_part=$_I06jQ['submissionpart'];
		$_I0t1t->submission_type=$_I06jQ['submissiontype'];
		$_I0t1t->submission_filename=str_replace(' ','_',$_I01ii).'.txt';
		$_I0t1t->submission_queued=NULL;
		$_I0t1t->submission_attempts=0;
		$_I0t1t->submission_gmimaged=0;
		$_I0t1t->submission_objectid=NULL;
		$_I0t1t->submission_score=NULL;
		$_I0t1t->submission_grade=NULL;
		$_I0t1t->submission_status=NULL;
		$_I0t1t->submission_modified=time();
		if (!$_Q8Qft = turnitintool_insert_record('turnitintool_submissions',$_I0t1t)) {
			turnitintool_print_error('submissioninserterror','turnitintool',NULL,__FILE__,__LINE__);
			exit();
		}
		$notice["subid"]=$_Q8Qft;
		if (has_capability('mod/turnitintool:grade', get_context_instance(CONTEXT_MODULE, $_Q8OLt->id)) AND !$turnitintool->autosubmission) {
			turnitintool_redirect($CFG->wwwroot.'/mod/turnitintool/view.php?id='.$_Q8OLt->id.'&do=allsubmissions');
			exit();
		} else if (!$turnitintool->autosubmission) {
			turnitintool_redirect($CFG->wwwroot.'/mod/turnitintool/view.php?id='.$_Q8OLt->id.'&do='.$_REQUEST['do']);
			exit();
		}
	}
	return $notice;
}
function turnitintool_dourlsubmission($turnitintool,$_Q8OLt,$userid,$_I06jQ) {
	global $USER,$CFG;
	$_Q86oL=false;
	$notice=array("error"=>'',"subid"=>'');
	if (turnitintool_checkforsubmission($turnitintool,$_Q8OLt,$_I06jQ['submissionpart'],$userid)) {
		$notice["error"].=get_string('alreadysubmitted','turnitintool').'<br />';
		$_Q86oL=true;
	}
	$_I01ii='';
	if (isset($_I06jQ['submissiontitle'])) {
		$_I01ii=$_I06jQ['submissiontitle'];
	}
	if (empty($_I01ii)) {
		$notice["error"].=get_string('submissiontitleerror','turnitintool').'<br />';
		$_Q86oL=true;
	}
	if (turnitintool_duplicate_submission_title($turnitintool,$_I01ii,$userid)) {
		$notice["error"].=get_string('submissiontitleduplicate','turnitintool').'<br />';
		$_Q86oL=true;
	}
	if (empty($_I06jQ['submissionurl'])) {
		$notice["error"].=get_string('submissionurlerror','turnitintool').'<br />';
		$_Q86oL=true;
	} else if (substr_count($_I06jQ['submissionurl'],'http')<1) {
		$notice["error"].=get_string('submissionprotocolerror','turnitintool').'<br />';
		$_Q86oL=true;
	}
	if (!isset($_I06jQ['agreement'])) {
		$notice["error"].=get_string('submissionagreementerror','turnitintool').'<br />';
		$_Q86oL=true;
	}
	$_I0IlI='';
	if (isset($_I06jQ['submissionurl'])) {
		$_I0IlI=$_I06jQ['submissionurl'];
	}
	$_QfloJ = new TIIToolClass;
	$_I0oCt=$_QfloJ->framesCheck($_I0IlI);
	if (!is_null($_I0oCt)) {
		if ($_I0oCt=="FRAMESET") {
			$notice["error"].=get_string('submissionframeseterror','turnitintool').'<br />';
		}
		if ($_I0oCt=="IFRAME") {
			$notice["error"].=get_string('submissioniframeerror','turnitintool').'<br />';
		}
		$_Q86oL=true;
	}
	if (!$_Q86oL) {
		$_I0t1t = new object();
		$_I0t1t->userid=$userid;
		$_I0t1t->turnitintoolid=$turnitintool->id;
		$_I0t1t->submission_title=$_I01ii;
		$_I0t1t->submission_part=$_I06jQ['submissionpart'];
		$_I0t1t->submission_type=$_I06jQ['submissiontype'];
		$_I0t1t->submission_filename=str_replace(' ','_',$_I01ii).'.htm';
		$_I0t1t->submission_queued=NULL;
		$_I0t1t->submission_attempts=0;
		$_I0t1t->submission_gmimaged=0;
		$_I0t1t->submission_objectid=NULL;
		$_I0t1t->submission_score=NULL;
		$_I0t1t->submission_grade=NULL;
		$_I0t1t->submission_status=NULL;
		$_I0t1t->submission_modified=time();
		if (!$_Q8Qft = turnitintool_insert_record('turnitintool_submissions',$_I0t1t)) {
			turnitintool_print_error('submissioninserterror','turnitintool',NULL,__FILE__,__LINE__);
			exit();
		}
		$_I0tlt=$_QfloJ->grabHTML($_I0IlI);
		if (substr_count(turnitintool_file_path($_Q8OLt,$turnitintool,$userid),'/')>0) {
			$_I08L0=turnitintool_file_path($_Q8OLt,$turnitintool,$userid);
		} else {
			$_I08L0=str_replace('/','\\',turnitintool_file_path($_Q8OLt,$turnitintool,$userid));
		}
		$notice["subid"]=$_Q8Qft;
		$_I0OJ0=$CFG->dataroot.'/'.$_I08L0;
		if (!file_exists($_I0OJ0)) {
			mkdir($_I0OJ0,0777,true);
		}
		$_I0Olt=fopen($_I0OJ0.'/'.$_I0t1t->submission_filename,'w+');
		if (!fwrite($_I0Olt,$_I0tlt)) {
			turnitintool_print_error('filewriteerror','turnitintool',NULL,__FILE__,__LINE__);
			exit();
		}
		if (has_capability('mod/turnitintool:grade', get_context_instance(CONTEXT_MODULE, $_Q8OLt->id)) AND !$turnitintool->autosubmission) {
			turnitintool_redirect($CFG->wwwroot.'/mod/turnitintool/view.php?id='.$_Q8OLt->id.'&do=allsubmissions');
			exit();
		} else if (!$turnitintool->autosubmission) {
			turnitintool_redirect($CFG->wwwroot.'/mod/turnitintool/view.php?id='.$_Q8OLt->id.'&do='.$_REQUEST['do']);
			exit();
		}
	}
	return $notice;
}
function turnitintool_upload_submission($_Q8OLt,$turnitintool,$_QtlC0) {
	global $CFG;
	 if (!$course = turnitintool_get_record('course','id',$turnitintool->course)) {
		turnitintool_print_error('coursegeterror','turnitintool',NULL,__FILE__,__LINE__);
		exit();
	 }
	 if (!$_Q88j6 = turnitintool_get_record('turnitintool_parts','id',$_QtlC0->submission_part)) {
	 	turnitintool_print_error('partgeterror','turnitintool',NULL,__FILE__,__LINE__);
		exit();
	 }
	 $user=turnitintool_get_moodleuser($_QtlC0->userid,NULL,__FILE__,__LINE__);
	 $_QO8QO=1;
	 $_Q80iI=turnitintool_usersetup($user,$_QO8QO,1,3,get_string('userprocess','turnitintool'));
	 $_Q81OO=$_Q80iI->turnitin_uid;
	 $post->uid=turnitintool_getUID($user); 
	 $post->cid=turnitintool_getCID($course->id); 
	 $post->assignid=turnitintool_getAID($_Q88j6->id); 
	 $post->utp=$_QO8QO;
	 $post->ctl=turnitintool_getCTL($course->id);
	 $post->assignname=$turnitintool->name.' - '.$_Q88j6->partname.' (Moodle '.$post->assignid.')';
	 $owner = turnitintool_get_owner($turnitintool->course);
	 $post->tem=turnitintool_get_tutor_email($owner->id);
	 $post->papertitle=$_QtlC0->submission_title;
	 $post->email=$user->email;
	 $post->firstname=$user->firstname;
	 $post->lastname=$user->lastname;
	$_I0olf=$CFG->dataroot.'/'.turnitintool_file_path($_Q8OLt,$turnitintool,$_QtlC0->userid).'/'.$_QtlC0->submission_filename;
	if (substr_count(turnitintool_file_path($_Q8OLt,$turnitintool,$_QtlC0->userid),'/')>0) {
		$_I08L0=$_I0olf;
	} else {
		$_I08L0=str_replace('/','\\',$_I0olf);
	}
	 $_QfloJ = new TIIToolClass;
	 $_QLiJL=$_QfloJ->joinClass($post,$user,2,3,get_string('joiningclass','turnitintool',''));
	 $_QOt08=$_QfloJ->getRmessage($_QLiJL);
	 $_Q8Jii=$_QfloJ->getRcode($_QLiJL);
	 if ($_Q8Jii>=100 AND $_Q8Jii!=1002) {
		turnitintool_print_error($_QOt08." CODE: ".$_Q8Jii,NULL,NULL,__FILE__,__LINE__);
		exit();
	 }
	 $_QLiJL=$_QfloJ->submitPaper($post,$_I0olf,3,3,get_string('uploadingtoturnitin','turnitintool'));
	 unset($_Q8Jii);
	 unset($_QOt08);
	 $_QOt08=$_QfloJ->getRmessage($_QLiJL);
	 $_Q8Jii=$_QfloJ->getRcode($_QLiJL);
	 if (empty($_Q8Jii)) {
		$_Q8Jii=1002;
	 }
	 if ($_Q8Jii>=100) {
		if ($_Q8Jii==1002) {
			$_QO88j=get_string('submissionconnecterror','turnitintool');
			$_Qol1C=NULL;
			$_I0CCJ=1;
		} else {
			turnitintool_print_error($_QOt08." CODE: ".$_Q8Jii,NULL,NULL,__FILE__,__LINE__);
			exit();
		}
	 } else {
		$_QO88j=get_string('submissionuploadsuccess','turnitintool');
		$_Qol1C=$_QfloJ->getObjectid($_QLiJL);
		$_I0CCJ=0;
	 }
	 $update=new object();
	 $update->submission_status=$_QO88j;
	 $update->submission_queued=$_I0CCJ;
	 $update->submission_attempts=$_QtlC0->submission_attempts++;
	 $update->submission_objectid=$_Qol1C;
	 $update->submission_modified=time();
	 $update->id=$_QtlC0->id;
	 if (!turnitintool_update_record('turnitintool_submissions',$update)) {
		turnitintool_print_error('submissionupdateerror','turnitintool',NULL,__FILE__,__LINE__);
		exit();
	 }
	 if (has_capability('mod/turnitintool:grade', get_context_instance(CONTEXT_MODULE, $_Q8OLt->id))) {
	 	turnitintool_redirect($CFG->wwwroot.'/mod/turnitintool/view.php?id='.$_Q8OLt->id.'&do=allsubmissions');
		exit();
	 } else {
	 	turnitintool_redirect($CFG->wwwroot.'/mod/turnitintool/view.php?id='.$_Q8OLt->id.'&do=submissions');
		exit();
	 }
	 exit();
}
function turnitintool_filetype_array($_I0iOI=true) {
	$_QOO18 = array(
		1 => get_string('fileupload','turnitintool'),
		2 => get_string('textsubmission','turnitintool')
		);
	if ($_I0iOI) {
		$_QOO18[NULL] = '--------------------';
		$_QOO18[0] = get_string('anytype','turnitintool');
	}
	return $_QOO18;
}
function turnitintool_view_student_feedback($_Q8OLt,$turnitintool) {
	$_QOO18='';
	return $_QOO18;
}
function turnitintool_grade_submission($_Q8OLt,$turnitintool) {
	$_QOO18='';
	return $_QOO18;
}
function turnitintool_cron() {
	global $CFG;
	if (!turnitintool_check_config()) {
		mtrace("\n".get_string('configureerror','turnitintool'));
		return false;
	} else {
		mtrace(get_string('synchronisingturnitin','turnitintool'));
		if ($_QtjLL=turnitintool_get_records('turnitintool')) {
			$_QO1If=0;
			foreach ($_QtjLL as $turnitintool) {
				if (!$_Q8L8C=turnitintool_get_records('turnitintool_parts','turnitintoolid',$turnitintool->id,'dtpost DESC')) {
					$_Q8L8C=array();
				}
				$_Q88j6=current($_Q8L8C);
				if (isset($_Q88j6->dtpost) AND $_Q88j6->dtpost>time()) { 
					$_Q8OLt=get_coursemodule_from_instance("turnitintool", $turnitintool->id, $turnitintool->course);
					turnitintool_update_all_report_scores($_Q8OLt,$turnitintool,true,false);
					turnitintool_synch_parts($_Q8OLt,$turnitintool,true,false);
					$_QO1If++;
				}
			}
			mtrace('... '.get_string('synchallsubmissions','turnitintool').' - '.$_QO1If.' '.get_string('processed','turnitintool'));
			mtrace('... '.get_string('synchassignments','turnitintool').' - '.$_QO1If.' '.get_string('processed','turnitintool'));
		}
		return true;
	}
}
function turnitintool_synch_parts($_Q8OLt,$turnitintool,$_QLliQ=false,$_QOO18=true) {
	if (((isset($_SESSION["_I0L66"][$turnitintool->id]) AND $_SESSION["_I0L66"][$turnitintool->id]==1) OR isset($_REQUEST['type'])) AND !$_QLliQ) {
		return false;
	} else {
		if (!$_Q8L8C=turnitintool_get_records_select('turnitintool_parts','turnitintoolid='.$turnitintool->id.' AND deleted=0')) {
			mtrace(get_string('partgeterror','turnitintool').' - ID: '.$turnitintool->id.'\n');
		}
		$_QtoCQ=array();
		$owner=turnitintool_get_owner($turnitintool->course);
		$_QfloJ=new TIIToolClass;
		$_I0Lti=false;
		foreach ($_Q8L8C as $_Q88j6) {
			$post->cid=turnitintool_getCID($turnitintool->course);
			$post->ctl=turnitintool_getCTL($turnitintool->course);
			$post->uid=turnitintool_getUID($owner);
			$post->uem=$owner->email;
			$post->ufn=$owner->firstname;
			$post->uln=$owner->lastname;
			$post->assign=$turnitintool->name.' - '.$_Q88j6->partname.' (Moodle: '.$_Q88j6->tiiassignid.')';
			$post->assignid=$_Q88j6->tiiassignid;
			$post->assignid=$_Q88j6->maxmarks;
			$_QLiJL=$_QfloJ->queryAssignment($post,1,1,get_string('synchassignments','turnitintool'),$_QOO18);
			$_I0ltj=$_QfloJ->getAssignmentObject($_QLiJL);
			$_QOt08=$_QfloJ->getRmessage($_QLiJL);
			$_Q8Jii=$_QfloJ->getRcode($_QLiJL);
			if (empty($_Q8Jii)) {
				$_Q8Jii=1002;
			}
			if ($_Q8Jii<100) {
				if (!$_I0Lti) {
					$_I0ll0->id=$turnitintool->id;
					$_I0ll0->anon=$_I0ltj->anon;
					$_I0ll0->reportgenspeed=$_I0ltj->report_gen_speed;
					$_I0ll0->studentreports=$_I0ltj->s_view_report;
					$_I0ll0->allowlate=$_I0ltj->late_accept_flag;
					$_I0ll0->submitpapersto=$_I0ltj->submit_papers_to;
					$_I0ll0->internetcheck=$_I0ltj->internet_check;
					$_I0ll0->journalcheck=$_I0ltj->journal_check;
					if (!$update=turnitintool_update_record('turnitintool',$_I0ll0)) {
						mtrace(get_string('turnitintoolupdateerror','turnitintool').' - ID: '.$turnitintool->id.'\n');
					}
					$_I10JI->id=$_Q88j6->id;
					$_I10JI->maxmarks=$_I0ltj->maxpoints;
					$_I10JI->dtstart=$_I0ltj->dtstart;
					$_I10JI->dtdue=$_I0ltj->dtdue;
					$_I10JI->dtpost=$_I0ltj->dtpost;
					if (!$update=turnitintool_update_record('turnitintool_parts',$_I10JI)) {
						mtrace(get_string('partupdateerror','turnitintool').' - ID: '.$_Q88j6->id.'\n');
					}
				}
			} else {
				$_QLiJL=false;
			}
		}
	}
}
function turnitintool_bulkuploadform($turnitintool) {
}
function turnitintool_bulkupload($turnitintool) {
	$_Q8J1f=false;
	return $_Q8J1f;
}
function turnitintool_get_participants($turnitintoolid) {
	return false;
}
function turnitintool_scale_used($turnitintoolid,$_I11ol) {
	$_QLiJL = false;
	return $_QLiJL;
}
function turnitintool_scale_used_anywhere($_I11ol) {
	if ($_I11ol and record_exists('turnitintool', 'grade', -$_I11ol)) {
		return true;
	} else {
		return false;
	}
}
function turnitintool_reset_course_form($course) {
    echo '<p>'.get_string('turnitintoolresetinfo', 'turnitintool').'<br />';
    $_I1QfJ = array(
	'0'=>get_string('turnitintoolresetdata0','turnitintool').'<br />',
	'1'=>get_string('turnitintoolresetdata1','turnitintool').'<br />',
	'2'=>get_string('turnitintoolresetdata2','turnitintool').'<br />'
	);
	choose_from_menu($_I1QfJ,'reset_turnitintool','0');  echo '</p>';
}
function turnitintool_delete_userdata($_I1Qof) {
	if ($_I1Qof->reset_turnitintool==0) {
		$_QO88j=turnitintool_duplicate_recycle($_I1Qof->courseid,'NEWCLASS',true);
		if (!$_QO88j['error']) {
			notify(get_string('modulenameplural','turnitintool').': '.get_string('copyassigndata','turnitintool'), 'notifysuccess');
		} else {
			notify(get_string('modulenameplural','turnitintool').': '.get_string('copyassigndataerror','turnitintool'));
		}
	} else if ($_I1Qof->reset_turnitintool==1) {
		$_QO88j=turnitintool_duplicate_recycle($_I1Qof->courseid,'OLDCLASS',true);
		if (!$_QO88j['error']) {
			notify(get_string('modulenameplural','turnitintool').': '.get_string('replaceassigndata','turnitintool'), 'notifysuccess');
		} else {
			notify(get_string('modulenameplural','turnitintool').': '.get_string('replaceassigndataerror','turnitintool'));
		}
	}
	turnitintool_duplicate_recycle($_I1Qof->courseid);
}
function turnitintool_reset_course_form_definition(&$_I1I0t) {
    $_I1I0t->addElement('header', 'turnitintoolheader', get_string('modulenameplural', 'turnitintool'));
    $_I1QfJ = array(
	'0'=>get_string('turnitintoolresetdata0','turnitintool').'<br />',
	'1'=>get_string('turnitintoolresetdata1','turnitintool').'<br />',
	'2'=>get_string('turnitintoolresetdata2','turnitintool').'<br />'
	);
	$_I1I0t->addElement('select', 'reset_turnitintool', get_string('selectoption','turnitintool'),$_I1QfJ);
}
function turnitintool_reset_userdata($_I1Qof) {
	$_QO88j = array();
	if ($_I1Qof->reset_turnitintool==0) {
		$_QO88j = turnitintool_duplicate_recycle($_I1Qof->courseid,'NEWCLASS');
	} else if ($_I1Qof->reset_turnitintool==1) {
		$_QO88j = turnitintool_duplicate_recycle($_I1Qof->courseid,'OLDCLASS');
	}
	return $_QO88j;
}
function turnitintool_reset_course_form_defaults($course) {
	return array('reset_turnitintool'=>0);
}
function turnitintool_duplicate_recycle($_QtjQt,$_Qi0C6,$_I1IoC=false) {
	global $CFG;
	if (!$_I1jIj=turnitintool_get_records('turnitintool','course',$_QtjQt)) {
		turnitintool_print_error('assigngeterror','turnitintool',NULL,__FILE__,__LINE__);
		exit();
	}
	if (!$course=turnitintool_get_record('course','id',$_QtjQt)) {
		turnitintool_print_error('coursegeterror','turnitintool',NULL,__FILE__,__LINE__);
		exit();
	}
	$_QtoCQ=array();
	$owner=turnitintool_get_owner($_QtjQt);
	foreach ($_I1jIj as $_I1j8Q) {
		if (!$_Q8L8C=turnitintool_get_records_select('turnitintool_parts','turnitintoolid='.$_I1j8Q->id.' AND deleted=0')) {
			turnitintool_print_error('partgeterror','turnitintool',NULL,__FILE__,__LINE__);
		}
		foreach ($_Q8L8C as $_Q88j6) {
			$_QtoCQ[$_QtjQt][$_I1j8Q->id][$_Q88j6->id]['cid']=turnitintool_getCID($_QtjQt);
			$_QtoCQ[$_QtjQt][$_I1j8Q->id][$_Q88j6->id]['ctl']=turnitintool_getCTL($_QtjQt);
			$_QtoCQ[$_QtjQt][$_I1j8Q->id][$_Q88j6->id]['uid']=turnitintool_getUID($owner);
			$_QtoCQ[$_QtjQt][$_I1j8Q->id][$_Q88j6->id]['uem']=$owner->email;
			$_QtoCQ[$_QtjQt][$_I1j8Q->id][$_Q88j6->id]['ufn']=$owner->firstname;
			$_QtoCQ[$_QtjQt][$_I1j8Q->id][$_Q88j6->id]['uln']=$owner->lastname;
			$_QtoCQ[$_QtjQt][$_I1j8Q->id][$_Q88j6->id]['assign']=$_I1j8Q->name.' - '.$_Q88j6->partname.' (Moodle: '.$_Q88j6->tiiassignid.')';
			$_QtoCQ[$_QtjQt][$_I1j8Q->id][$_Q88j6->id]['assignid']=$_Q88j6->tiiassignid;
			$_QtoCQ[$_QtjQt][$_I1j8Q->id][$_Q88j6->id]['max_points']=$_Q88j6->maxmarks;
		}
	}
	$_QfloJ = new TIIToolClass;
	if ($_Qi0C6=="OLDCLASS") {
		$_I1JjL=turnitintool_getCID($_QtjQt);
		$_I1JOL=turnitintool_getCTL($_QtjQt);
	} else {
		$_I1616=turnitintool_getCID($_QtjQt);
		$_I16OL=turnitintool_getCTL($_QtjQt);
		if (!$delete=turnitintool_delete_records('turnitintool_courses','courseid',$_QtjQt)) {
			turnitintool_print_error('coursedeleteerror','turnitintool',NULL,__FILE__,__LINE__);
			exit();
		}
		$_Q81l6=turnitintool_classsetup($course,$owner,1,1,'',false);
		$_I1JjL=$_Q81l6->turnitin_cid;
		$_I1JOL=$_Q81l6->turnitin_ctl;
	}
	foreach ($_QtoCQ as $_I1fJI => $_I18IO) {
		foreach ($_I18IO as $_I18tt => $_I18oI) {
			foreach ($_I18oI as $_QOJlC => $_I1Qof) {
				$post->cid=$_I1Qof['cid'];
				$post->ctl=$_I1Qof['ctl'];
				$post->uid=$_I1Qof['uid'];
				$post->uem=$_I1Qof['uem'];
				$post->ufn=$_I1Qof['ufn'];
				$post->uln=$_I1Qof['uln'];
				$post->assign=$_I1Qof['assign'];
				$post->assignid=$_I1Qof['assignid'];
				$_QLiJL=$_QfloJ->queryAssignment($post,1,1,'',false);
				$_I0ltj=$_QfloJ->getAssignmentObject($_QLiJL);
				$_QOt08=$_QfloJ->getRmessage($_QLiJL);
				$_Q8Jii=$_QfloJ->getRcode($_QLiJL);
				if (empty($_Q8Jii)) {
					$_Q8Jii=1002;
				}
				if ($_Q8Jii>=100) {
					if ($_Q8Jii==1002) {
						$_QOt08=get_string('turnitintoolgeterror','turnitintool');
					}
					$_I1tfi[]=$_QOt08;
				}
				$post->cid='';
				$post->uid='';
				$post->assignid='';
				$post->ctl=$_I1JOL;
				$_Q8jt8=strtoupper(uniqid());
				$post->name=current(explode(' (Moodle: ',$post->assign)).' (Moodle: '.$_Q8jt8.')';
				$post->dtstart=time();
				$post->dtdue=strtotime('+7 days');
				$post->dtpost=strtotime('+7 days');
				$post->s_view_report=$_I0ltj->s_view_report;
				$post->anon=$_I0ltj->anon;
				$post->report_gen_speed=$_I0ltj->report_gen_speed;
				$post->late_accept_flag=$_I0ltj->late_accept_flag;
				$post->submit_papers_to=$_I0ltj->submit_papers_to;
				$post->s_paper_check=$_I0ltj->s_paper_check;
				$post->internet_check=$_I0ltj->internet_check;
				$post->journal_check=$_I0ltj->journal_check;
				$post->max_points=$_I0ltj->maxpoints;
				$_QLiJL=$_QfloJ->createAssignment($post,'INSERT',$owner,1,1,'',false);
				$_QOt08=$_QfloJ->getRmessage($_QLiJL);
				$_Q8Jii=$_QfloJ->getRcode($_QLiJL);
				if (empty($_Q8Jii)) {
					$_Q8Jii=1002;
				}
				if ($_Q8Jii>=100) {
					if ($_Q8Jii==1002) {
						$_QOt08=get_string('turnitintoolupdateerror','turnitintool');
					}
					$_I1tfi[]=$_QOt08;
				}
				$_I1to0=$_QfloJ->getAssignid($_QLiJL);
				$post->currentassign=current(explode(' (Moodle: ',$post->assign)).' (Moodle: '.$_Q8jt8.')';
				$post->name=current(explode(' (Moodle: ',$post->name)).' (Moodle: '.$_I1to0.')';
				$post->assignid=$_I1to0;
				$post->dtstart=$_I0ltj->dtstart;
				$post->dtdue=$_I0ltj->dtdue;
				$post->dtpost=$_I0ltj->dtpost;
				$post->cid=$_I1JjL;
				$post->uid=$_I1Qof['uid'];
				$_QLiJL=$_QfloJ->createAssignment($post,'UPDATE',$owner,1,1,'',false);
				$_QOt08=$_QfloJ->getRmessage($_QLiJL);
				$_Q8Jii=$_QfloJ->getRcode($_QLiJL);
				if (empty($_Q8Jii)) {
					$_Q8Jii=1002;
				}
				if ($_Q8Jii>=100) {
					if ($_Q8Jii==1002) {
						$_QOt08=get_string('turnitintoolupdateerror','turnitintool');
					}
					$_I1tfi[]=$_QOt08;
				}
				$_Qt1l0=new object();
				$_Qt1l0->id=$_QOJlC;
				$_Qt1l0->tiiassignid=$_I1to0;
				if (!$update=turnitintool_update_record('turnitintool_parts',$_Qt1l0)) {
					turnitintool_print_error('partupdateerror','turnitintool',NULL,__FILE__,__LINE__);
					exit();
				}
				if (!$delete=turnitintool_delete_records('turnitintool_submissions','submission_part',$_QOJlC)) {
					turnitintool_print_error('submissiondeleteerror','turnitintool',NULL,__FILE__,__LINE__);
					exit();
				}
				unset($post);
			}
		}
	}
	if ($_Qi0C6=="OLDCLASS") { 
		foreach ($_QtoCQ as $_I1fJI => $_I18IO) {
			foreach ($_I18IO as $_I18tt => $_I18oI) {
				foreach ($_I18oI as $_QOJlC => $_I1Qof) {
					$post->cid=$_I1Qof['cid'];
					$post->ctl=$_I1Qof['ctl'];
					$post->uid=$_I1Qof['uid'];
					$post->uem=$_I1Qof['uem'];
					$post->ufn=$_I1Qof['ufn'];
					$post->uln=$_I1Qof['uln'];
					$post->name=$_I1Qof['assign'];
					$post->assignid=$_I1Qof['assignid'];
					$_QLiJL=$_QfloJ->deleteAssignment($post,$owner,1,1,'',false);
					$_QOt08=$_QfloJ->getRmessage($_QLiJL);
					$_Q8Jii=$_QfloJ->getRcode($_QLiJL);
					if (empty($_Q8Jii)) {
						$_Q8Jii=1002;
					}
					if ($_Q8Jii>=100) {
						if ($_Q8Jii==1002) {
							$_QOt08=get_string('turnitintooldeleteerror','turnitintool');
						}
						$_I1tfi[]=$_QOt08;
					}
				}
			}
		}
	} else {
		if (isset($_I1tfi)) { 
			$_I1Otj=new object();
			$_I1Otj->id=$_QtjQt;
			$_I1Otj->turnitin_cid=$_I1616;
			$_I1Otj->turnitin_ctl=$_I16OL;
			if (!$_I1o88=turnitintool_update_record('turnitintool_courses',$_I1Otj)) {
				turnitintool_print_error('classupdateerror','turnitintool',NULL,__FILE__,__LINE__);
				exit();
			}
		}
	}
	if (isset($_I1tfi) AND $CFG->turnitin_enablediagnostic=='1') {
		$_I1ol6='-----------<br />['.join(']<br />-----------<br />[',$_I1tfi).']';
	} else {
		$_I1ol6='';
	}
	$_QO88j=NULL;
	if (!$_I1IoC) {
		if (isset($_I1tfi) AND $_Qi0C6=="NEWCLASS") {
			$_QO88j[] = array('component'=>get_string('modulenameplural','turnitintool'), 'item'=>get_string('copyassigndata','turnitintool').$_I1ol6, 'error'=>true);
		} else if (!isset($_I1tfi) AND $_Qi0C6=="NEWCLASS") {
			$_QO88j[] = array('component'=>get_string('modulenameplural','turnitintool'), 'item'=>get_string('copyassigndata','turnitintool'), 'error'=>false);
		} else if (isset($_I1tfi) AND $_Qi0C6=="OLDCLASS") {
			$_QO88j[] = array('component'=>get_string('modulenameplural','turnitintool'), 'item'=>get_string('replaceassigndata','turnitintool').$_I1ol6, 'error'=>true);
		} else if (!isset($_I1tfi) AND $_Qi0C6=="OLDCLASS") {
			$_QO88j[] = array('component'=>get_string('modulenameplural','turnitintool'), 'item'=>get_string('replaceassigndata','turnitintool'), 'error'=>false);
		}
	} else {
		if (isset($_I1tfi) AND $_Qi0C6=="NEWCLASS") {
			$_QO88j['error'] = true;
		} else if (!isset($_I1tfi) AND $_Qi0C6=="NEWCLASS") {
			$_QO88j['error'] = false;
		} else if (isset($_I1tfi) AND $_Qi0C6=="OLDCLASS") {
			$_QO88j['error'] = true;
		} else if (!isset($_I1tfi) AND $_Qi0C6=="OLDCLASS") {
			$_QO88j['error'] = false;
		}
	}
	return $_QO88j;
}
function turnitintool_buildgrades($turnitintool,$_Qo6lJ) {
	if ($_Q8lfO=turnitintool_get_records_select('turnitintool_submissions','turnitintoolid='.$turnitintool->id.' AND userid='.$_Qo6lJ->id)) {
		$_QtI1L = new object();
		$_QtI1L->userid = $_Qo6lJ->id;
		$_I1C6O=turnitintool_grades($turnitintool->id);
		$_QCo8l=number_format($_I1C6O->grades[$_Qo6lJ->id],1);
		if ($_QCo8l=='-') {
			$_QCo8l=NULL;
		}
		$_QtI1L->rawgrade=$_QCo8l;
		return $_QtI1L;
	} else {
		return new object();
	}
}
function turnitintool_grades($turnitintoolid) {
	$_QLiJL=false;
	if ($_Q8lfO=turnitintool_get_records('turnitintool_submissions','turnitintoolid',$turnitintoolid)) {
		$turnitintool=turnitintool_get_record('turnitintool','id',$turnitintoolid);
		$_Q8L8C=turnitintool_get_records_select('turnitintool_parts',"turnitintoolid=".$turnitintoolid." AND deleted=0","dtpost DESC");
		$_QtoCQ=array_keys($_Q8L8C);
		$_Q8OLt=get_coursemodule_from_instance("turnitintool", $turnitintool->id, $turnitintool->course);
		foreach ($_Q8lfO as $_QtlC0) {
			$_QtlC0=get_object_vars($_QtlC0);
			$_I1iQl=array_keys($_QtlC0);
			for ($_Q8ILi=0;$_Q8ILi<count($_I1iQl);$_Q8ILi++) {
				if (in_array($_QtlC0['submission_part'],$_QtoCQ)) {
					$_I1ijQ=$_I1iQl[$_Q8ILi];
					$_I1if1=$_QtlC0[$_I1ijQ];
					$_I1LJ1=$_QtlC0["userid"];
					$_I1Loo=$_QtlC0["id"];
					$_QCOo6[$_I1LJ1][$_I1Loo]->$_I1ijQ=$_I1if1;
				}
			}
		}
		$_I1LiQ=array_keys($_QCOo6); 
		foreach ($_I1LiQ as $userid) {
			$_QtI1L[$userid]=turnitintool_overallgrade($turnitintool,$_QCOo6,$userid);
		}
		$_QLiJL->grades = $_QtI1L;
		$_QLiJL->maxgrade = $turnitintool->grade;
	}
    return $_QLiJL;
}
function turnitintool_install() {
	 return true;
}
function turnitintool_uninstall() {	
	return true;
}
function turnitintool_check_config() {
	global $CFG;
	if (!isset($CFG->turnitin_account_id) OR !isset($CFG->turnitin_subaccount_id) OR !isset($CFG->turnitin_enablediagnostic) OR !isset($CFG->turnitin_secretkey) OR !isset($CFG->turnitin_apiurl) OR !isset($CFG->turnitin_usegrademark) OR !isset($CFG->turnitin_agreement) OR !isset($CFG->turnitin_useanon) OR !isset($CFG->turnitin_studentemail)) {
		return false;
	} else {
		return true;
	}
}
function turnitintool_is_owner($_QtjQt) {
	global $USER, $CFG;
	if ($course=turnitintool_get_record('turnitintool_courses','courseid',$_QtjQt)) {
		$_I1LLQ=$course->ownerid;
	} else {
		$_I1LLQ=NULL;
	}
	if ($_I1LLQ==$USER->id) {
		return true;
	} else {
		return false;
	}
}
function turnitintool_get_owner($_QtjQt) {
	global $CFG;
	if ($course=turnitintool_get_record('turnitintool_courses','courseid',$_QtjQt)) {
		return turnitintool_get_moodleuser($course->ownerid,NULL,__FILE__,__LINE__);
	} else {
		return NULL;
	}
}
function turnitintool_pst_datetime($_I1l6J,$_QoO18='Ymd') {
	$_IQ00i = strtotime(gmdate('Y/m/d H:i:s',$_I1l6J).'-8 hours');
	return date($_QoO18,$_IQ00i);
}
function turnitintool_seconds_to_words($_IQ106) {
    $_QLiJL = "";
	$_IQ1CO = (int)($_IQ106/86400);
	$_IQQ6j = (int)(($_IQ106-($_IQ1CO*86400))/3600);
    if($_IQQ6j > 0)
    {
        $_QLiJL .= "$_IQQ6j ".get_string('hrs','turnitintool');
    }
	$_IQQO1 = (int)(($_IQ106-$_IQ1CO*86400-$_IQQ6j*3600)/60);
    if($_IQQ6j > 0 || $_IQQO1 > 0)
    {
        $_QLiJL .= " $_IQQO1 ".get_string('mins','turnitintool');
    } else {
		$_IQI8j = (int)($_IQ106 - ($_IQ1CO*86400)-($_IQQ6j*3600)-($_IQQO1*60)); 
		if (intval($_IQI8j)==0) {
			$_IQI8j='-';
		}
    	$_QLiJL .= " $_IQI8j ".get_string('secs','turnitintool');
	}
    return $_QLiJL;
}
function turnitintool_start_loader($_Q8I6l=1, $_QflLo=1, $_QO88j='',$_QOO18=true) {
	global $CFG,$loaderOn,$loadingdone,$timethen,$timestarted;
	$timenow=time();
	if (!isset($timestarted)) {
		$timestarted=$timenow;
	}
	$_IQfjf=(($timenow-$timestarted)/$_Q8I6l)*($_QflLo-$_Q8I6l+1);
	if ($_Q8I6l>ceil($_QflLo-($_QflLo*0.98))) {
		$_IQfo1=get_string('remaining','turnitintool',turnitintool_seconds_to_words(ceil($_IQfjf)));
	} else {
		$_IQfo1=get_string('estimatingtime','turnitintool');
	}
	$_IQfll=ceil(($_Q8I6l/$_QflLo)*100);	
	$_IQ8It=$_IQfll.'%';
	$timethen=$_IQfjf;
	while (ob_get_level()) {
		ob_end_flush();
	}
	if (ob_get_length() === false) {
		ob_start();
	}
	if ($_QOO18) {
		if (!isset($loadingdone)) {
			echo '<?xml version="1.0" encoding="UTF-8"?>
				<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
				<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
				<head>
				<script type="text/javascript" language="javascript">
				function updateLoader(proc,total,percentdone,timeleft,status) {
					document.getElementById("loaderBlock").style.display="block";
					pos=proc;
					tot=total;
					var bar=document.getElementById("barBlock");
					backpos=(pos/tot*250)-250;
					bar.style.border="1px solid #999999";
					bar.style.backgroundImage="url('.$CFG->wwwroot.'/mod/turnitintool/images/progressgrad.gif)";
					bar.style.backgroundPosition=backpos+"px 0px";
					bar.style.backgroundRepeat="no-repeat";
					document.getElementById("statusText").innerHTML=status+"<br />"+percentdone+" - ("+timeleft+")";
					document.getElementById("headText").innerHTML="'.get_string('turnitinloading','turnitintool').'";
				}
				</script>
				<style type="text/css">
				#loaderBlock {
					position: absolute;
					top: 0;
					left: 0;
					width: 100%;
					height: 100%;
					border: 0px solid black;
					z-index: 1001;
					background-color: #FFFFFF;
				}
				#loaderBlock #loaderBar {
					position: absolute;
					top: 45%;
					width: 100%;
					padding: 0px;
					text-align: center;
					border: 0px solid black;
				}
				#loaderBlock #headText {
					color: #999999;
					font-family: arial,verdana,sans;
					font-weight: bold;
					font-style: italic;
					border: 0px solid black;
				}
				#loaderBlock #statusText {
					color: #999999;
					font-size: 0.85em;
					font-family: arial,verdana,sans;
					font-style: italic;
					border: 0px solid black;
				}
				#loaderBlock #barBlock {
					width: 249px;
					height: 14px;
					margin: 8px auto 8px auto;
				}
				</style>
				</head>
				<body>
			<div id="loaderBlock">
				<div id="loaderBar">
					<div id="headText">&nbsp;</div>
					<div id="barBlock">&nbsp;</div>
					<div id="statusText">&nbsp;</div>
				</div>
			</div>';
			$loadingdone=true;
		} 
		echo '
		<script language="javascript" type="text/javascript">
			updateLoader('.$_Q8I6l.','.$_QflLo.',"'.$_IQ8It.'","'.$_IQfo1.'","'.$_QO88j.'");
		</script>';
		$loaderOn=true;
		ob_flush();
		flush();
		echo '
		<script language="javascript" type="text/javascript">
			document.getElementById("loaderBlock").style.display="none";
		</script>';
		if ($_Q8I6l==$_QflLo) {
			echo '</body></html>';
		}
	}
}
function turnitintool_end_loader() {
	global $loaderOn;
	echo '<script language="javascript">
		document.getElementById("loaderBlock").style.display="none";
	</script>';
	$loaderOn=false;
}
function turnitintool_url_jumpto($userid,$jumppage,$post) {
	global $CFG;
	$_QfloJ = new TIIToolClass;
	$_Qo6lJ=turnitintool_get_moodleuser($userid,NULL,__FILE__,__LINE__);
	turnitintool_usersetup($_Qo6lJ,2,1,1,get_string('userprocess','turnitintool'));
	if ($jumppage=='grade') {
		$_IQtQL=$_QfloJ->getGradeMarkLink($post,$_Qo6lJ);
	} else if ($jumppage=='report') {
		$_IQtQL=$_QfloJ->getReportLink($post,$_Qo6lJ);
	} else if ($jumppage=='submission') {
		$_IQtQL=$_QfloJ->getSubmissionURL($post,$_Qo6lJ);
	} else {
		header('Content-Disposition: attachment;');
		$_IQtQL=$_QfloJ->getSubmissionDownload($post,$_Qo6lJ);
	}
	turnitintool_redirect($_IQtQL);
	exit();
}
function turnitintool_replace_quote($_IQtII) {
	return str_replace("'","&#39;",$_IQtII);
}
function turnitintool_redirect($_IQtQL) {
	if (!headers_sent()) {
		header('Location: '.$_IQtQL);
	} else {
		echo '
		<a href="'.$_IQtQL.'" id="redirectlink">'.get_string('redirect','turnitintool').'</a>
		<script language="javascript">
		document.getElementById("redirectlink").style.display="none";
		location.href="'.$_IQtQL.'";
		</script>
		';
	}
	exit();
}
function turnitintool_get_records_sql($_IQtC8,$_Q8CiI=NULL,$_IQOj6=0,$_IQOLo=0) {
	global $DB;
	if (is_callable(array($DB,'get_records_sql'))) {
		return $DB->get_records_sql($_IQtC8,$_Q8CiI,$_IQOj6,$_IQOLo);
	} else {
		return get_records_sql($_IQtC8,$_Q8CiI,$_IQOj6,$_IQOLo);
	}
}
function turnitintool_count_records_sql($_IQtC8,$_Q8CiI=null) {
	global $DB;
	if (is_callable(array($DB,'count_records_sql'))) {
		return $DB->count_records_sql($_IQtC8,$_Q8CiI);
	} else {
		return count_records_sql($_IQtC8,$_Q8CiI);
	}
}
function turnitintool_get_record($_Qo0t8,$_IQofJ='',$_IQoi0='',$_IQoLQ='',$_IQC8J='',$_IQCil='',$_IQiJ0='',$_IQi6C='*') {
	global $DB;
	if (is_callable(array($DB,'get_record'))) {
		if (!empty($_IQofJ)) {
			$_IQitt[$_IQofJ]=$_IQoi0;
		}
		if (!empty($_IQoLQ)) {
			$_IQitt[$_IQoLQ]=$_IQC8J;
		}
		if (!empty($_IQCil)) {
			$_IQitt[$_IQCil]=$_IQiJ0;
		}
		return $DB->get_record($_Qo0t8,$_IQitt,$_IQi6C);
	} else {
		return get_record($_Qo0t8,$_IQofJ,$_IQoi0,$_IQoLQ,$_IQC8J,$_IQCil,$_IQiJ0,$_IQi6C);
	}
}
function turnitintool_get_records($_Qo0t8,$_IQLQo='',$_QCO80='',$_IQLJf='',$_IQi6C='*',$_IQOj6='',$_IQOLo='') {
	global $DB;
	if (is_callable(array($DB,'get_records'))) {
		if (!empty($_IQLQo)) {
			$_IQitt[$_IQLQo]=$_QCO80;
		} else {
			$_IQitt=array();
		}
		return $DB->get_records($_Qo0t8,$_IQitt,$_IQLJf,$_IQi6C,$_IQOj6,$_IQOLo);
	} else {
		return get_records($_Qo0t8,$_IQLQo,$_QCO80,$_IQLJf,$_IQi6C,$_IQOj6,$_IQOLo);
	}
}
function turnitintool_get_records_select($_Qo0t8,$_IQitt,$_IQLJf='',$_IQi6C='*',$_IQOj6='',$_IQOLo='') {
	global $DB;
	if (is_callable(array($DB,'get_records_select'))) {
		return $DB->get_records_select($_Qo0t8,$_IQitt,NULL,$_IQLJf,$_IQi6C,$_IQOj6,$_IQOLo);
	} else {
		return get_records_select($_Qo0t8,$_IQitt,$_IQLJf,$_IQi6C,$_IQOj6,$_IQOLo);
	}
}
function turnitintool_get_record_select($_Qo0t8,$_IQitt,$_IQi6C='*') {
	global $DB;
	if (is_callable(array($DB,'get_record_select'))) {
		return $DB->get_record_select($_Qo0t8,$_IQitt,NULL,$_IQi6C);
	} else {
		return get_record_select($_Qo0t8,$_IQitt,$_IQi6C);
	}
}
function turnitintool_update_record($_Qo0t8,$_IQl10) {
	global $DB;
	$_IQl10=(object) array_map('turnitintool_replace_quote', (array)$_IQl10);
	if (is_callable(array($DB,'update_record'))) {
		return $DB->update_record($_Qo0t8,$_IQl10);
	} else {
		return update_record($_Qo0t8,$_IQl10);
	}
}
function turnitintool_insert_record($_Qo0t8,$_IQl10,$_IQlQC=true,$_IQloJ='id') {
	global $DB;
	$_IQl10=(object) array_map('turnitintool_replace_quote', (array)$_IQl10);
	if (is_callable(array($DB,'insert_record'))) {
		return $DB->insert_record($_Qo0t8,$_IQl10,$_IQlQC,$_IQloJ);
	} else {
		return insert_record($_Qo0t8,$_IQl10,$_IQlQC,$_IQloJ);
	}
}
function turnitintool_delete_records_select($_Qo0t8,$_IQitt='') {
	global $DB;
	if (is_callable(array($DB,'delete_records_select'))) {
		return $DB->delete_records_select($_Qo0t8,$_IQitt);
	} else {
		return delete_records_select($_Qo0t8,$_IQitt);
	}
}
function turnitintool_delete_records($_Qo0t8,$_IQofJ='',$_IQoi0='',$_IQoLQ='',$_IQC8J='',$_IQCil='',$_IQiJ0='') {
	global $DB;
	if (is_callable(array($DB,'delete_records'))) {
		if (!empty($_IQofJ)) {
			$_IQitt[$_IQofJ]=$_IQoi0;
		}
		if (!empty($_IQoLQ)) {
			$_IQitt[$_IQoLQ]=$_IQC8J;
		}
		if (!empty($_IQCil)) {
			$_IQitt[$_IQCil]=$_IQiJ0;
		}
		return $DB->delete_records($_Qo0t8,$_IQitt);
	} else {
		return delete_records($_Qo0t8,$_IQofJ,$_IQoi0,$_IQoLQ,$_IQC8J,$_IQCil,$_IQiJ0);
	}
}
function turnitintool_count_records_select($_Qo0t8,$_IQitt='',$_II0Qf='COUNT(*)') {
	global $DB;
	if (is_callable(array($DB,'count_records_select'))) {
		return $DB->count_records_select($_Qo0t8,$_IQitt,NULL,$_II0Qf);
	} else {
		return count_records_select($_Qo0t8,$_IQitt,$_II0Qf);
	}
}
function turnitintool_count_records($_Qo0t8,$_IQofJ='',$_IQoi0='',$_IQoLQ='',$_IQC8J='',$_IQCil='',$_IQiJ0='') {
	global $DB;
	if (is_callable(array($DB,'count_records'))) {
		if (!empty($_IQofJ)) {
			$_IQitt[$_IQofJ]=$_IQoi0;
		}
		if (!empty($_IQoLQ)) {
			$_IQitt[$_IQoLQ]=$_IQC8J;
		}
		if (!empty($_IQCil)) {
			$_IQitt[$_IQCil]=$_IQiJ0;
		}
		return $DB->count_records($_Qo0t8,$_IQitt);
	} else {
		return count_records($_Qo0t8,$_IQofJ,$_IQoi0,$_IQoLQ,$_IQC8J,$_IQCil,$_IQiJ0);
	}
}
function turnitintool_search_users($_QtjQt, $_II06j, $_II1QQ, $_IQLJf='', $_IIQ1l='') {
	global $DB;
	if (is_callable(array($DB,'count_records')) AND !empty($_IIQ1l)) {
		$_IIQl6=explode(",",$_IIQ1l);
	} else if (is_callable(array($DB,'count_records'))) {
		$_IIQl6=array();
	} else {
		$_IIQl6=$_IIQ1l;
	}
	return search_users($_QtjQt, $_II06j, $_II1QQ, $_IQLJf, $_IIQl6);
}
function turnitintool_box_start($_IIIfC='generalbox', $_Qt8jo='', $_QLiJL=false) {
	global $_IIIC0;
	if (is_callable(array($_IIIC0,'box_start')) AND !$_QLiJL) {
		echo $_IIIC0->box_start($_IIIfC,$_Qt8jo);
	} else if (is_callable(array($_IIIC0,'box_start'))) {
		return $_IIIC0->box_start($_IIIfC,$_Qt8jo);
	} else {
		return print_box_start($_IIIfC,$_Qt8jo,$_QLiJL);
	}
}
function turnitintool_box_end($_QLiJL=false) {
	global $_IIIC0;
	if (is_callable(array($_IIIC0,'box_end')) AND !$_QLiJL) {
		echo $_IIIC0->box_end();
	} else if (is_callable(array($_IIIC0,'box_end'))) {
		return $_IIIC0->box_end();
	} else {
		return print_box_end($_QLiJL);
	}
}
function turnitintool_help_icon($_IIj6j, $_QClCl, $_Q8oLQ='moodle', $_IIjl8=true, $_IIJij=false, $_II6ft='', $_QLiJL=false, $_II6tl='') {
	global $_IIIC0;
	if (is_callable(array($_IIIC0,'help_icon'))) {
		$_IIfjQ=moodle_help_icon::make($_IIj6j, $_QClCl, $_Q8oLQ, $_IIJij);
		$_IIfjQ->image=$_IIjl8;
		if (!$_QLiJL) {
			echo $_IIIC0->help_icon($_IIfjQ);
		} else {
			return $_IIIC0->help_icon($_IIfjQ);
		}
	} else {
		return helpbutton($_IIj6j, $_QClCl, $_Q8oLQ, $_IIjl8, $_IIJij, $_II6ft, $_QLiJL, $_II6tl);
	}
}
function turnitintool_print_table($_Qo0t8, $_QLiJL=false) {
	global $_IIIC0;
	if (is_callable(array($_IIIC0,'table'))) {
		$_IIfo0=$_Qo0t8;
		$_Qo0t8 = new html_table();
		foreach ($_IIfo0 as $_Qtt0O => $_II8t6) {
			if ($_Qtt0O!='class') {
				$_Qo0t8->$_Qtt0O = $_II8t6;
			} else {
				$_IIt68=$_II8t6;
			}
		}
		$_Qo0t8->set_classes($_IIt68);
		if (!$_QLiJL) {
			echo $_IIIC0->table($_Qo0t8);
		} else {
			return $_IIIC0->table($_Qo0t8);
		}
	} else {
		return print_table($_Qo0t8, $_QLiJL);
	}
}
function turnitintool_header($_Q8OLt,$course,$_IQtQL,$_QClCl='', $_IItL8='', $_IIOiJ='', $_IIoOQ='',
                      $_IICIL='', $_IICff=true, $_IIi6f='&nbsp;', $_IIiCO=null,
                      $_IIilQ=false, $_IILiQ='', $_QLiJL=false) {
	global $_IIlCo,$_IIIC0;
	if (is_callable(array($_IIIC0,'header'))) {
		$_IIlCo->set_url($_IQtQL);
		$_IIlCo->set_title($_QClCl);
    	$_IIlCo->set_heading($_IItL8);
		$_IIlCo->navbar->add($_QClCl);
		$_Ij0oj=($_Q8OLt!=NULL) ? $_Q8OLt->id : NULL;
		$_QtjQt=($course!=NULL) ? $course->id : NULL;
		if (!is_null($_Ij0oj)) {
			$_QttoQ = get_context_instance(CONTEXT_MODULE,$_Ij0oj);
			$_Ij1OQ = '<table><tr><td>'.update_module_button($_Ij0oj, $_QtjQt, get_string('modulename', 'turnitintool')).'</td>';
			if ($_IIlCo->user_allowed_editing() && !empty($CFG->showblocksonmodpages)) {
				$_Ij1OQ .= '<td><form '.$CFG->frametarget.' method="get" action="view.php"><div>'.
					'<input type="hidden" name="id" value="'.$_Q8OLt->id.'" />'.
					'<input type="hidden" name="edit" value="'.($_IIlCo->user_is_editing()?'off':'on').'" />'.
					'<input type="submit" value="'.get_string($_IIlCo->user_is_editing()?'blockseditoff':'blocksediton').'" /></div></form></td>';
			}
			$_Ij1OQ .= '</tr></table>';
			$_IIlCo->set_button($_Ij1OQ);
		}
		if ($_QLiJL) {
			return $_IIIC0->header();
		} else {
			echo $_IIIC0->header();
		}
	} else {
		return print_header($_QClCl,$_IItL8,$_IIOiJ,$_IIoOQ,$_IICIL,$_IICff,$_IIi6f,$_IIiCO,$_IIilQ,$_IILiQ,$_QLiJL);
	}
}
function turnitintool_footer($course = NULL, $_IjQQf = NULL, $_QLiJL = false) {
	global $_IIlCo,$_IIIC0;
	if (is_callable(array($_IIIC0,'footer'))) {
		if ($_QLiJL) {
			return $_IIIC0->footer();
		} else {
			echo $_IIIC0->footer();
		}
	} else {
		return print_footer($course,$_IjQQf,$_QLiJL);
	}
}
function turnitintool_print_error($_QtlJi,$_Q8oLQ=NULL,$_QCjff='',$_IjQ8C=NULL,$file=__FILE__,$_IjQOj=__LINE__) {
	global $CFG;
	if (is_null($_Q8oLQ)) {
		$_IjIfC=$_QtlJi;
	} else {
		$_IjIfC=get_string($_QtlJi,$_Q8oLQ,$_IjQ8C);
	}
	if ($CFG->turnitin_enablediagnostic=="1") {
		$_IjIfC.=' ('.basename($file).' | '.$_IjQOj.')';
	}
	if (!ob_get_contents()) {
	} else { 
		ob_flush();
		flush();
	}
	print_error('string','turnitintool',$_QCjff,'<span style="color: #888888;">'.$_IjIfC.'</span>'.$_IjICQ);
	exit();
}
class TIIToolClass {
    var $_IjjJf = false;
	function qecho($_IQtII=NULL, $_IjJ08=NULL, $_QLiJL=false) {
		if (isset($_IQtII) AND !empty($_IQtII) AND $_QLiJL) {
			return $_IQtII;
		} else if (isset($_IjJ08) AND !empty($_IjJ08) AND $_QLiJL) {
			return $_IjJ08;
		} else if (isset($_IQtII) AND !empty($_IQtII)) {
			echo $_IQtII;
		} else if (isset($_IjJ08) AND !empty($_IjJ08)) {
			echo $_IjJ08;
		}
	}
	function xmlToArray($_IQtII) {
		$_IjJC6 = xml_parser_create();
        $_QOO18=xml_parse_into_struct($_IjJC6, $_IQtII, $this->_xmlvalues, $this->_xmlkeys);
        xml_parser_free($_IjJC6);
		return $_QOO18;
	}
	function getSubmissionArray($_IQtII) {
		$_QOO18=array();
		$_IjJL8=$this->xmlToArray($_IQtII);
		if (isset($this->_xmlkeys['OBJECTID']) AND is_array($this->_xmlkeys['OBJECTID'])) {
	        for ($_Q8ILi=0;$_Q8ILi<count($this->_xmlkeys['OBJECTID']);$_Q8ILi++) {
				$_IjJlL = $this->_xmlkeys['USERID'][$_Q8ILi];
				$_Ij6Lf = $this->_xmlkeys['OBJECTID'][$_Q8ILi];
				$_Ijfto = $this->_xmlkeys['OVERLAP'][$_Q8ILi];
				$_Ij8Ij = $this->_xmlkeys['SIMILARITYSCORE'][$_Q8ILi];
				$_Ij8iQ = $this->_xmlkeys['SCORE'][$_Q8ILi];
				$_Ij8lQ = $this->_xmlkeys['FIRSTNAME'][$_Q8ILi];
				$_Ijt1J = $this->_xmlkeys['LASTNAME'][$_Q8ILi];
				$_Ijt6I = $this->_xmlkeys['TITLE'][$_Q8ILi];
				$_Ijt86 = $this->_xmlkeys['ANON'][$_Q8ILi];
				$_IjOJI = $this->_xmlkeys['GRADEMARKSTATUS'][$_Q8ILi];
				$_IjojJ = $this->_xmlkeys['DATE_SUBMITTED'][$_Q8ILi];
				$_Qol1C = $this->_xmlvalues[$_Ij6Lf]['value'];
				$_QOO18[$_Qol1C]["userid"] = $this->_xmlvalues[$_IjJlL]['value'];
				if (isset($this->_xmlvalues[$_Ij8lQ]['value'])) {
					$_QOO18[$_Qol1C]["firstname"] = $this->_xmlvalues[$_Ij8lQ]['value'];
				} else {
					$_QOO18[$_Qol1C]["firstname"] = '';
				}
				if (isset($this->_xmlvalues[$_Ijt1J]['value'])) {
					$_QOO18[$_Qol1C]["lastname"] = $this->_xmlvalues[$_Ijt1J]['value'];
				} else {
					$_QOO18[$_Qol1C]["lastname"] = '';
				}
				$_QOO18[$_Qol1C]["title"] = $this->_xmlvalues[$_Ijt6I]['value'];
				if (isset($this->_xmlvalues[$_Ij8Ij]['value']) AND $this->_xmlvalues[$_Ij8Ij]['value']!="-1") {
					$_QOO18[$_Qol1C]["similarityscore"] = $this->_xmlvalues[$_Ij8Ij]['value'];
				} else {
					$_QOO18[$_Qol1C]["similarityscore"] = NULL;
				}
				if (isset($this->_xmlvalues[$_Ijfto]['value']) AND $this->_xmlvalues[$_Ijfto]['value']!="-1" AND !is_null($_QOO18[$_Qol1C]["similarityscore"])) {
					$_QOO18[$_Qol1C]["overlap"] = $this->_xmlvalues[$_Ijfto]['value'];
				} else {
					$_QOO18[$_Qol1C]["overlap"] = NULL;
				}
				if (isset($this->_xmlvalues[$_Ij8iQ]['value']) AND $this->_xmlvalues[$_Ij8iQ]['value']!="-1") {
					$_QOO18[$_Qol1C]["grademark"] = $this->_xmlvalues[$_Ij8iQ]['value'];
				} else {
					$_QOO18[$_Qol1C]["grademark"] = NULL;
				}
				if (isset($this->_xmlvalues[$_Ijt86]['value']) AND $this->_xmlvalues[$_Ijt86]['value']!="-1") {
					$_QOO18[$_Qol1C]["anon"] = $this->_xmlvalues[$_Ijt86]['value'];
				} else {
					$_QOO18[$_Qol1C]["anon"] = NULL;
				}
				if (isset($this->_xmlvalues[$_IjOJI]['value']) AND $this->_xmlvalues[$_IjOJI]['value']!="-1") {
					$_QOO18[$_Qol1C]["grademarkstatus"] = $this->_xmlvalues[$_IjOJI]['value'];
				} else {
					$_QOO18[$_Qol1C]["grademarkstatus"] = NULL;
				}
				if (isset($this->_xmlvalues[$_IjojJ]['value']) AND $this->_xmlvalues[$_IjojJ]['value']!="-1") {
					$_QOO18[$_Qol1C]["date_submitted"] = $this->_xmlvalues[$_IjojJ]['value'];
				} else {
					$_QOO18[$_Qol1C]["date_submitted"] = NULL;
				}
			}
			return $_QOO18;
		} else {
			return $_QOO18;
		}
	}
	function getRmessage($_IQtII) {
		if ($this->xmlToArray($_IQtII)) {
	        $_Ql1iI = $this->_xmlkeys['RMESSAGE'][0];
			return $this->_xmlvalues[$_Ql1iI]['value'];
		} else {
			return '';
		}
    }
	function getUserID($_IQtII) {
		if ($this->xmlToArray($_IQtII)) {
	        $_Ql1iI = $this->_xmlkeys['USERID'][0];
			return $this->_xmlvalues[$_Ql1iI]['value'];
		} else {
			return '';
		}
    }
	function getClassID($_IQtII) {
		if ($this->xmlToArray($_IQtII)) {
	        $_Ql1iI = $this->_xmlkeys['CLASSID'][0];
			return $this->_xmlvalues[$_Ql1iI]['value'];
		} else {
			return '';
		}
    }
    function getRcode($_IQtII) {
		if ($this->xmlToArray($_IQtII)) {
	        $_Ql1iI = $this->_xmlkeys['RCODE'][0];
	        return $this->_xmlvalues[$_Ql1iI]['value'];
    	} else {
			return '';
		}
	}
	function getObjectid($_IQtII) {
		if ($this->xmlToArray($_IQtII)) {
        	$_Ql1iI = $this->_xmlkeys['OBJECTID'][0];
        	return $this->_xmlvalues[$_Ql1iI]['value'];
		} else {
			return '';
		}
    }
	function getAssignid($_IQtII) {
		if ($this->xmlToArray($_IQtII)) {
        	$_Ql1iI = $this->_xmlkeys['ASSIGNMENTID'][0];
        	return $this->_xmlvalues[$_Ql1iI]['value'];
		} else {
			return '';
		}
    }
	function getScore($_IQtII) {
		if ($this->xmlToArray($_IQtII) AND isset($this->_xmlkeys['ORIGINALITYSCORE'][0])) {
        	$_Ql1iI = $this->_xmlkeys['ORIGINALITYSCORE'][0];
        	return $this->_xmlvalues[$_Ql1iI]['value'];
		} else {
			return '';
		}
    }
	function setCallback($_Ijo6J) {
		$this->_IjjJf = $_Ijo6J;
	}
	function doRequest($_Ijoof, $_IQtQL, $_QoQot, $_IjC8t=true, $_Q8I6l=1, $_QflLo=1, $_QO88j='',$_QOO18=true) {
		turnitintool_start_loader($_Q8I6l,$_QflLo,$_QO88j,$_QOO18);
		set_time_limit(0);
		$_IjCLi = curl_init();
		$_Iji6L="Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.1) Gecko/20061204 Firefox/2.0.0.1";
		curl_setopt($_IjCLi, CURLOPT_URL, $_IQtQL);
		curl_setopt($_IjCLi, CURLOPT_HEADER, 0);
		curl_setopt($_IjCLi, CURLOPT_USERAGENT, $_Iji6L);
		curl_setopt($_IjCLi, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($_IjCLi, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($_IjCLi, CURLOPT_ENCODING, '');
		curl_setopt($_IjCLi, CURLOPT_MAXREDIRS, 10);
		curl_setopt($_IjCLi, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($_IjCLi, CURLOPT_SSL_VERIFYPEER, 0);
		if ($_IjC8t) {
			curl_setopt($_IjCLi, CURLOPT_TIMEOUT, 120);
		}
		if ($_Ijoof == 'POST') {
			curl_setopt($_IjCLi, CURLOPT_POSTFIELDS, $_QoQot);
		}
		$_I1Qof = curl_exec($_IjCLi);
		if ($_I1Qof) {
			if ($this->_IjjJf)
			{
				$_IjjJf = $this->_IjjJf;
				$this->_IjjJf = false;
				$_Q8J1f=call_user_func($_IjjJf, $_I1Qof);
			} else {
				$_Q8J1f=$_I1Qof;
			}
		} else {
			$_Q8J1f=curl_error($_IjCLi);
		}
		sleep(TII_LATENCY_SLEEP);
		$this->doLogging($_IQtQL,$_QoQot,$_Q8J1f);
		return $_Q8J1f;
		curl_close($_IjCLi);
	}
	function doLogging($_IQtQL,$_QoQot,$_Q8J1f) {
		global $CFG;
		if ($CFG->turnitin_enablediagnostic) {
			$_Ijio1=10;
			$_IjL1O="commslog_";
			$_IjL6C=$CFG->dataroot."/temp/turnitintool/logs/";
			if (!is_dir($_IjL6C)) {
				mkdir($_IjL6C,NULL,true);
			}
			$_IjLft=opendir($_IjL6C);
			$_IjLOI=array();
			while ($_Ijl0l=readdir($_IjLft)) {
				if (substr(basename($_Ijl0l),0,1)!="." AND substr_count(basename($_Ijl0l),$_IjL1O)>0) {
					$_IjLOI[]=basename($_Ijl0l);
				}
			}
			sort($_IjLOI);
			for ($_Q8ILi=0;$_Q8ILi<count($_IjLOI)-$_Ijio1;$_Q8ILi++) {
				unlink($_IjL6C.$_IjLOI[$_Q8ILi]);
			}
			$_I0olf=$_IjL6C.$_IjL1O.date('Ymd',time()).".log";
			$file=fopen($_I0olf,'a');
			if (!isset($_QoQot["fid"])) {
				$_QoQot["fid"]="N/A";
			}
			if (!isset($_QoQot["fcmd"])) {
				$_QoQot["fcmd"]="N/A";
			}
			$_QOO18="== FID:".$_QoQot["fid"]." | FCMD:".$_QoQot["fcmd"]." ===========================================================\n";
			$_Q8Jii=$this->getRcode($_Q8J1f);
			if ($_Q8Jii<100 AND !is_null($_Q8Jii)) {
				$_QOO18.="== SUCCESS ===================================================================\n";
			} else {
				$_QOO18.="== ERROR =====================================================================\n";
			}
			$_QOO18.="CALL DATE TIME: ".date('r',time())."\n";
			$_QOO18.="URL: ".$_IQtQL."\n";
			$_QOO18.="------------------------------------------------------------------------------\n";
			$_QOO18.="REQUEST VARS: \n".print_r($_QoQot,true)."\n";
			$_QOO18.="------------------------------------------------------------------------------\n";
			$_QOO18.="RESPONSE: \n".$_Q8J1f."\n";
			$_QOO18.="##############################################################################\n\n";
			fwrite($file,$_QOO18);
			fclose($file);
		}
	}
	function framesCheck($_IQtQL) {
		$_QLiJL=$this->doRequest('GET',$_IQtQL,NULL,false);
		preg_match("'<frameset[^>]*?>.*?</frameset>'si",$_QLiJL,$_IJ008);
		preg_match("'<iframe[^>]*?>.*?</iframe>'si",$_QLiJL,$_IJ086);
		if (count($_IJ008)>0) {
			return "FRAMESET";
		} else if (count($_IJ086)>0) {
			return "IFRAME";
		} else {
			return NULL;
		}
	}
	function grabHTML($_IQtQL) {
		$_QLiJL=$this->doRequest('GET',$_IQtQL,NULL,false,1,1,get_string('urlsnapshot','turnitintool'));
		$_QLiJL=preg_replace("'<script[^>]*?>.*?</script>'si",'',$_QLiJL); 
		$_IJ0Cl = array(	'/(onabort=").*?(")/si',"/(onabort=').*?(')/si",
							'/(onblur=").*?(")/si',"/(onblur=').*?(')/si",
							'/(onclick=").*?(")/si',"/(onclick=').*?(')/si",
							'/(ondblclick=").*?(")/si',"/(ondblclick=').*?(')/si",
							'/(onerror=").*?(")/si',"/(onerror=').*?(')/si",
							'/(onfocus=").*?(")/si',"/(onfocus=').*?(')/si",
							'/(onkeydown=").*?(")/si',"/(onkeydown=').*?(')/si",
							'/(onkeypress=").*?(")/si',"/(onkeypress=').*?(')/si",
							'/(onkeyup=").*?(")/si',"/(onkeyup=').*?(')/si",
							'/(onload=").*?(")/si',"/(onload=').*?(')/si",
							'/(onmousedown=").*?(")/si',"/(onmousedown=').*?(')/si",
							'/(onmousemove=").*?(")/si',"/(onmousemove=').*?(')/si",
							'/(onmouseout=").*?(")/si',"/(onmouseout=').*?(')/si",
							'/(onmouseover=").*?(")/si',"/(onmouseover=').*?(')/si",
							'/(onmouseup=").*?(")/si',"/(onmouseup=').*?(')/si",
							'/(onreset=").*?(")/si',"/(onreset=').*?(')/si",
							'/(onresize=").*?(")/si',"/(onresize=').*?(')/si",
							'/(onselect=").*?(")/si',"/(onselect=').*?(')/si",
							'/(onsubmit=").*?(")/si',"/(onsubmit=').*?(')/si",
							'/(onunload=").*?(")/si',"/(onunload=').*?(')/si"
						);
		$_QLiJL=preg_replace($_IJ0Cl,'',$_QLiJL); 
		$_QLiJL=preg_replace('/(src=")(.*)(")/eisxmU','"\\1".$this->rel2absolute($_IQtQL,"$2")."\\3"',$_QLiJL); 
		$_QLiJL=preg_replace('/(href=")(.*)(")/eisxmU','"\\1".$this->rel2absolute($_IQtQL,"$2")."\\3"',$_QLiJL); 
		$_QLiJL=preg_replace('/(action=")(.*)(")/eisxmU','"\\1".$this->rel2absolute($_IQtQL,"$2")."\\3"',$_QLiJL); 
		$_QLiJL=preg_replace('/(@import\s*")(.*)(")/eisxmU','"\\1".$this->rel2absolute($_IQtQL,"$2")."\\3"',$_QLiJL); 
		$_QLiJL=preg_replace('/(@import\s*url()(.*)())/eisxmU','"\\1".$this->rel2absolute($_IQtQL,"$2")."\\3"',$_QLiJL); 
		$_QLiJL=preg_replace("/(src=')(.*)(')/eisxmU",'"\\1".$this->rel2absolute($_IQtQL,"$2")."\\3"',$_QLiJL); 
		$_QLiJL=preg_replace("/(href=')(.*)(')/eisxmU",'"\\1".$this->rel2absolute($_IQtQL,"$2")."\\3"',$_QLiJL); 
		$_QLiJL=preg_replace("/(action=')(.*)(')/eisxmU",'"\\1".$this->rel2absolute($_IQtQL,"$2")."\\3"',$_QLiJL); 
		$_QLiJL=preg_replace("/(src=)(.*)(>)/eisxmU",'"\\1".$this->rel2absolute($_IQtQL,"$2")."\\3"',$_QLiJL); 
		$_QLiJL=preg_replace("/(href=)(.*)(>)/eisxmU",'"\\1".$this->rel2absolute($_IQtQL,"$2")."\\3"',$_QLiJL); 
		$_QLiJL=preg_replace("/(action=)(.*)(>)/eisxmU",'"\\1".$this->rel2absolute($_IQtQL,"$2")."\\3"',$_QLiJL); 
		$_QLiJL=preg_replace("/(@import\s*')(.*)(')/eisxmU",'"\\1".$this->rel2absolute($_IQtQL,"$2")."\\3"',$_QLiJL); 
		$_QLiJL.='<div style="font-size: small;text-align: center;position: absolute;width: 100%;opacity: 65;filter:alpha(opacity=65);top: 0; left: 0;z-index: 1000;border-width: 0px 0px 1px 0px;border-style: solid;border-color: white;margin: 0px auto 10px auto;padding: 4px 0px;background-color: black;color: white;">Snapshot from URL: '.$_IQtQL.' on '.date('r',time()).'</div>';
		return $_QLiJL;
	}
	function rel2absolute($_IQtQL,$_IJ1t1) {
		$_IJQ1J=parse_url($_IQtQL);
		$_IJQoi = $_IJQ1J["scheme"];
		$_IJIjC = $_IJQ1J["host"];
		if (isset($_IJQ1J["path"])) {
			$_IJIJC = basename($_IJQ1J["path"]);
			$_IjLft = dirname($_IJQ1J["path"]);
		} else {
			$_IJIJC='';
			$_IjLft='';
		}
		$_IJjjQ="";
		if (substr($_IJ1t1,0,1)=="/") {
			$_IJjjQ=$_IJQoi."://".$_IJIjC.$_IJ1t1;
		} else if (substr($_IJ1t1,0,2)=="..") {
			$_IJjj8=explode("/",$_IjLft);
			$_IJjC6=substr_count($_IJ1t1,"../");
			$_IJjC8=substr_count($_IjLft,"/");
			$_IJJoI=$_IJjC8-$_IJjC6;
			$_IJJoj='';
			for ($_Q8ILi=0;$_Q8ILi<$_IJJoI;$_Q8ILi++) {
				$_IJJoj.='/'.$_IJjj8[$_Q8ILi];
			}
			$_IJJoj.='/';
			$_IJjjQ=$_IJQoi."://".$_IJIjC.$_IJJoj.str_replace('../','',$_IJ1t1);
		} else if (substr_count($_IJ1t1,"http://")>0 OR substr_count($_IJ1t1,"https://")>0) {
			$_IJjjQ=$_IJ1t1;
		} else {
			$_IJjjQ=$_IJQoi."://".$_IJIjC."/".$_IJ1t1;
		}
		return $_IJjjQ;
	}
	function number2Alpha($_IJ611) {
		$_QOO18='';
        while($_IJ611 >= 1) {
            $_IJ611=$_IJ611-1;
            $_QOO18 = chr(($_IJ611 % 26)+65).$_QOO18;
            $_IJ611 = $_IJ611 / 26;
        }
        return strtolower($_QOO18);
    }
	function deleteAssignment($post,$owner,$_Q8I6l=1,$_QflLo=1,$_QO88j='',$_QOO18=true) {
		global $CFG;
		if (!turnitintool_check_config()) {
			turnitintool_print_error('configureerror','turnitintool',NULL,__FILE__,__LINE__);
			exit();
		}
		$_IJ6lJ=array('gmtime'=>$this->tiiGmtime(),
						 'encrypt'=>TII_ENCRYPT,
						 'aid'=>$CFG->turnitin_account_id,
						 'diagnostic'=>0,
						 'fcmd'=>6,
						 'cid'=>$post->cid,
						 'ctl'=>stripslashes($post->ctl),
						 'assignid'=>$post->assignid,
						 'assign'=>stripslashes($post->name),
						 'utp'=>2,
						 'fid'=>4,
						 'uid'=>$post->uid,
						 'uem'=>$owner->email,
						 'ufn'=>$owner->firstname,
						 'uln'=>$owner->lastname
						);
		$_IJfJ1=$CFG->turnitin_subaccount_id;
		if (!empty($_IJfJ1)) {
			$_IJ6lJ['said']=$_IJfJ1;
		}
		$_IJ6lJ["md5"]=$this->doMD5($_IJ6lJ);
		return $this->doRequest("POST", $CFG->turnitin_apiurl, $_IJ6lJ,true,$_Q8I6l,$_QflLo,$_QO88j,$_QOO18);
	}
	function createAssignment($post,$do='INSERT',$owner,$_Q8I6l=1,$_QflLo=1,$_QO88j='',$_QOO18=true) { 
		global $CFG;
		if (!turnitintool_check_config()) {
			turnitintool_print_error('configureerror','turnitintool',NULL,__FILE__,__LINE__);
			exit();
		}
		if ($do!='INSERT') {
			$_IJfJl=3;
		} else {
			$_IJfJl=2;
		}
		$_IJ6lJ=array('gmtime'=>$this->tiiGmtime(),
						 'encrypt'=>TII_ENCRYPT,
						 'aid'=>$CFG->turnitin_account_id,
						 'diagnostic'=>0,
						 'fcmd'=>$_IJfJl,
						 'cid'=>$post->cid,
						 'ctl'=>stripslashes($post->ctl),
						 'assignid'=>$post->assignid,
						 'utp'=>2,
						 'dtstart'=>date('Y-m-d H:i:s',$post->dtstart),
						 'dtdue'=>date('Y-m-d H:i:s',$post->dtdue),
						 'dtpost'=>date('Y-m-d H:i:s',$post->dtpost),
						 'fid'=>4,
						 'uid'=>$post->uid,
						 'uem'=>$owner->email,
						 'ufn'=>$owner->firstname,
						 'uln'=>$owner->lastname
						);
		$_IJfJ1=$CFG->turnitin_subaccount_id;
		if (!empty($_IJfJ1)) {
			$_IJ6lJ['said']=$_IJfJ1;
		}
		if ($do!='INSERT') {
			$_IJ6lJ['newassign']=stripslashes($post->name);
			$_IJ6lJ['assign']=stripslashes($post->currentassign);
		} else {
			$_IJ6lJ['assign']=stripslashes($post->name);
		}
		$_IJ6lJ["md5"]=$this->doMD5($_IJ6lJ);
		$_IJ6lJ["s_view_report"]=$post->s_view_report;
		if (isset($post->max_points)) {
			$_IJ6lJ["max_points"]=$post->max_points;
		}
		if (isset($post->report_gen_speed)) {
			$_IJ6lJ["report_gen_speed"]=$post->report_gen_speed;
		}
		if (isset($post->anon)) {
			$_IJ6lJ["anon"]=$post->anon;
		}
		if (isset($post->late_accept_flag)) {
			$_IJ6lJ["late_accept_flag"]=$post->late_accept_flag;
		}
		if (isset($post->submit_papers_to)) {
			$_IJ6lJ["submit_papers_to"]=$post->submit_papers_to;
		}
		if (isset($post->s_paper_check)) {
			$_IJ6lJ["s_paper_check"]=$post->s_paper_check;
		}
		if (isset($post->internet_check)) {
			$_IJ6lJ["internet_check"]=$post->internet_check;
		}
		if (isset($post->journal_check)) {
			$_IJ6lJ["journal_check"]=$post->journal_check;
		}
		if (isset($post->idsync)) {
			$_IJ6lJ['idsync']=$post->idsync;
		}
		return $this->doRequest("POST", $CFG->turnitin_apiurl, $_IJ6lJ,true,$_Q8I6l,$_QflLo,$_QO88j,$_QOO18);
	}
	function changeOwner($post,$_Q8I6l=1,$_QflLo=1,$_QO88j='',$_QOO18=true) {
		global $CFG;
		$_IJ6lJ=array('gmtime'=>$this->tiiGmtime(),
						 'encrypt'=>TII_ENCRYPT,
						 'aid'=>$CFG->turnitin_account_id,
						 'diagnostic'=>0,
						 'fcmd'=>4,
						 'cid'=>$post->cid,
						 'ctl'=>stripslashes($post->ctl),
						 'tem'=>$post->email,
						 'utp'=>2,
						 'fid'=>2,
						 'uid'=>$post->uid,
						 'uem'=>$post->email,
						 'ufn'=>$post->firstname,
						 'uln'=>$post->lastname
						);
		$_IJfJ1=$CFG->turnitin_subaccount_id;
		if (!empty($_IJfJ1)) {
			$_IJ6lJ['said']=$_IJfJ1;
		}
		$_IJ6lJ['md5']=$this->doMD5($_IJ6lJ);
		$_IJ6lJ['new_teacher_email']=$post->new_teacher_email;
		return $this->doRequest("POST", $CFG->turnitin_apiurl, $_IJ6lJ,false,$_Q8I6l,$_QflLo,$_QO88j,$_QOO18);
	}
	function submitPaper($post,$_I0olf,$_Q8I6l=1,$_QflLo=1,$_QO88j='',$_QOO18=true) {
		global $CFG;
		$_IJ6lJ=array('gmtime'=>$this->tiiGmtime(),
						 'encrypt'=>TII_ENCRYPT,
						 'aid'=>$CFG->turnitin_account_id,
						 'diagnostic'=>0,
						 'fcmd'=>2,
						 'cid'=>$post->cid,
						 'ctl'=>stripslashes($post->ctl),
						 'assignid'=>$post->assignid,
						 'assign'=>stripslashes($post->assignname),
						 'tem'=>$post->tem,
						 'ptype'=>2,
						 'ptl'=>stripslashes($post->papertitle),
						 'utp'=>1,
						 'fid'=>5,
						 'uid'=>$post->uid,
						 'uem'=>$post->email,
						 'ufn'=>$post->firstname,
						 'uln'=>$post->lastname
						);
		$_IJfJ1=$CFG->turnitin_subaccount_id;
		if (!empty($_IJfJ1)) {
			$_IJ6lJ['said']=$_IJfJ1;
		}
		$_IJ6lJ['md5']=$this->doMD5($_IJ6lJ);
		$_IJ6lJ['pdata']='@'.$_I0olf;
		return $this->doRequest("POST", $CFG->turnitin_apiurl, $_IJ6lJ,false,$_Q8I6l,$_QflLo,$_QO88j,$_QOO18);
	}
	function queryAssignment($post,$_Q8I6l=1,$_QflLo=1,$_QO88j='',$_QOO18=true) {
		global $CFG;
		$_IJ6lJ=array('gmtime'=>$this->tiiGmtime(),
						 'encrypt'=>TII_ENCRYPT,
						 'aid'=>$CFG->turnitin_account_id,
						 'diagnostic'=>0,
						 'fcmd'=>7,
						 'cid'=>$post->cid,
						 'ctl'=>stripslashes($post->ctl),
						 'assignid'=>$post->assignid,
						 'assign'=>stripslashes($post->assign),
						 'utp'=>2,
						 'fid'=>4,
						 'uid'=>$post->uid,
						 'uem'=>$post->uem,
						 'ufn'=>$post->ufn,
						 'uln'=>$post->uln
						);
		$_IJfJ1=$CFG->turnitin_subaccount_id;
		if (!empty($_IJfJ1)) {
			$_IJ6lJ['said']=$_IJfJ1;
		}
		$_IJ6lJ['md5']=$this->doMD5($_IJ6lJ);
		return $this->doRequest("POST", $CFG->turnitin_apiurl, $_IJ6lJ,false,$_Q8I6l,$_QflLo,$_QO88j,$_QOO18);
	}
	function getAssignmentObject($_IQtII) {
		$_QOO18=new object();
		$_IjJL8=$this->xmlToArray($_IQtII);
		if (isset($this->_xmlkeys['ASSIGN']) AND is_array($this->_xmlkeys['ASSIGN'])) {
	        for ($_Q8ILi=0;$_Q8ILi<count($this->_xmlkeys['ASSIGN']);$_Q8ILi++) {
				$_IjJlL = $this->_xmlkeys['ASSIGN'][$_Q8ILi];
				$_Ij6Lf = $this->_xmlkeys['DTSTART'][$_Q8ILi];
				$_Ijfto = $this->_xmlkeys['DTDUE'][$_Q8ILi];
				$_Ij8Ij = $this->_xmlkeys['DTPOST'][$_Q8ILi];
				$_Ij8iQ = $this->_xmlkeys['AINST'][$_Q8ILi];
				$_Ij8lQ = $this->_xmlkeys['GENERATE'][$_Q8ILi];
				$_Ijt1J = $this->_xmlkeys['SVIEWREPORTS'][$_Q8ILi];
				$_Ijt6I = $this->_xmlkeys['LATESUBMISSIONS'][$_Q8ILi];
				$_Ijt86 = $this->_xmlkeys['REPOSITORY'][$_Q8ILi];
				$_IjOJI = $this->_xmlkeys['SEARCHPAPERS'][$_Q8ILi];
				$_IjojJ = $this->_xmlkeys['SEARCHINTERNET'][$_Q8ILi];
				$_IJ8QO = $this->_xmlkeys['SEARCHJOURNALS'][$_Q8ILi];
				$_IJ868 = $this->_xmlkeys['ANON'][$_Q8ILi];
				$_IJt1j = $this->_xmlkeys['MAXPOINTS'][$_Q8ILi];
				$_QOO18->assign = $this->_xmlvalues[$_IjJlL]['value'];
				$_QOO18->dtstart = strtotime($this->_xmlvalues[$_Ij6Lf]['value']);
				$_QOO18->dtdue = strtotime($this->_xmlvalues[$_Ijfto]['value']);
				$_QOO18->dtpost = strtotime($this->_xmlvalues[$_Ij8Ij]['value']);
				if (isset($this->_xmlvalues[$_Ij8iQ]['value'])) {
					$_QOO18->ainst = $this->_xmlvalues[$_Ij8iQ]['value'];
				} else {
					$_QOO18->ainst = NULL;
				}
				$_QOO18->report_gen_speed = $this->_xmlvalues[$_Ij8lQ]['value'];
				$_QOO18->s_view_report = $this->_xmlvalues[$_Ijt1J]['value'];
				$_QOO18->late_accept_flag = $this->_xmlvalues[$_Ijt6I]['value'];
				$_QOO18->submit_papers_to = $this->_xmlvalues[$_Ijt86]['value'];
				$_QOO18->s_paper_check = $this->_xmlvalues[$_IjOJI]['value'];
				$_QOO18->internet_check = $this->_xmlvalues[$_IjojJ]['value'];
				$_QOO18->journal_check = $this->_xmlvalues[$_IJ8QO]['value'];
				$_QOO18->anon = $this->_xmlvalues[$_IJ868]['value'];
				$_QOO18->maxpoints = $this->_xmlvalues[$_IJt1j]['value'];
			}
			return $_QOO18;
		} else {
			return $_QOO18;
		}
	}
	function joinClass($post,$user=NULL,$_Q8I6l=1,$_QflLo=1,$_QO88j='',$_QOO18=true) {
		global $USER,$CFG;
		if (is_null($user)) {
			$_Qo6lJ=$USER;
		} else {
			$_Qo6lJ=$user;
		}
		$_IJ6lJ=array('gmtime'=>$this->tiiGmtime(),
						 'encrypt'=>TII_ENCRYPT,
						 'aid'=>$CFG->turnitin_account_id,
						 'diagnostic'=>0,
						 'fcmd'=>2,
						 'cid'=>$post->cid,
						 'ctl'=>stripslashes($post->ctl),
						 'tem'=>stripslashes($post->tem),
						 'utp'=>1,
						 'fid'=>3,
						 'uid'=>$post->uid,
						 'uem'=>$_Qo6lJ->email,
						 'ufn'=>$_Qo6lJ->firstname,
						 'uln'=>$_Qo6lJ->lastname
						);
		$_IJfJ1=$CFG->turnitin_subaccount_id;
		if (!empty($_IJfJ1)) {
			$_IJ6lJ['said']=$_IJfJ1;
		}
		$_IJ6lJ['md5']=$this->doMD5($_IJ6lJ);
		return $this->doRequest("POST", $CFG->turnitin_apiurl, $_IJ6lJ,true,$_Q8I6l,$_QflLo,$_QO88j,$_QOO18);
	}
	function createUser($post,$user=NULL,$_Q8I6l=1,$_QflLo=1,$_QO88j='',$_QOO18=true) {
		global $USER,$CFG;
		if (is_null($user)) {
			$_Qo6lJ=$USER;
		} else {
			$_Qo6lJ=$user;
		}
		if (!isset($post->uid)) $post->uid="";
		if (!isset($post->cid)) $post->cid="";
		$_IJ6lJ=array('gmtime'=>$this->tiiGmtime(),
						 'encrypt'=>TII_ENCRYPT,
						 'aid'=>$CFG->turnitin_account_id,
						 'diagnostic'=>0,
						 'fcmd'=>2,
						 'utp'=>$post->utp,
						 'fid'=>1,
						 'uid'=>$post->uid,
						 'uem'=>$_Qo6lJ->email,
						 'ufn'=>$_Qo6lJ->firstname,
						 'uln'=>$_Qo6lJ->lastname
						);
		$_IJfJ1=$CFG->turnitin_subaccount_id;
		if (!empty($_IJfJ1)) {
			$_IJ6lJ['said']=$_IJfJ1;
		}
		if (isset($post->dis) AND $post->dis==1) {
			$_IJ6lJ['dis']=1;
		} else {
			$_IJ6lJ['dis']=0;
		}
		$_IJ6lJ['md5']=$this->doMD5($_IJ6lJ);
		if (isset($post->idsync)) {
			$_IJ6lJ['idsync']=$post->idsync;
		}
		return $this->doRequest("POST", $CFG->turnitin_apiurl, $_IJ6lJ,true,$_Q8I6l,$_QflLo,$_QO88j,$_QOO18);
	}
	function createClass($post,$user=NULL,$_Q8I6l=1,$_QflLo=1,$_QO88j='',$_QOO18=true) {
		global $USER,$CFG;
		if (is_null($user)) {
			$_Qo6lJ=$USER;
		} else {
			$_Qo6lJ=$user;
		}
		if (!isset($post->cid)) {
			$post->cid="";
			$post->uid="";
		} else {
			$post->uid=turnitintool_getUID($_Qo6lJ);
		}
		$_IJ6lJ=array('gmtime'=>$this->tiiGmtime(),
						 'encrypt'=>TII_ENCRYPT,
						 'aid'=>$CFG->turnitin_account_id,
						 'diagnostic'=>0,
						 'fcmd'=>2,
						 'utp'=>2,
						 'fid'=>2,
						 'cid'=>$post->cid,
						 'ctl'=>stripslashes($post->ctl),
						 'uid'=>$post->uid,
						 'uem'=>$_Qo6lJ->email,
						 'ufn'=>$_Qo6lJ->firstname,
						 'uln'=>$_Qo6lJ->lastname
						);
		$_IJfJ1=$CFG->turnitin_subaccount_id;
		if (!empty($_IJfJ1)) {
			$_IJ6lJ['said']=$_IJfJ1;
		}
		$_IJ6lJ['md5']=$this->doMD5($_IJ6lJ);
		if (isset($post->idsync)) {
			$_IJ6lJ['idsync']=$post->idsync;
		}
		return $this->doRequest("POST", $CFG->turnitin_apiurl, $_IJ6lJ,true,$_Q8I6l,$_QflLo,$_QO88j,$_QOO18);
	}
	function getReportScore($post,$_Qo6lJ,$_Q8I6l=1,$_QflLo=1,$_QO88j='',$_QOO18=true) {
		global $CFG;
		if (!turnitintool_check_config()) {
			turnitintool_print_error('configureerror','turnitintool',NULL,__FILE__,__LINE__);
			exit();
		}
		$_IJ6lJ=array('gmtime'=>$this->tiiGmtime(),
						 'encrypt'=>TII_ENCRYPT,
						 'aid'=>$CFG->turnitin_account_id,
						 'diagnostic'=>0,
						 'fcmd'=>2,
						 'oid'=>$post->paperid,
						 'utp'=>$post->utp,
						 'fid'=>6,
						 'uid'=>$post->uid,
						 'uem'=>$_Qo6lJ->email,
						 'ufn'=>$_Qo6lJ->firstname,
						 'uln'=>$_Qo6lJ->lastname
						);
		$_IJfJ1=$CFG->turnitin_subaccount_id;
		if (!empty($_IJfJ1)) {
			$_IJ6lJ['said']=$_IJfJ1;
		}
		$_IJ6lJ["md5"]=$this->doMD5($_IJ6lJ);
		return $this->doRequest("POST", $CFG->turnitin_apiurl, $_IJ6lJ,true,$_Q8I6l,$_QflLo,$_QO88j,$_QOO18);
	}
	function listSubmissions($post,$_Qo6lJ,$_Q8I6l=1,$_QflLo=1,$_QO88j='',$_QOO18=true) {
		global $CFG;
		if (!turnitintool_check_config()) {
			turnitintool_print_error('configureerror','turnitintool',NULL,__FILE__,__LINE__);
			exit();
		}
		$_IJ6lJ=array('gmtime'=>$this->tiiGmtime(),
						 'encrypt'=>TII_ENCRYPT,
						 'aid'=>$CFG->turnitin_account_id,
						 'diagnostic'=>0,
						 'fcmd'=>2,
						 'assignid'=>$post->assignid,
						 'assign'=>$post->assign,
						 'cid'=>$post->cid,
						 'ctl'=>$post->ctl,
						 'tem'=>$post->tem,
						 'utp'=>$post->utp,
						 'fid'=>10,
						 'uid'=>$post->uid,
						 'uem'=>$_Qo6lJ->email,
						 'ufn'=>$_Qo6lJ->firstname,
						 'uln'=>$_Qo6lJ->lastname
						);
		$_IJfJ1=$CFG->turnitin_subaccount_id;
		if (!empty($_IJfJ1)) {
			$_IJ6lJ['said']=$_IJfJ1;
		}
		$_IJ6lJ["md5"]=$this->doMD5($_IJ6lJ);
		return $this->doRequest("POST", $CFG->turnitin_apiurl, $_IJ6lJ,true,$_Q8I6l,$_QflLo,$_QO88j,$_QOO18);
	}
	function getReportLink($post,$_Qo6lJ) {
		global $CFG;
		$_IJ6lJ=array('gmtime'=>$this->tiiGmtime(),
						 'encrypt'=>TII_ENCRYPT,
						 'aid'=>$CFG->turnitin_account_id,
						 'diagnostic'=>0,
						 'fcmd'=>1,
						 'oid'=>$post->paperid,
						 'utp'=>$post->utp,
						 'fid'=>6,
						 'uid'=>$post->uid,
						 'uem'=>$_Qo6lJ->email,
						 'ufn'=>$_Qo6lJ->firstname,
						 'uln'=>$_Qo6lJ->lastname
						);
		$_IJfJ1=$CFG->turnitin_subaccount_id;
		if (!empty($_IJfJ1)) {
			$_IJ6lJ['said']=$_IJfJ1;
		}
		$_IJ6lJ['md5']=$this->doMD5($_IJ6lJ);
		$_I1iQl = array_keys($_IJ6lJ);
  		$_QL0tj = array_values($_IJ6lJ);
		$_IJtjI='';
  		for ($_Q8ILi=0;$_Q8ILi<count($_QL0tj); $_Q8ILi++) {
    		if ($_Q8ILi!=0) {
				$_IJtjI .= '&';
  			}
			$_IJtjI .= $_I1iQl[$_Q8ILi].'='.urlencode($_QL0tj[$_Q8ILi]);
		}
		return $CFG->turnitin_apiurl."?".$_IJtjI;
	}
	function setGradeMark($post,$owner,$_Q8I6l=1,$_QflLo=1,$_QO88j='',$_QOO18=true) {
		global $CFG;
		if (!turnitintool_check_config()) {
			turnitintool_print_error('configureerror','turnitintool',NULL,__FILE__,__LINE__);
			exit();
		}
		$_IJ6lJ=array('gmtime'=>$this->tiiGmtime(),
						 'encrypt'=>TII_ENCRYPT,
						 'aid'=>$CFG->turnitin_account_id,
						 'diagnostic'=>0,
						 'fcmd'=>3,
						 'cid'=>$post->cid,
						 'oid'=>$post->oid,
						 'utp'=>2,
						 'fid'=>15,
						 'uid'=>$post->uid,
						 'uem'=>$owner->email,
						 'ufn'=>$owner->firstname,
						 'uln'=>$owner->lastname
						);
		$_IJfJ1=$CFG->turnitin_subaccount_id;
		if (!empty($_IJfJ1)) {
			$_IJ6lJ['said']=$_IJfJ1;
		}
		$_IJ6lJ["md5"]=$this->doMD5($_IJ6lJ);
		$_IJ6lJ["score"]=$post->score;
		return $this->doRequest("POST", $CFG->turnitin_apiurl, $_IJ6lJ,true,$_Q8I6l,$_QflLo,$_QO88j,$_QOO18);
	}
	function getGradeMarkLink($post,$_Qo6lJ) {
		global $CFG;
		$_IJ6lJ=array('gmtime'=>$this->tiiGmtime(),
						 'encrypt'=>TII_ENCRYPT,
						 'aid'=>$CFG->turnitin_account_id,
						 'diagnostic'=>0,
						 'fcmd'=>1,
						 'oid'=>$post->paperid,
						 'utp'=>$post->utp,
						 'fid'=>13,
						 'uid'=>$post->uid,
						 'uem'=>$_Qo6lJ->email,
						 'ufn'=>$_Qo6lJ->firstname,
						 'uln'=>$_Qo6lJ->lastname
						);
		$_IJfJ1=$CFG->turnitin_subaccount_id;
		if (!empty($_IJfJ1)) {
			$_IJ6lJ['said']=$_IJfJ1;
		}
		$_IJ6lJ['md5']=$this->doMD5($_IJ6lJ);
		$_I1iQl = array_keys($_IJ6lJ);
  		$_QL0tj = array_values($_IJ6lJ);
		$_IJtjI='';
  		for ($_Q8ILi=0;$_Q8ILi<count($_QL0tj); $_Q8ILi++) {
    		if ($_Q8ILi!=0) {
				$_IJtjI .= '&';
  			}
			$_IJtjI .= $_I1iQl[$_Q8ILi].'='.urlencode($_QL0tj[$_Q8ILi]);
		}
		return $CFG->turnitin_apiurl."?".$_IJtjI;
	}
	function getSubmissionURL($post,$_Qo6lJ) {
		global $CFG;
		$_IJ6lJ=array('gmtime'=>$this->tiiGmtime(),
						 'encrypt'=>TII_ENCRYPT,
						 'aid'=>$CFG->turnitin_account_id,
						 'diagnostic'=>0,
						 'fcmd'=>1,
						 'oid'=>$post->paperid,
						 'utp'=>$post->utp,
						 'fid'=>7,
						 'assignid'=>$post->assignid,
						 'assign'=>$post->assign,
						 'ctl'=>$post->ctl,
						 'cid'=>$post->cid,
						 'uid'=>$post->uid,
						 'tem'=>$post->tem,
						 'uem'=>$_Qo6lJ->email,
						 'ufn'=>$_Qo6lJ->firstname,
						 'uln'=>$_Qo6lJ->lastname
						);
		$_IJfJ1=$CFG->turnitin_subaccount_id;
		if (!empty($_IJfJ1)) {
			$_IJ6lJ['said']=$_IJfJ1;
		}
		$_IJ6lJ['md5']=$this->doMD5($_IJ6lJ);
		$_I1iQl = array_keys($_IJ6lJ);
  		$_QL0tj = array_values($_IJ6lJ);
		$_IJtjI='';
  		for ($_Q8ILi=0;$_Q8ILi<count($_QL0tj); $_Q8ILi++) {
    		if ($_Q8ILi!=0) {
				$_IJtjI .= '&';
  			}
			$_IJtjI .= $_I1iQl[$_Q8ILi].'='.urlencode($_QL0tj[$_Q8ILi]);
		}
		return $CFG->turnitin_apiurl."?".$_IJtjI;
	}
	function getSubmissionDownload($post,$_Qo6lJ) {
		global $CFG;
		$_IJ6lJ=array('gmtime'=>$this->tiiGmtime(),
						 'encrypt'=>TII_ENCRYPT,
						 'aid'=>$CFG->turnitin_account_id,
						 'diagnostic'=>0,
						 'fcmd'=>2,
						 'oid'=>$post->paperid,
						 'utp'=>$post->utp,
						 'fid'=>7,
						 'assignid'=>$post->assignid,
						 'assign'=>$post->assign,
						 'ctl'=>$post->ctl,
						 'cid'=>$post->cid,
						 'uid'=>$post->uid,
						 'tem'=>$post->tem,
						 'uem'=>$_Qo6lJ->email,
						 'ufn'=>$_Qo6lJ->firstname,
						 'uln'=>$_Qo6lJ->lastname
						);
		$_IJfJ1=$CFG->turnitin_subaccount_id;
		if (!empty($_IJfJ1)) {
			$_IJ6lJ['said']=$_IJfJ1;
		}
		$_IJ6lJ['md5']=$this->doMD5($_IJ6lJ);
		$_I1iQl = array_keys($_IJ6lJ);
  		$_QL0tj = array_values($_IJ6lJ);
		$_IJtjI='';
  		for ($_Q8ILi=0;$_Q8ILi<count($_QL0tj); $_Q8ILi++) {
    		if ($_Q8ILi!=0) {
				$_IJtjI .= '&';
  			}
			$_IJtjI .= $_I1iQl[$_Q8ILi].'='.urlencode($_QL0tj[$_Q8ILi]);
		}
		return $CFG->turnitin_apiurl."?".$_IJtjI;
	}
	function deleteSubmission($post,$_Qo6lJ,$_Q8I6l=1,$_QflLo=1,$_QO88j='',$_QOO18=true) {
		global $CFG;
		$_IJ6lJ=array('gmtime'=>$this->tiiGmtime(),
						 'encrypt'=>TII_ENCRYPT,
						 'aid'=>$CFG->turnitin_account_id,
						 'diagnostic'=>0,
						 'fcmd'=>2,
						 'oid'=>$post->paperid,
						 'utp'=>$post->utp,
						 'fid'=>8,
						 'uid'=>$post->uid,
						 'uem'=>$_Qo6lJ->email,
						 'ufn'=>$_Qo6lJ->firstname,
						 'uln'=>$_Qo6lJ->lastname
						);
		$_IJfJ1=$CFG->turnitin_subaccount_id;
		if (!empty($_IJfJ1)) {
			$_IJ6lJ['said']=$_IJfJ1;
		}
		$_IJ6lJ['md5']=$this->doMD5($_IJ6lJ);
		return $this->doRequest("POST", $CFG->turnitin_apiurl, $_IJ6lJ,true,$_Q8I6l,$_QflLo,$_QO88j,$_QOO18);
	}
	function revealAnon($post,$_Qo6lJ,$_Q8I6l=1,$_QflLo=1,$_QO88j='',$_QOO18=true) {
		global $CFG;
		$_IJ6lJ=array('gmtime'=>$this->tiiGmtime(),
						 'encrypt'=>TII_ENCRYPT,
						 'aid'=>$CFG->turnitin_account_id,
						 'diagnostic'=>0,
						 'fcmd'=>3,
						 'oid'=>$post->paperid,
						 'utp'=>$post->utp,
						 'fid'=>16,
						 'uid'=>$post->uid,
						 'uem'=>$_Qo6lJ->email,
						 'ufn'=>$_Qo6lJ->firstname,
						 'uln'=>$_Qo6lJ->lastname
						);
		$_IJfJ1=$CFG->turnitin_subaccount_id;
		if (!empty($_IJfJ1)) {
			$_IJ6lJ['said']=$_IJfJ1;
		}
		$_IJ6lJ['md5']=$this->doMD5($_IJ6lJ);
		$_IJ6lJ['anon_reason']=$post->anon_reason;
		return $this->doRequest("POST", $CFG->turnitin_apiurl, $_IJ6lJ,true,$_Q8I6l,$_QflLo,$_QO88j,$_QOO18);
	}
	function pushGrade($post,$_Qo6lJ,$_Q8I6l=1,$_QflLo=1,$_QO88j='',$_QOO18=true) {
		global $CFG;
		$_IJ6lJ=array('gmtime'=>$this->tiiGmtime(),
						 'encrypt'=>TII_ENCRYPT,
						 'aid'=>$CFG->turnitin_account_id,
						 'diagnostic'=>0,
						 'fcmd'=>3,
						 'oid'=>$post->paperid,
						 'utp'=>$post->utp,
						 'fid'=>15,
						 'uid'=>$post->uid,
						 'uem'=>$_Qo6lJ->email,
						 'ufn'=>$_Qo6lJ->firstname,
						 'uln'=>$_Qo6lJ->lastname
						);
		$_IJfJ1=$CFG->turnitin_subaccount_id;
		if (!empty($_IJfJ1)) {
			$_IJ6lJ['said']=$_IJfJ1;
		}
		$_IJ6lJ['md5']=$this->doMD5($_IJ6lJ);
		$_IJ6lJ['score']=$post->score;
		return $this->doRequest("POST", $CFG->turnitin_apiurl, $_IJ6lJ,true,$_Q8I6l,$_QflLo,$_QO88j,$_QOO18);
	}
	function get($_IQtQL) {
		return $this->doRequest('GET', $_IQtQL, 'NULL');
	}
	function post($_IQtQL, $_QoQot) {
		return $this->doRequest('POST', $_IQtQL, $_QoQot);
	}
	function postToQuery($post,$_IJtfJ=false) {
		$_QOO18="";
		$_IJOQJ=array_keys($post);
		for ($_Q8ILi=0;$_Q8ILi<count($post);$_Q8ILi++) {
			if ($_Q8ILi>0) $_QOO18.="&";
			$_IJOi0=$_IJOQJ[$_Q8ILi];
			if ($_IJtfJ) {
				$_QOO18.=$_IJOi0."=".urlencode($post[$_IJOi0]);
			} else {
				$_QOO18.=$_IJOi0."=".$post[$_IJOi0];
			}
		}
		return $_QOO18;
	}
	function doMD5($post) {
		global $CFG;
		$_QOO18="";
		ksort($post);
		$_IJOQJ=array_keys($post);
		for ($_Q8ILi=0;$_Q8ILi<count($post);$_Q8ILi++) {
			$_IJOi0=$_IJOQJ[$_Q8ILi];
			$_QOO18.=$post[$_IJOi0];
		}
		$_QOO18.=$CFG->turnitin_secretkey;
		return md5($_QOO18);
	}
	function tiiGmtime() {
		$_QOO18="";
		$_QOO18.=gmdate('YmdH',time());
		$_QOO18.=substr(gmdate('i',time()),0,1);
		return $_QOO18;
	}
}
function turnitintool_outputobj($_QtlJi) {
	$_IJoJi=10;
	foreach ($_QtlJi as $_Ijl0l) {
		echo "<pre>";
		$_QO1If=0;
		foreach ($_Ijl0l as $_IJC0l) {
			$_IJC6i=' ';
			echo " | ".substr(str_pad($_IJC0l,$_IJoJi,$_IJC6i),0,$_IJoJi);
			$_QO1If++;
		}
		echo " |<br />".str_pad('',($_QO1If*$_IJoJi+3),'-')."<br /></pre>";
	}
}
?>
