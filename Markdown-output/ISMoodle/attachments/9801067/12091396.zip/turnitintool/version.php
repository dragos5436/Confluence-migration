<?php

$module->version  = 2009102301;  // The current module version (Date: YYYYMMDDXX)
$module->cron     = 1800;        // Period for cron to check this module (secs)

?>
