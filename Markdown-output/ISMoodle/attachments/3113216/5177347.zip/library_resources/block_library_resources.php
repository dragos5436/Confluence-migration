<?php

/* Reference block by Tom Flannaghan and Andrew Walker - Alton College.  
Modified for RHUL use by Alison Pope */
/*CHANGE LOG 
1.0  (00) Initial release of RHUL modified library block.  This takes the learning resource block and adds context sensitivity that allow resources to be generic or relate to the course or course category
1.1 (01) 06/07/2006 Moved the additional text so it displays when you hover over the link (tool tip) instead of as text within the block
1.2 (02) 09/08/2006 Changed how liaison librarian is looked up. Added person context and created tables to lookup liaison librarian from staff db via a lookup table in Moodle.
1.3 (03) 29/09/2006 Removed department string from end of category context links.
*/

    class block_library_resources extends block_list {
        function init() {
            $this->title = "Library Resources";
            $this->version = 2006092903;
        }
        
        function specialization() {
            global $CFG;
            
            $this->title = !empty($CFG->block_library_resources_title) ? $CFG->block_library_resources_title : $this->title;
        }
        
        function get_content() {
            if ($this->content !== NULL) {
                return $this->content;
            }
            
            $this->content = new stdClass;
            $this->content->items = array();
            $this->content->icons = array();
            $this->content->footer = '';
            
            $rs = get_records('block_library_resources');
            if (!is_array($rs)) {
                $rs = array();
            }
            $rs = stripslashes_safe($rs);
            
            foreach ($rs as $link) {
                $temp = 'allow_' . $link->id;
                if (isset($this->config->$temp)) {
                    if ($this->config->$temp == 1) {
                        $this->add_link($link);
                    }
                } else if ($link->defaultshow == 1) {
                    $this->add_link($link);
                }
            }
            
            return $this->content;
        }
		
		
        
        function add_link($link) {
            global $CFG;

   //new for library block         
$course  = get_record('course', 'id', $this->instance->pageid);
$category = get_record('course_categories','id',$course->category);
$strdept = get_string('department');
//$librarian = get_record_sql('SELECT * FROM `rhul_lib_liaison` WHERE rhul_lib_liaison.id in (SELECT librarian FROM rhul_lib_liaison_subject WHERE rhul_lib_liaison_subject.category =' .$course->category .')');
   //new for library block   
   
        
            $target = !empty($CFG->block_library_resources_window) ? ' target="_blank"' : '';

/* Make links context sensitive */

if ($link->context == 2) { 
// We are going to check whether the context for this link is course
                   $this->content->items[] = '<a href="' . str_replace("%s",urlencode(substr($course->shortname,0,8)),$link->url) .'"' . $target . 'title="' .$link->notes . '">'. $link->linktext . ' for '. substr($course->shortname,0,8). '</a>'; 
// If so we embed the course shortname in the url and the link text and add the url postscript.
                    }
else if ($link->context == 3) {
// We are going to check whether the context for this link is category name
               $this->content->items[] = '<a href="' . str_replace("%s",urlencode($course->category),$link->url).'"' . 'title="' .$link->notes . '">'.  $link->linktext . ' for '. $category->name. ' </a>'; 
// If so we embed the category id in the url and the link text and add the url postscript.
}
else if ($link->context == 4) {
     $this->content->items[] = '<a href="' . str_replace("%s",urlencode($category->name),$link->url).'"' . $target . 'title="' .$link->notes . '">' .  $link->linktext . ' for '. $category->name. ' </a>';  
// If so we embed the category in the url and the link text and add the url postscript.
}
else if ($link->context == 5) {
	if (is_null($librarian->staffdbid)) {
		//do nothing
		$this->content->items[] = 'Sorry there is no Liaison Librarian for this course';
	}
	else {
// We are going to check whether the context for this link is to lookup the librarian
               $this->content->items[] = '<a href="' . str_replace("%s",urlencode($librarian->staffdbid),$link->url).'"' . $target . 'title="' .$link->notes . '">'.  $link->linktext . ' for '. $category->name. ' </a>'; 
// If so we embed the category id in the url and the link text and add the url postscript.
	}
}
 else  { // If not just output the url and the link text.
                        $this->content->items[] = '<a href="' . $link->url. '"' . $target .'title="' .$link->notes . '">'. $link->linktext . '</a>';
                }

            $this->content->icons[] = '<img src="' . $CFG->pixpath . '/f/web.gif" height="16" width="16" alt="" />';
        						}
		
		
        
        function instance_allow_config() {
            return true;
        }
        
        function has_config() {
            return true;
        }

    }
?>