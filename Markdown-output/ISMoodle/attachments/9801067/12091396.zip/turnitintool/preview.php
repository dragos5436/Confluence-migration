<?php  // $Id: view.php,v 1.6 2007/09/03 12:23:36 jamiesensei Exp $
/**
 * This page prints a particular instance of turnitintool
 *
 * @author
 * @version $Id: view.php,v 1.6 2007/09/03 12:23:36 jamiesensei Exp $
 * @package turnitintool
 **/


    require_once("../../config.php");
    require_once("lib.php");
	require_once($CFG->dirroot."/lib/uploadlib.php");
	
	require_js($CFG->wwwroot.'/mod/turnitintool/turnitintool.js');

    $id = required_param('id', PARAM_INT); // Course Module ID, or
    $a  = optional_param('a', 0, PARAM_INT);  // turnitintool ID
	$s  = optional_param('s', 0, PARAM_INT);  // submission ID
	$type  = optional_param('type', 0, PARAM_INT);  // submission ID

    if ($id) {
        if (! $cm = get_record("course_modules", "id", $id)) {
            error("Course Module ID was incorrect");
        }

        if (! $course = get_record("course", "id", $cm->course)) {
            error("Course is misconfigured");
        }

        if (! $turnitintool = get_record("turnitintool", "id", $cm->instance)) {
            error("Course module is incorrect");
        }
		if (! $submission = get_record("turnitintool_submissions", "id", $s)) {
			error("Submission ID is incorrect");
		}

    } else {
        if (! $turnitintool = get_record("turnitintool", "id", $a)) {
            error("Course module is incorrect");
        }
        if (! $course = get_record("course", "id", $turnitintool->course)) {
            error("Course is misconfigured");
        }
        if (! $cm = get_coursemodule_from_instance("turnitintool", $turnitintool->id, $course->id)) {
            error("Course Module ID was incorrect");
        }
		if (! $submission = get_record("turnitintool_submissions", "id", $s)) {
			error("Submission ID is incorrect");
		}
    }

    require_login($course->id);


/// Print the main part of the page
	
	if (has_capability('mod/turnitintool:grade', get_context_instance(CONTEXT_MODULE, $cm->id))
		OR (has_capability('mod/turnitintool:submit', get_context_instance(CONTEXT_MODULE, $cm->id)) AND $submission->userid == $USER->id)) {
		if ($type=="2") {
			
			turnitintool_header($cm,$course,$_SERVER["REQUEST_URI"],$submission->submission_title, NULL, '', '', '');
			print_heading($submission->submission_title, '', 3);
			echo nl2br($submission->submission_text);
			turnitintool_footer('none', 'none');
			
		} else if ($type=="3") {
			echo $submission->submission_text;
		} else {
			print_error('submissiongeterror','turnitintool');
		}
	} else {
		print_error('permissiondeniederror','turnitintool');
	}
	

?>