<?php

    class block_library_search extends block_base {
        function init() {
            $this->title = "Library Search";
            $this->version = 2006070600;
        }
        
        function specialization() {
            global $CFG;
            
            $this->title = !empty($CFG->block_library_search_title) ? $CFG->block_library_search_title : $this->title;
            $this->course = get_record('course', 'id', $this->instance->pageid);
        }
        
function get_content() {
            global $CFG;
            if ($this->content !== NULL) {
                return $this->content;
            }
            
            $this->content = new stdClass;
            $this->content->footer = '';
            
            $this->content->text  = '<div class="searchform">';
            $this->content->text .= '<form name="librarysearch" action="'.$CFG->wwwroot.'/blocks/library_search/search.php" target="_blank" style="display:inline">';
            $this->content->text .= '<input name="courseid" type="hidden" value="'.$this->course->id.'" />';   
            $this->content->text .= '<label for="search">Enter Search Term</label><input name="search" type="text" size="26" value="" alt="search" />';
            $this->content->text .= '<div><label for="engine">Select Search Engine</label><select name="engine" onChange="document.librarysearch.engine.value=this.options[this.selectedIndex].value;">';
            
            $rs = get_records('block_library_search');
            if (!is_array($rs)) {
                $rs = array();
            }
            $rs = stripslashes_safe($rs);
            
            foreach ($rs as $link) {
                $temp = 'allow_' . $link->id;
                if (isset($this->config->$temp)) {
                    if ($this->config->$temp == 1) {
                          $this->content->text .= '<option value="'.$link->id .'">'.$link->linktext .'</option>';
                    }
                } else if ($link->defaultshow == 1) {
                         $this->content->text .= '<option value="'.$link->id .'">'.$link->linktext .'</option>';
                }
            }
            
            $this->content->text .= '</select></div>';
            $this->content->text .= '<input type="submit" value="Search" onClick="document.librarysearch.submit();return false;" />';
            $this->content->text .= '</form></div>';
            
            return $this->content;
        }
		
        function instance_allow_config() {
            return true;
        }
        
        function has_config() {
            return true;
        }

    }
?>