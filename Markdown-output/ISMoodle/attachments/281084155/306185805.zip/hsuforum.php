<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from https://moodle.ucl.ac.uk
 *
 * @package    mod
 * @subpackage hsuforum
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['forumtype_help'] = 'There are 5 forum types: * A single simple discussion - A single discussion topic to which everyone can reply (cannot be used with separate groups). * Each person posts one discussion - Each student can post exactly one new discussion topic, to which everyone can then reply. * Q and A forum - Students must first post their perspectives before viewing other students\' posts. You must post a question in order for student to be able to answer it. * Standard forum displayed in a blog-like format - An open forum where anyone can start a new discussion at any time, and in which discussion topics are displayed on one page with "Discuss this topic" links. * Standard forum for general use - An open forum where anyone can start a new discussion at any time.';
$string['hsuforum:revealpost'] = 'Reveal your identity in an anonymous forum';
$string['modulename'] = 'Forum (Advanced)';
$string['modulename_help'] = '<p>The Advanced Forum activity module enables participants to have asynchronous discussions with the additional option of allowing anonymous forum posts. (see \'<span class="" style="color: rgb(255, 51, 102);">Caution</span>\' note in <a href="https://wiki.ucl.ac.uk/x/RgU8AQ" target="_blank">Miniguide </a>regarding anonymity and subscription)</p><p><br></p><p>The anonymous posting setting can be enabled in the Advanced Forum settings and students and staff can then choose whether or not to post anonymously. They can also go back to posts at any point in the future, and change their post to reveal their identity or make it anonymous.&nbsp;</p><p><br></p><p>Other advanced features include the ability for tutors to bookmark posts and mark posts as substantive (important or meaningful). A \'View posters\' page allows tutors to see how many posts each student has started, how many posts they have replied to, as well as how many have been marked as substantive.</p><p><br></p><p>All other settings are similar to the standard Moodle forum (see the Forum activity for more information).</p>';
$string['modulenameplural'] = 'Forums (Advanced)';
$string['pluginname'] = 'Forum (Advanced)';
$string['qandanotify'] = 'This is a question and answer forum. In order to see other responses to these questions, you must first reply to the question below. If you cannot see a question, please ask your tutor to post one first.';
$string['reveal'] = 'Reveal your identity in this post';
