<?php  //$Id: upgrade.php,v 1.2 2007/08/08 22:36:54 stronk7 Exp $

// This file keeps track of upgrades to
// the turnitintools module

function xmldb_turnitintool_upgrade($oldversion) {

    global $CFG, $THEME, $DB;

    $result = true;

	// Do necessary DB upgrades here
	//function add_field($name, $type, $precision=null, $unsigned=null, $notnull=null, $sequence=null, $enum=null, $enumvalues=null, $default=null, $previous=null)

	if ($result && $oldversion < 2009071501) {
		if (is_callable(array($DB,'get_manager'))) {
			$dbman=$DB->get_manager();
			$table = new xmldb_table('turnitintool_submissions');
			$field = new xmldb_field('submission_gmimaged', XMLDB_TYPE_INTEGER, '10', XMLDB_UNSIGNED, XMLDB_NOTNULL, null, null, null, '0', 'submission_grade');
	
			if (!$dbman->field_exists($table, $field)) {
				$dbman->add_field($table, $field);
			}
		} else {
			$table = new XMLDBTable('turnitintool_submissions');
			$field = new XMLDBField('submission_gmimaged');
			$field->setAttributes(XMLDB_TYPE_INTEGER, '10', XMLDB_UNSIGNED, XMLDB_NOTNULL, null, null, null, '0', 'submission_grade');
			$result = $result && add_field($table, $field);
		}
	}
	
	if ($result && $oldversion < 2009091401) {
		if (is_callable(array($DB,'get_manager'))) {
			$dbman=$DB->get_manager();
			$table = new xmldb_table('turnitintool');
			$field = new xmldb_field('introformat', XMLDB_TYPE_INTEGER, '4', XMLDB_UNSIGNED, null, null, null, null, '0', 'intro');
	
			if (!$dbman->field_exists($table, $field)) {
				$dbman->add_field($table, $field);
			}
		} else {
			$table = new XMLDBTable('turnitintool');
			$field = new XMLDBField('introformat');
			$field->setAttributes(XMLDB_TYPE_INTEGER, '4', XMLDB_UNSIGNED, null, null, null, null, '0', 'intro');
			$result = $result && add_field($table, $field);
		}
	}
	
	if ($result && $oldversion < 2009092901) {
		if (is_callable(array($DB,'get_manager'))) {
			$dbman=$DB->get_manager();
			$table1 = new xmldb_table('turnitintool');
			$field1 = new xmldb_field('resubmit', XMLDB_TYPE_INTEGER, '1', XMLDB_UNSIGNED, null, null, null, null, '0', 'defaultdtpost');
			if ($dbman->field_exists($table1, $field1)) {
				$dbman->rename_field($table1, $field1, 'anon');
			}
			
			$table2 = new xmldb_table('turnitintool_submissions');
			$field2 = new xmldb_field('submission_unanon', XMLDB_TYPE_INTEGER, '1', XMLDB_UNSIGNED, NULL, null, null, null, '0', 'submission_nmlastname');
			$field3 = new xmldb_field('submission_unanonreason', XMLDB_TYPE_TEXT, 'medium', null, null, null, null, 'submission_unanon');
			$field4 = new xmldb_field('submission_nmuserid', XMLDB_TYPE_TEXT, 'medium', null, null, null, null, null);
	
			if (!$dbman->field_exists($table2, $field2)) {
				$dbman->add_field($table2, $field2);
			}
			if (!$dbman->field_exists($table2, $field3)) {
				$dbman->add_field($table2, $field3);
			}
			$dbman->change_field_type($table2, $field4);
		} else {
			$table1 = new XMLDBTable('turnitintool');
			$field1 = new XMLDBField('resubmit');
			$field1->setAttributes(XMLDB_TYPE_INTEGER, '1', XMLDB_UNSIGNED, null, null, null, null, '0', 'defaultdtpost');
			$result = $result && rename_field($table1, $field1, 'anon');
			
			$table2 = new XMLDBTable('turnitintool_submissions');
			$field2 = new XMLDBField('submission_unanon');
			$field3 = new XMLDBField('submission_unanonreason');
			$field4 = new XMLDBField('submission_nmuserid');
			$field2->setAttributes(XMLDB_TYPE_INTEGER, '1', XMLDB_UNSIGNED, null, null, null, null, '0', 'submission_nmlastname');
			$result = $result && add_field($table2, $field2);
			$field3->setAttributes(XMLDB_TYPE_TEXT, 'medium', null, null, null, null, null, null, 'submission_unanon');
			$result = $result && add_field($table2, $field3);
			$field4->setAttributes(XMLDB_TYPE_TEXT, 'medium', null, null, null, null, null, null, null);
			$result = $result && change_field_type($table2, $field4);
		}
	}

    return $result;
}

?>
