<?php // $Id: block_library_resources.php,v 1.1 2006/06/13 queendido Exp $ 

$string['actions'] = 'Actions';
$string['are_you_sure'] = 'Are you sure you want to delete';
$string['addlink'] = 'Add a link';
$string['blockname'] = 'Library Resources';
$string['context'] = 'Context';
$string['context1'] = 'No context';
$string['context2'] = 'Course Shortname';
$string['context3'] = 'Category Name';
$string['context4'] = 'Category Name (new window)';
$string['context5'] = 'Liaison Librarian';
$string['defaultshow'] = 'Show by default';
$string['delete'] = 'Delete';
$string['deleted'] = 'The resource has been deleted';
$string['delete_resources'] = 'Delete resources';
$string['display'] = 'Display';
$string['links'] = 'Search Engines';
$string['linktext'] = 'Search Engine Name';
$string['manage_links'] = 'Add/Edit Search Engines';
$string['modify'] = 'Edit';
$string['newwindow_label'] = 'Open links in a new window:';
$string['no'] = 'No';
$string['none'] = 'There are no items to display';
$string['notes'] = 'Additional text';
$string['not_exist'] = 'The selected resource does not exist!';
$string['reference'] = 'Reference';
$string['title_label'] = 'Title:';
$string['url'] = 'URL';
//$string['urlps'] = '???';
$string['yes'] = 'Yes';
?>