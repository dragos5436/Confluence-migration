<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Details services
 *
 * @copyright &copy; 2011 University of London Computer Centre
 * @author http://www.ulcc.ac.uk, http://moodle.ulcc.ac.uk
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package ULCC_webservices
 * @version 1.0
 */

$functions = array (
    'ulcc_course_get_sections' => array(
        'classname'   => 'local_ulcc_webservices',
        'methodname'  => 'course_get_sections',
        'classpath'   => 'local/ulcc_webservices/externallib.php',
        'description' => 'Returns a list of the sections within a course',
        'type'        => 'read',
    ),
    'ulcc_section_get_content' => array(
        'classname'   => 'local_ulcc_webservices',
        'methodname'  => 'section_get_content',
        'classpath'   => 'local/ulcc_webservices/externallib.php',
        'description' => 'Returns the content within a section',
        'type'        => 'read',
    ),
    'ulcc_get_user_assignments' => array(
        'classname'   => 'local_ulcc_webservices',
        'methodname'  => 'get_user_assignments',
        'classpath'   => 'local/ulcc_webservices/externallib.php',
        'description' => 'Returns all user assigments',
        'type'        => 'read',
    ),
    'ulcc_get_cm_assignment' => array(
        'classname'   => 'local_ulcc_webservices',
        'methodname'  => 'get_cm_assignment',
        'classpath'   => 'local/ulcc_webservices/externallib.php',
        'description' => 'Returns a assigment based on its course module id',
        'type'        => 'read',
    ),
    'ulcc_get_user_grades' => array(
        'classname'   => 'local_ulcc_webservices',
        'methodname'  => 'get_user_grades',
        'classpath'   => 'local/ulcc_webservices/externallib.php',
        'description' => 'Returns all finalised grades for the user with the given id',
        'type'        => 'read',
    ),
    'ulcc_get_course_grades' => array(
        'classname'   => 'local_ulcc_webservices',
        'methodname'  => 'get_course_grades',
        'classpath'   => 'local/ulcc_webservices/externallib.php',
        'description' => 'Returns all grades the given user in the given course',
        'type'        => 'read',
    ),

    'ulcc_get_coursemodule_forum' => array(
        'classname'   => 'local_ulcc_webservices',
        'methodname'  => 'get_coursemodule_forum',
        'classpath'   => 'local/ulcc_webservices/externallib.php',
        'description' => 'Returns forum with course module id',
        'type'        => 'read',
    ),

    'ulcc_get_course_forums' => array(
        'classname'   => 'local_ulcc_webservices',
        'methodname'  => 'get_course_forums',
        'classpath'   => 'local/ulcc_webservices/externallib.php',
        'description' => 'Returns all forums within the given course',
        'type'        => 'read',
    ),

    'ulcc_get_forum_discussions' => array(
        'classname'   => 'local_ulcc_webservices',
        'methodname'  => 'get_forum_discussions',
        'classpath'   => 'local/ulcc_webservices/externallib.php',
        'description' => 'Returns all discussions within the forum with the given id',
        'type'        => 'read',
    ),

    'ulcc_get_discussion_posts' => array(
        'classname'   => 'local_ulcc_webservices',
        'methodname'  => 'get_discussion_posts',
        'classpath'   => 'local/ulcc_webservices/externallib.php',
        'description' => 'Returns all posts within the discussion with the given id',
        'type'        => 'read',
    ),

    'ulcc_add_forum_discussion' => array(
        'classname'   => 'local_ulcc_webservices',
        'methodname'  => 'add_forum_discussion',
        'classpath'   => 'local/ulcc_webservices/externallib.php',
        'description' => 'Adds a discussion post to the forum with the given id',
        'type'        => 'read',
    ),

    'ulcc_add_discussion_post' => array(
        'classname'   => 'local_ulcc_webservices',
        'methodname'  => 'add_discussion_post',
        'classpath'   => 'local/ulcc_webservices/externallib.php',
        'description' => 'Adds a post to a forum discussion',
        'type'        => 'read',
    ),

    'ulcc_get_user_forums' => array(
        'classname'   => 'local_ulcc_webservices',
        'methodname'  => 'get_user_forums',
        'classpath'   => 'local/ulcc_webservices/externallib.php',
        'description' => 'get all forums a user can post to',
        'type'        => 'read',
    ),

    'ulcc_get_coursemodule_choice' => array(
        'classname'   => 'local_ulcc_webservices',
        'methodname'  => 'get_coursemodule_choice',
        'classpath'   => 'local/ulcc_webservices/externallib.php',
        'description' => 'get the choice record linked to the given course module id',
        'type'        => 'read',
    ),

    'ulcc_user_choice_repsonse' => array(
        'classname'   => 'local_ulcc_webservices',
        'methodname'  => 'user_choice_repsonse',
        'classpath'   => 'local/ulcc_webservices/externallib.php',
        'description' => 'submit a response to a choice',
        'type'        => 'read',
    ),

    'ulcc_get_choice_options' => array(
        'classname'   => 'local_ulcc_webservices',
        'methodname'  => 'get_choice_options',
        'classpath'   => 'local/ulcc_webservices/externallib.php',
        'description' => 'get the choice option',
        'type'        => 'read',
    ),

    'ulcc_get_users_courses' => array(
        'classname'   => 'local_ulcc_webservices',
        'methodname'  => 'get_users_courses',
        'classpath'   => 'local/ulcc_webservices/externallib.php',
        'description' => 'get the users courses',
        'type'        => 'read',
    ),



);



$services = array(
    'ULCC get course sections' => array(
        'functions' => array ('ulcc_course_get_sections'),
        'enabled'=>1,
    ),
    'ULCC get sections content' => array(
        'functions' => array ('ulcc_section_get_content'),
        'enabled'=>1,
    ),
    'ULCC get user assignment' => array(
        'functions' => array ('ulcc_get_user_assignments'),
        'enabled'=>1,
    ),
    'ULCC get a assignment using its course module id' => array(
        'functions' => array ('ulcc_get_cm_assignment'),
        'enabled'=>1,
    ),
    'ULCC get user grades' => array(
        'functions' => array ('ulcc_get_user_grades'),
        'enabled'=>1,
    ),
    'ULCC get course grades' => array(
        'functions' => array ('ulcc_get_course_grades'),
        'enabled'=>1,
    ),
    'ULCC get course forums' => array(
        'functions' => array ('ulcc_get_course_forums'),
        'enabled'=>1,
    ),
    'ULCC get course module forum' => array(
        'functions' => array ('ulcc_get_coursemodule_forum'),
        'enabled'=>1,
    ),
    'ULCC get forum discussion' => array(
        'functions' => array ('ulcc_get_forum_discussions'),
        'enabled'=>1,
    ),

    'ULCC get discussion posts' => array(
        'functions' => array ('ulcc_get_discussion_posts'),
        'enabled'=>1,
    ),

    'ULCC add_forum_discussion' => array(
        'functions' => array ('ulcc_add_forum_discussion'),
        'enabled'=>1,
    ),

    'ULCC get add discussion post' => array(
        'functions' => array ('ulcc_add_discussion_post'),
        'enabled'=>1,
    ),

    'ULCC get_user_forums' => array(
        'functions' => array ('ulcc_get_user_forums'),
        'enabled'=>1,
    ),

    'ULCC get_coursemodule_choice' => array(
        'functions' => array ('ulcc_get_coursemodule_choice'),
        'enabled'=>1,
    ),


    'ULCC user choice repsonse' => array(
        'functions' => array ('ulcc_user_choice_repsonse'),
        'enabled'=>1,
    ),

    'ULCC get_choice_options' => array(
        'functions' => array ('ulcc_get_choice_options'),
        'enabled'=>1,
    ),

    'ULCC get_users_courses' => array(
        'functions' => array ('ulcc_get_users_courses'),
        'enabled'=>1,
    ),


);